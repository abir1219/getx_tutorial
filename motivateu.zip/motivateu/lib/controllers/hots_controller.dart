import 'dart:async';

import 'package:MotivateU/repository/hots_repository.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/hots_model.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class HotsController extends GetxController{
  final _hotsRepository = HotsRepository();

  Rx<HotsModel> hotsModel = HotsModel().obs;
  RxBool isLoading = false.obs;

  Timer? timerTrack;
  Rx<int> counterTracker = 0.obs;
  Rx<bool> haveTime = true.obs;

  void startTimerTrack() {
    debugPrint("--------Hots Pattern Start---------");
    // haveTime.value = true;
    // counterTracker.value = 0;
    timerTrack = Timer.periodic(Duration(seconds: 1), (timer) {
      // if(SharedPreferencesUtils.getInt(AppConstants.USED_TIME)! > counterTracker.value){
      if (haveTime.value) {
        if (SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! >= counterTracker.value) {
          debugPrint("HOTS_PATTERN_counterTracker_Timer====>${counterTracker.value}");
          counterTracker.value += 1000;
        } else {
          haveTime.value = false;
          timer.cancel(); // Stop the timer when haveTime.value becomes false
          debugPrint("<<<<<<<==Stop==>>>>>>>>>");
          stopTimerTrack();
        }
      } else {
        haveTime.value = false;
        timer.cancel(); // Stop the timer if haveTime.value is already false
      }
    });

  }

  void stopTimerTrack([String? questionID]) {
    debugPrint("--------Hots Pattern Stop---------");
    if (timerTrack != null && timerTrack!.isActive) {
      timerTrack!.cancel();
      debugPrint("HOTS_PATTERN_counterTracker_STOP====>${counterTracker.value}");
     sendTimeTrack(questionID);
      counterTracker.value = 0;
    }
  }

  Future<void> sendTimeTrack([String? questionId = null]) async{
    debugPrint("--------Hots Pattern Send Track---------");
    Map<String,dynamic> body = {
      "profile" : SharedPreferencesUtils.getString(AppConstants.PROFILE_ID),
      "question" : questionId,
      "time" : counterTracker.value
    };

    _hotsRepository.sendTimeTrack(body).then((value) {
      if(value['errMsg'] == false){
        //Utils.showToastMessage(value['message']);
        SharedPreferencesUtils.saveInt(AppConstants.LEFT_TIME,value['leftTime']);
      }
    }).onError((error, stackTrace) {
      debugPrint("TIME_TRACK_ERROR->$error");
    });
  }


  /*@override
  void onInit() {
    super.onInit();
    getHotsList();
  }
*/
  Future<void> getHotsList() async{
    isLoading.value = true;
    _hotsRepository.getHotList().then((value) {
      isLoading.value = false;
      hotsModel.value = HotsModel.fromJson(value);
      if(hotsModel.value.errMsg==true){
        Utils.showToastMessage(hotsModel.value.message!);
      }
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("HOTS_ERROR=>$error");
      Utils.showToastMessage(error.toString());
    });
  }
}