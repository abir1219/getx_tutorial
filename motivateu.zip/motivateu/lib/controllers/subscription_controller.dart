import 'dart:io';

import 'package:MotivateU/models/subscription_model.dart';
import 'package:MotivateU/repository/subscription_repository.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_file_downloader/flutter_file_downloader.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';

import '../helper/api_end_points.dart';
import '../main.dart';
import '../models/my_subscription_history.dart';

class SubscriptionController extends GetxController{
  final _subscriptionRepo = SubscriptionRepository();
  Rx<SubscriptionModel> subscriptionModel = SubscriptionModel().obs;
  Rx<MySubscriptionHistory> mySubscriptionListModel = MySubscriptionHistory().obs;
  Rx<bool> isLoading = false.obs;
  Rx<bool> isAnotherLoading = false.obs;
  Rx<bool> isValue = false.obs;

  Future<void> getSubscriptionList() async{
    isLoading.value = true;
    _subscriptionRepo.getSubscriptionList().then((value) {
      isLoading.value = false;
      subscriptionModel.value = SubscriptionModel.fromJson(value);
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("SUBSCRIPTION_LIST_ERROR: $error");
    });
  }

  Future<void> getSubscriptionInvoice(var subscriptionId) async{
    _subscriptionRepo.getSubscriptionInvoice(subscriptionId).then((value) async {
      debugPrint("invoice-value-->$value");
      debugPrint("invoice-url-->https://s3.ap-south-1.amazonaws.com/motivateyou-invoice.motivateuedutech.com/${value['result']['fileUrl']}");

      /*if(value['errMsg'] == false){
        if(Platform.isAndroid){
                  if(await _requestPermission(Permission.storage)){
                    FileDownloader.downloadFile(
                        url: "https://s3.ap-south-1.amazonaws.com/motivateyou-invoice.motivateuedutech.com/${value['result']['fileUrl']}",
                        name: "Invoice",
                        downloadDestination: DownloadDestinations.appFiles,
                        notificationType: NotificationType.all,
                        onProgress: (fileName, progress) {
                          debugPrint("===Progress===$progress");
                        },
                        onDownloadCompleted: (path) {
                          //final File file = File(path);
                          //This will be the path of the downloaded file

                        });
                  }
                }else if(Platform.isIOS){
                  FileDownloader.downloadFile(
                      url: "https://indiapostgdsonline.cept.gov.in/Notifications/Model_Notification.pdf",
                      name: "Model_Notification",
                      downloadDestination: DownloadDestinations.appFiles,
                      notificationType: NotificationType.all,
                      onProgress: (fileName, progress) {
                        debugPrint("===Progress===$progress");
                      },
                      onDownloadCompleted: (path) {
                        //final File file = File(path);
                        //This will be the path of the downloaded file

                      });
                }
      }*/
    }).onError((error, stackTrace) {
      debugPrint("Invoice_error->$error");
    });
  }

  Future<bool> _requestPermission(Permission permission) async {
    final deviceInfoPlugin = DeviceInfoPlugin();

    AndroidDeviceInfo build = await deviceInfoPlugin.androidInfo;
    debugPrint("build---->$build");

    if (build.version.sdkInt >= 30) {
      var re = await Permission.manageExternalStorage.request();
      if (re.isGranted) {
        return true;
      } else {
        return false;
      }
    } else {
      if (await permission.isGranted) {
        return true;
      } else {
        var result = await permission.request();
        if (result.isGranted) {
          return true;
        } else {
          return false;
        }
      }
    }
  }

  Future<void> mySubscriptionList() async{
    isAnotherLoading.value = true;
    _subscriptionRepo.mySubscriptionList().then((value) {
      isAnotherLoading.value = false;
      mySubscriptionListModel.value = MySubscriptionHistory.fromJson(value);
    }).onError((error, stackTrace) {
      isAnotherLoading.value = false;
      debugPrint("SUBSCRIPTION_LIST_ERROR: $error");
    });
  }

  Future<void> mySubscriptionHistoryList() async{
    isLoading.value = true;
    _subscriptionRepo.mySubscriptionHistoryList().then((value) {
      isLoading.value = false;
      mySubscriptionListModel.value = MySubscriptionHistory.fromJson(value);
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("SUBSCRIPTION_LIST_ERROR: $error");
    });
  }

  Future<void> subscribePlan(var subscriptionId, int? baseAmount,int totalAmount,int sgstAmount,int cgstAmount,String hsnCode) async{
    isLoading.value = true;
    Map<String,dynamic> body = {
      'subscription' : subscriptionId,
      "baseAmount" : baseAmount,
      "totalAmount": totalAmount,
      "sgstAmount" : sgstAmount,
      "cgstAmount" :cgstAmount,
      "igstAmount" : 0,
      "hsnCode" : hsnCode,
      "transactionId" : "TN480234802348923",
      "transactionStatus" : "success"
    };
    _subscriptionRepo.subscribePlan(body).then((value) {
      isLoading.value = false;
      if(value['errMsg'] == false){
        Utils.showToastMessage(value['message']);
        getTimeApiCall();
        // Get.offNamed(AppRoutes.dashboard,arguments: [4]);
        Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'4'});
      }else{
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("SUBSCRIPTION_LIST_ERROR: $error");
    });
  }


}//mySubscriptionHistoryList