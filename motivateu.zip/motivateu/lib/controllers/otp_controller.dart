import 'dart:async';

import 'package:MotivateU/repository/otp_repository.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart';
import '../main.dart';
import '../models/send_otp_model.dart';
import '../models/verify_otp_model.dart';
import '../res/routes/app_routes.dart';
import '../utils/utils.dart';

class OtpController extends GetxController {
  final _otpRepository = OtpRepository();
  Rx<SendOtpModel> sendOtpData = SendOtpModel().obs;
  Rx<VerifyOtpModel> verifyOtpData = VerifyOtpModel().obs;

  Rx<TextEditingController> phController = TextEditingController().obs;
  Rx<String> otpController = "".obs;

  Rx<String> verifyType = "".obs;
  Rx<bool> isLoading = false.obs;
  Rx<bool> isLoad = false.obs;

  Timer? _timer;
  Rx<int> _counter = 45.obs;

  int get counter => _counter.value;

  void startTimer() {
    _timer = Timer.periodic(Duration(milliseconds: 1), (timer) {
      _counter.value--;
    });
  }

  void stopTimer() {
    _timer?.cancel();
    _counter.value = 0;
  }

  @override
  void onInit() {
    super.onInit();
    startTimer();
    verifyType.value = AppConstants.TYPE;
  }



  Future<void> sendOtp() async {
    isLoad.value = true;
    Map<String, dynamic> body = {
      'phone': phController.value.text.toString().trim(),
    };

    _otpRepository.sendOtp(body).then(
      (value) {
        isLoad.value = false;
        sendOtpData.value = SendOtpModel.fromJson(value);
        if (sendOtpData.value.errMsg == false) {
          debugPrint("OTP=>${sendOtpData.value.otp}");
          debugPrint("PHONE_CONTROLLER=>${phController.value.text.toString().trim()}");

          Get.toNamed(AppRoutes.otp,
              arguments: [phController.value.text.trim().toString(), "other"]);
        }else{
          Utils.showToastMessage(sendOtpData.value.message.toString());
        }
      },
    ).onError(
      (error, stackTrace) {
        isLoad.value = false;
        debugPrint("SEND_OTP_ERROR====>${error}");
      },
    );
  }

  Future<void> verifyOtp(String? type) async {

    isLoading.value = true;
    Map<String, dynamic> body = {
      'phone': phController.value.text.toString().trim(),
      'otp': otpController.value,
    };

    debugPrint("FROM_TYPE=${verifyType.value}");
    _otpRepository.verifyOtp(body).then(
      (value) async {
        isLoading.value = false;

        // debugPrint("sajdhkjahsdjkhasdkhsa;jkdh==>$value");
        // debugPrint("TYPEerwer=>${verifyOtpData.value.accessToken}");
        verifyOtpData.value = VerifyOtpModel.fromJson(value);
        //debugPrint("${value.errMsg}");
        //debugPrint("verifyOtpData.value.errMsg=${verifyOtpData.value.errMsg}");
        if (verifyOtpData.value.errMsg == true) {
          // Utils.showToastMessage(verifyOtpData.value.message.toString());
          debugPrint("TYPEerwer=>${value['message']}");
          Utils.showToastMessage(value['message']);
        } else {
          //Utils.showToastMessage(verifyOtpData.value.message.toString());
          if (verifyOtpData.value.accessToken != null) {
            await SharedPreferencesUtils.init();
            SharedPreferencesUtils.saveString(AppConstants.ACCESS_TOKEN, verifyOtpData.value.accessToken.toString());
            SharedPreferencesUtils.saveString(AppConstants.REFRESH_TOKEN, verifyOtpData.value.refreshToken.toString());
            SharedPreferencesUtils.saveString(AppConstants.LOGIN_TIME, DateTime.now().toString());
            SharedPreferencesUtils.saveString(AppConstants.PROFILE_ID, verifyOtpData.value.profile![0].id!);
            if (verifyType.value == 'login') {
              Utils.showToastMessage(verifyOtpData.value.message.toString());
              //saveSP();
              /*await SharedPreferencesUtils.init();
              SharedPreferencesUtils.saveString(AppConstants.ACCESS_TOKEN, verifyOtpData.value.accessToken.toString());
              SharedPreferencesUtils.saveString(AppConstants.REFRESH_TOKEN, verifyOtpData.value.refreshToken.toString());
              SharedPreferencesUtils.saveString(AppConstants.LOGIN_TIME, DateTime.now().toString());
              SharedPreferencesUtils.saveString(AppConstants.PROFILE_ID, verifyOtpData.value.profile![0].id!);*/
              // Get.offNamed(AppRoutes.dashboard);
              // _connectionSocket();
              socket.emit('connected-student',verifyOtpData.value.profile![0].id!);
              getTimeApiCall();
              addFCM();
              //Get.offNamed(AppRoutes.dashboard,arguments: [0]);
              Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'0'});
            } else if (verifyType.value == 'signup') {
              // Utils.showToastMessage(verifyOtpData.value.message.toString());
              Utils.showToastMessage("This number is already registered");
              Get.offNamed(AppRoutes.mobile);
            } else if (verifyType.value == 'forgetPw') {
              Utils.showToastMessage(verifyOtpData.value.message.toString());
              //SharedPreferencesUtils.saveString(AppConstants.ACCESS_TOKEN, verifyOtpData.value.accessToken.toString());
              Get.offNamed(AppRoutes.forgetPW);
            }
          } else {
            if (verifyType.value == 'login') {
              Utils.showToastMessage("This number has not registered yet");
            } else if (verifyType.value == 'signup') {
              Utils.showToastMessage(verifyOtpData.value.message.toString());
              Get.offNamed(AppRoutes.signup,
                  arguments: [phController.value.text.trim().toString(), ""]);
            } else if (verifyType.value == 'forgetPw') {
              Utils.showToastMessage("This mobile no is not registered.");
              Get.offNamed(AppRoutes.login);
            }
          }
        }
      },
    ).onError(
      (error, stackTrace) {
        isLoading.value = false;
        debugPrint("VERIFY_OTP_ERROR====>${error}");
      },
    );
  }

  Future<void> addFCM() async{
    // await SharedPreferencesUtils.init();
    debugPrint("fcm token=>${SharedPreferencesUtils.getString(AppConstants.TOKEN)}");

    Map<String,dynamic> body = {
      'profile': '${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}',
      'fcm': '${SharedPreferencesUtils.getString(AppConstants.TOKEN)}',
    };
    try{
      _otpRepository.addFcm(body);
    }catch(e){
      debugPrint("Failed to add fcm Token with the profile");
    }
  }

  _connectionSocket(){
    print("Socket Start->${socket.connected}");
    socket.onConnect((data) => print("Connection Established LOIN"));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("Socket After->${socket.json.connected}");
  }

  Future<void> saveSP() async{
    await SharedPreferencesUtils.init();
    SharedPreferencesUtils.saveString(AppConstants.ACCESS_TOKEN, verifyOtpData.value.accessToken.toString());
    SharedPreferencesUtils.saveString(AppConstants.REFRESH_TOKEN, verifyOtpData.value.refreshToken.toString());
    SharedPreferencesUtils.saveString(AppConstants.LOGIN_TIME, DateTime.now().toString());
    SharedPreferencesUtils.saveString(AppConstants.PROFILE_ID, verifyOtpData.value.profile![0].id!);
  }
}
