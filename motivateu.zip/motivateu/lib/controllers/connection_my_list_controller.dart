import 'package:MotivateU/repository/connection_my_list_repository.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/connection_my_list_model.dart';
import '../models/post_model.dart';
import '../repository/fetch_post_repository.dart';
import '../utils/utils.dart';

class ConnectionMyListController extends GetxController {
  final myListRepo = ConnectionMyListRepository();
  final fetchPostRepo = FetchPostRepository();

  RxBool isLoading = false.obs;
  RxBool isMoreLoading = false.obs;

  RxList<List<Connection>?> connectionList = <List<Connection>?>[].obs;
  RxList<List<Group>?> groupList = <List<Group>?>[].obs;

  Rx<PostModel> _postModel = PostModel().obs;

  RxList<Result> _postList = <Result>[].obs;
  RxList<Result> postList = <Result>[].obs;

  //List<List<Result>?> get postList =>_postList;

  RxList<bool> myGroupSelection = <bool>[].obs;
  RxList<String> myGroupList = <String>[].obs;

  Rx<ConnectionMyListModel> myListModel = ConnectionMyListModel().obs;

  void createGroupList() {
    myGroupSelection
        .assignAll(List<bool>.generate(groupList.length, (index) => false));
  }

  void toggleGroupSelectionStatus(int position) {
    // debugPrint(myGroupSelection[position].toString());
    myGroupSelection[position] = !myGroupSelection[position];
    // debugPrint(myGroupSelection[position].toString());
  }

  void toggleSelectedGroupList(int position) {
    //debugPrint("asdm;saldj;sajd"+myListModel.value.connectionMyListModelReturn!.group!.length.toString());
    myGroupList.contains(
            myListModel.value.connectionMyListModelReturn!.group![position].id)
        ? myGroupList.remove(
            myListModel.value.connectionMyListModelReturn!.group![position].id)
        : myGroupList.add(groupList[0]![position].id);
    // debugPrint("GROUP DATA LENGTH=======>"+myListModel.value.connectionMyListModelReturn!.group!.length.toString());
    // for(int i=0;i<myGroupList.length;i++){
    //   debugPrint("GROUP DATA=======>"+myGroupList[i]);
    // }
  }

  Future<void> getConnectionMyList(var pageNo, var type, var searchName) async {
    isLoading.value = true;
    groupList.clear();
    myListRepo
        .getMyConnectionList(
            pageNumber: pageNo, type: type, searchName: searchName)
        .then((value) {
      myListModel.value = ConnectionMyListModel.fromJson(value);
      debugPrint(
          "value['return']['group']=>${myListModel.value.connectionMyListModelReturn!.group!.length}");
      groupList.add(myListModel.value.connectionMyListModelReturn!.group);
      // createGroupList();
      debugPrint("groupList.length=>${groupList.length}");
      myGroupSelection.assignAll(List<bool>.generate(
          myListModel.value.connectionMyListModelReturn!.group!.length,
          (index) => false));
      debugPrint("myGroupSelection Length=>${myGroupSelection[0]}");
      if (myListModel.value.connectionMyListModelReturn!.connection!.length >
          0) {
        debugPrint(
            "value['return']['connection']=>${myListModel.value.connectionMyListModelReturn!.connection!.length}");
        connectionList
            .add(myListModel.value.connectionMyListModelReturn!.connection);
      }
      isLoading.value = false;
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("CONNECTION_MY_LIST_ERROR=>$error");
    });
  }

  Future<void> fetchPost(var pageNumber) async {
    // if(postList!.length>0)
    postList.clear();
    isLoading.value = true;
    String searchGroup = "";
    if (myGroupList.length > 0) {
      for (int i = 0; i < myGroupList.length; i++) {
        // if(i == myGroupList.length){
        if (i == 0) {
          searchGroup = searchGroup + myGroupList[i];
        } else {
          searchGroup = searchGroup + "," + myGroupList[i];
        }
      }
    }
    fetchPostRepo.fetchPost(pageNumber, searchGroup).then((value) {
      isLoading.value = false;
      _postModel.value = PostModel.fromJson(value);
      _postList.assignAll(List<Result>.generate(
          _postModel.value.result!.length,
          (index) => _postModel.value.result![index]));

      postList.addAll(List<Result>.from(_postList));
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("FETCH_POST_ERROR=>$error");
    });
  }

  Future<void> fetchMorePost(var pageNumber) async {
    // if(postList!.length>0)
    // postList.clear();
    isMoreLoading.value = true;
    String searchGroup = "";
    if (myGroupList.length > 0) {
      for (int i = 0; i < myGroupList.length; i++) {
        // if(i == myGroupList.length){
        if (i == 0) {
          searchGroup = searchGroup + myGroupList[i];
        } else {
          searchGroup = searchGroup + "," + myGroupList[i];
        }
      }
    }
    fetchPostRepo.fetchPost(pageNumber, searchGroup).then((value) {
      isMoreLoading.value = false;
      _postModel.value = PostModel.fromJson(value);
      _postList.assignAll(List<Result>.generate(
          _postModel.value.result!.length,
          (index) => _postModel.value.result![index]));

      postList.addAll(List<Result>.from(_postList));
    }).onError((error, stackTrace) {
      isMoreLoading.value = false;
      debugPrint("FETCH_POST_ERROR=>$error");
    });
  }

  RxBool isLikedLoading = false.obs;
  RxBool isDisLikedLoading = false.obs;

  Future<void> likePost(var postId, int index, bool isLiked) async {
    isLikedLoading.value = true;
    // isLoading.value = true;
    fetchPostRepo.likePost(postId).then((value) {
      isLikedLoading.value = false;
      // isLoading.value = false;
      if (value['errMsg'] == false) {
        postList[index].isLiked = !postList[index].isLiked!;
        if(postList[index].isDisliked!)
          postList[index].isDisliked = !postList[index].isDisliked!;
        debugPrint("==postList![index].isLiked==${postList[index].isLiked}");
        /*postList[index].isLiked == true
            ? postList[index].likesCount = postList[index].likesCount! + 1
            : postList[index].likesCount = postList[index].likesCount! - 1;*/
        postList[index].likesCount = value['likeCount'];
        postList[index].dislikesCount = value['dislikeCount'];

        debugPrint("Like-->likesCount->${postList[index].likesCount}, dislikeCount->${postList[index].dislikesCount}");
      } else {}
    }).onError((error, stackTrace) {
      isLikedLoading.value = false;
      // isLoading.value = false;
      debugPrint("LIKE_POST_ERROR->$error");
    });
  }

  Future<void> dislikePost(var postId, int index) async {
    isDisLikedLoading.value = true;
    fetchPostRepo.disLikePost(postId).then((value) {
      isDisLikedLoading.value = false;
      if (value['errMsg'] == false) {
        postList[index].isDisliked = !postList[index].isDisliked!;
        // if(postList[index].isDisliked!)
        //   postList[index].isDisliked = !postList[index].isDisliked!;
        // postList[index].isLiked = !postList[index].isLiked!;

        postList[index].likesCount = value['likeCount'];
        postList[index].dislikesCount = value['dislikeCount'];
        debugPrint("Dislike-->likesCount->${postList[index].likesCount}, dislikeCount->${postList[index].dislikesCount}");
      } else {}
    }).onError((error, stackTrace) {
      isDisLikedLoading.value = false;
      debugPrint("DISLIKE_POST_ERROR->$error");
    });
  }

  Future<void> deletePost(String postId, void Function() function) async {
    isLoading.value = true;
    myListRepo.deletePost(postId).then((value) {
      isLoading.value = false;
      if (value['errMsg'] == false) {
        Utils.showToastMessage(value['message']);
        function();
      } else {
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace) {
      isLoading.value = false;
    });
  }
}
