import 'package:MotivateU/models/chapter_model.dart';
import 'package:MotivateU/models/subject_model.dart';
import 'package:MotivateU/repository/reels_filter_repository.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../models/topic_model.dart';

class ReelsFilterController extends GetxController {
  final _filterRepository = ReelsFilterRepository();

  final Rx<ChapterModel> chapterData = ChapterModel().obs;
  final Rx<TopicModel> topicData = TopicModel().obs;
  final Rx<SubjectModel> subjectData = SubjectModel().obs;

  Rx<bool> isLoading = false.obs;

  Rx<TextEditingController> filterType = TextEditingController().obs;
  Rx<TextEditingController> chapterController = TextEditingController().obs;
  Rx<TextEditingController> topicController = TextEditingController().obs;
  Rx<TextEditingController> keywordController = TextEditingController().obs;

  Rx<String> subjectId = "".obs;
  Rx<String> chapterId = "".obs;
  Rx<String> topicId = "".obs;

  Rx<int> selectedIndex = Rx<int>(-1);


  Future<void> getAllChapters() async {
    isLoading.value = true;

    _filterRepository
        .getChapters(filterType.value.text.toString())
        .then((value) {
      chapterData.value = ChapterModel.fromJson(value);
      isLoading.value = false;
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("ALL_CHAPTERS_ERROR=>$error");
    });
  }

  Future<void> getAllSubjects() async {
    isLoading.value = true;
    _filterRepository
        .getSubjects(filterType.value.text.toString())
        .then((value) {
      subjectData.value = SubjectModel.fromJson(value);
      isLoading.value = false;
    }).onError((error, stackTrace) {
      debugPrint("ALL_SUBJECT_ERROR=>$error");
      isLoading.value = false;
    });
  }

  Future<void> getAllTopics() async {
    isLoading.value = true;

    _filterRepository
        .getTopics(filterType.value.text.toString())
        .then((value) {
      topicData.value = TopicModel.fromJson(value);
      isLoading.value = false;
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("ALL_TOPICS_ERROR=>$error");
    });
  }
}
