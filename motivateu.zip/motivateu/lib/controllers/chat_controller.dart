import 'package:MotivateU/main.dart';
import 'package:MotivateU/models/chat_history_model.dart';
import 'package:MotivateU/repository/chat_repository.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/chat_list_model.dart';
import '../models/chat_model.dart';

class ChatController extends GetxService {
  var _repo = ChatRepository();
  Rx<ChatListModel> chatListModel = ChatListModel().obs;
  Rx<ChatHistoryModel> chatHistoryModel = ChatHistoryModel().obs;

  RxList<Result>? _chatHistoryList = <Result>[].obs;
  RxList<Result>? chatHistoryList = <Result>[].obs;

  RxList<Message> messages = <Message>[].obs;
  RxBool isLoading = false.obs;
  RxBool isLoadingHistory = false.obs;
  RxBool isMoreLoading = false.obs;


  Rx<TextEditingController> messageController = TextEditingController().obs;

  @override
  void onInit() {
    super.onInit();
    loadChatData();
  }

  Future<void> getChatList() async {
    isLoading.value = true;
    _repo.getChatList().then((value) {
      isLoading.value = false;
      chatListModel.value = ChatListModel.fromJson(value);
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("GET_CHAT_LIST_ERROR->$error");
      Utils.showToastMessage("Getting some errors");
    });
  }

  Future<void> getChatHistory(var roomId,var pageNo) async{
    chatHistoryList!.clear();
    isLoadingHistory.value = true;
    _repo.getChatHistory(roomId, pageNo).then((value) {
      chatHistoryModel.value = ChatHistoryModel.fromJson(value);
      if(chatHistoryModel.value.errMsg == false){
        _chatHistoryList?.assignAll(List<Result>.generate(
            chatHistoryModel.value.result!.length,
                (index) => chatHistoryModel.value.result![index]));

        chatHistoryList!.addAll(List<Result>.from(_chatHistoryList!));
        debugPrint("chatHistoryList!.length->${chatHistoryList!.length}");
      }
      isLoadingHistory.value = false;
    }).onError((error, stackTrace) {
      isLoadingHistory.value = false;
      debugPrint("GET_CHAT_HISTORY_ERROR->$error");
      Utils.showToastMessage("Getting some errors");
    });
  }

  Future<void> getMoreChatHistory(var roomId,var pageNo) async{
    isMoreLoading.value = true;
    _repo.getChatHistory(roomId, pageNo).then((value) {
      isMoreLoading.value = false;
      chatHistoryModel.value = ChatHistoryModel.fromJson(value);
      _chatHistoryList?.assignAll(List<Result>.generate(
          chatHistoryModel.value.result!.length,
              (index) => chatHistoryModel.value.result![index]));

      chatHistoryList!.addAll(List<Result>.from(_chatHistoryList!));
    }).onError((error, stackTrace) {
      isMoreLoading.value = false;
      debugPrint("GET_CHAT_HISTORY_ERROR->$error");
      Utils.showToastMessage("Getting some errors");
    });
  }

  Future<void> sendChat(var roomId) async{
    Map<String,dynamic> body = {
      'roomId' : roomId,
      'message' : messageController.value.text.trim(),
    };
    _repo.sendChat(body).then((value) {
      if(value['errMsg'] == false){
        messageController.value.text = "";
        Utils.showToastMessage(value['message']);
      }else{
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace) {
      Utils.showToastMessage("Getting some troubles");
    });
  }

  void loadChatData() {
    // Replace this with your JSON parsing logic
    // You can use the 'json.decode()' method or any other method to parse your JSON data.

    // For the sake of example, I'm manually adding data here:
    messages.addAll([
      Message(
        id: "1",
        type: "sender",
        text: "Hey there!",
        timestamp: DateTime.parse("2023-08-22T10:30:00Z"),
      ),
      Message(
        id: "2",
        type: "receiver",
        text: "Hi! How are you?",
        timestamp: DateTime.parse("2023-08-22T10:32:00Z"),
      ),
      Message(
        id: "3",
        type: "sender",
        text: "I'm doing well, thanks!",
        timestamp: DateTime.parse("2023-08-22T10:35:00Z"),
      ),
      Message(
        id: "4",
        type: "receiver",
        text: "That's great to hear!",
        timestamp: DateTime.parse("2023-08-22T10:40:00Z"),
      ),
      Message(
        id: "3",
        type: "sender",
        text: "I'm doing well, thanks!",
        timestamp: DateTime.parse("2023-08-22T10:35:00Z"),
      ),
      Message(
        id: "4",
        type: "receiver",
        text: "That's great to hear!",
        timestamp: DateTime.parse("2023-08-22T10:40:00Z"),
      ),
      Message(
        id: "3",
        type: "sender",
        text: "I'm doing well, thanks!",
        timestamp: DateTime.parse("2023-08-22T10:35:00Z"),
      ),
      Message(
        id: "4",
        type: "receiver",
        text: "That's great to hear!",
        timestamp: DateTime.parse("2023-08-22T10:40:00Z"),
      ),
      Message(
        id: "3",
        type: "sender",
        text: "I'm doing well, thanks!",
        timestamp: DateTime.parse("2023-08-22T10:35:00Z"),
      ),
      Message(
        id: "4",
        type: "receiver",
        text: "That's great to hear!",
        timestamp: DateTime.parse("2023-08-22T10:40:00Z"),
      ),
      Message(
        id: "3",
        type: "sender",
        text: "I'm doing well, thanks!",
        timestamp: DateTime.parse("2023-08-22T10:35:00Z"),
      ),
      Message(
        id: "4",
        type: "receiver",
        text: "That's great to hear!",
        timestamp: DateTime.parse("2023-08-22T10:40:00Z"),
      ),
      Message(
        id: "3",
        type: "sender",
        text: "I'm doing well, thanks!",
        timestamp: DateTime.parse("2023-08-22T10:35:00Z"),
      ),
      Message(
        id: "4",
        type: "receiver",
        text: "That's great to hear!",
        timestamp: DateTime.parse("2023-08-22T10:40:00Z"),
      ),
      Message(
        id: "3",
        type: "sender",
        text: "I'm doing well, thanks!",
        timestamp: DateTime.parse("2023-08-22T10:35:00Z"),
      ),
      Message(
        id: "4",
        type: "receiver",
        text: "That's great to hear!",
        timestamp: DateTime.parse("2023-08-22T10:40:00Z"),
      ),
    ]);
  }
}
