import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:get/get.dart';

class InternetCheckController extends GetxController {
  RxBool hasInternet = true.obs;

  @override
  void onInit() {
    super.onInit();
    // Initial check when the controller is initialized
    checkInternetConnection();

    // Listen for changes in connectivity status
    Connectivity().onConnectivityChanged.listen((result) {
      checkInternetConnection();
    });
  }

  Future<void> checkInternetConnection() async {
    var connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult == ConnectivityResult.mobile ||
        connectivityResult == ConnectivityResult.wifi) {
      hasInternet.value = true;
    } else {
      hasInternet.value = false;
    }
  }
}
