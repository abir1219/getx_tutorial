import 'dart:async';

import 'package:MotivateU/models/reels_model.dart';
import 'package:MotivateU/repository/reels_repository.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart';

import '../main.dart';
import '../models/save_reels_seen_model.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class ReelsController extends GetxController {

  var _reelsRepo = ReelsRepository();

  Rx<ReelsModel> reelsData = ReelsModel().obs;
  // RxList<List<Result>>? _reelsList = <List<Result>>[].obs;
  // RxList<List<Result>>? reelsList = <List<Result>>[].obs;
  // RxList<ReelsModel> reelsData = <ReelsModel>[].obs;
  // List<ReelsModel> reelsData = [];
  Rx<SaveReelsSeenModel> saveReelsData = SaveReelsSeenModel().obs;
  Rx<bool> isLoading = false.obs;
  Rx<bool> isMoreLoading = false.obs;
  Rx<bool> correctAnswer = false.obs;
  Rx<bool> haveTime = true.obs;
  Rx<String> questionId = "".obs;


  RxInt index = (-1).obs;


  Rx<String> subjectId = "".obs;
  Rx<String> chapterId = "".obs;
  Rx<String> topicId = "".obs;
  RxList<String> keywordList = <String>[].obs;

  Timer? _timer;
  Timer? timerTrack;
  Rx<int> _counter = 0.obs;

  int get counter => _counter.value;

  Rx<int> counterTracker = 0.obs;
  Rx<int> leftTimeTracker = 0.obs;
  //int get counterTracker => _counterTracker.value;

  RxList<Result>? _reelsList = <Result>[].obs;
  RxList<Result>? reelsList = <Result>[].obs;

  RxMap<String, dynamic> socketData = <String, dynamic>{}.obs;

  void startTimer() {
    _timer = Timer.periodic(Duration(milliseconds: 1), (timer) {
      _counter.value++;
    });
  }

  void startTimerTrack() {
    debugPrint("--------Reels Pattern Start---------");
    // haveTime.value = true;
    // counterTracker.value = 0;
    timerTrack = Timer.periodic(Duration(seconds: 1), (timer) {
      // if(SharedPreferencesUtils.getInt(AppConstants.USED_TIME)! > counterTracker.value){
      if (haveTime.value) {
        if (SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! >= counterTracker.value) {
          debugPrint("REELS_counterTracker_Timer====>${counterTracker.value}");
          counterTracker.value += 1000;
        } else {
          haveTime.value = false;
          //timer.cancel(); // Stop the timer when haveTime.value becomes false
          debugPrint("<<<<<<<==Stop==>>>>>>>>>");
          stopTimerTrack();
        }
      } else {
        haveTime.value = false;
        timer.cancel(); // Stop the timer if haveTime.value is already false
        sendTimeTrack();
      }
    });
  }

  void stopTimerTrack() {
    debugPrint("--------Reels Pattern Stop---------");
    if (timerTrack != null && timerTrack!.isActive) {
      timerTrack!.cancel();
      debugPrint("HOTS_PATTERN_counterTracker_STOP====>${counterTracker.value}");
     sendTimeTrack();
      counterTracker.value = 0;
    }
  }

  Future<void> sendTimeTrack() async{
    debugPrint("--------Reels Pattern Send Track---------");
    Map<String,dynamic> body = {
      "profile" : SharedPreferencesUtils.getString(AppConstants.PROFILE_ID),
      // "question" : questionId,
      "question" : questionId.value,
      "time" : counterTracker.value
    };

    _reelsRepo.sendTimeTrack(body).then((value) {
      if(value['errMsg'] == false){
        // Utils.showToastMessage(value['message']);
        SharedPreferencesUtils.saveInt(AppConstants.LEFT_TIME,value['leftTime']);
      }
    }).onError((error, stackTrace) {
      debugPrint("TIME_TRACK_ERROR->$error");
    });
  }

  void stopTimer() {
    _timer?.cancel();
    _counter.value = 0;
  }


  @override
  void onClose() {
    stopTimer(); // Cancel the timer when the controller is closed to avoid memory leaks
    super.onClose();
  }


  Future<void> likeReels(var reelsId,Result result) async{
    _reelsRepo.likeReel(reelsId).then((value) {
      if(value['errMsg'] == false){
        // _connectionSocket();
        socket.emit('reel-action',reelsId);
        result.isLiked = !result.isLiked!;
        if(result.isDisliked!){
          result.isDisliked = false;
        }
      }
    }).onError((error, stackTrace) {
      debugPrint("Reels_Like=>$error");
      Utils.showToastMessage("Getting some error");
    });
  }

  Future<void> dislikeReels(var reelsId,Result result) async{
    _reelsRepo.dislikeReel(reelsId).then((value) {
      if(value['errMsg'] == false){
        // _connectionSocket();
        socket.emit('reel-action',reelsId);
        result.isDisliked = !result.isDisliked!;
        if(result.isLiked!){
          result.isLiked = false;
        }
      }
    }).onError((error, stackTrace) {
      debugPrint("Reels_Like=>$error");
      Utils.showToastMessage("Getting some error");
    });
  }

  _connectionSocket(){
    print("SOCket->${socket.connected}");
    socket.onConnect((data) => print("Connection Established"));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("SOCket->${socket.json.connected}");
  }

  Future<void> getReels(int pageNumber,[String? scenarioId]) async {
    reelsList!.clear();
    _reelsList!.clear();
    isLoading.value = true;
    debugPrint("scenarioId->${scenarioId}");

    Map<String, dynamic> body = {
      'subjectId': subjectId.value,
      'chapterId': chapterId.value,
      'topicId': topicId.value,
      'keywordList': keywordList,
      'scenario': scenarioId
    };

    debugPrint("getReels---->$body");

    _reelsRepo.getReels(pageNumber, body,scenarioId).then((value) {
      isLoading.value = false;

      // final List<ReelsModel> items = value.map((data) => ReelsModel.fromJson(value)).toList();
      // reelsData.assignAll(items);
      debugPrint("REELS_Length_1=>${reelsList!.length}");
      reelsData.value = ReelsModel.fromJson(value);
      _reelsList?.assignAll(List<Result>.generate(
          reelsData.value.result!.length,
              (index) => reelsData.value.result![index]));

      reelsList!.addAll(List<Result>.from(_reelsList!));
      debugPrint("REELS_Length_2=>${reelsList!.length}");
      // _reelsList?.assignAll(List<List<Result>>.generate(
      //     reelsData.value.result!.length,
      //         (index) => reelsData.value.result!));
      // reelsList!.addAll(List<List<Result>>.from(_reelsList!));
      // reelsData.addAll(value);
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("REELS_ERROR=>${error}");
    });
  }

  Future<void> getMoreReels(int pageNumber,[String? scenarioId]) async {
    // _reelsList!.clear();
    // reelsList!.clear();
    isMoreLoading.value = false;
    debugPrint("scenarioId->${scenarioId}");

    Map<String, dynamic> body = {
      'subjectId': subjectId.value,
      'chapterId': chapterId.value,
      'topicId': topicId.value,
      'keywordList': keywordList,
      'scenario': scenarioId
    };

    debugPrint("getMoreReels---->$body");

    _reelsRepo.getReels(pageNumber, body,scenarioId).then((value) {
      isMoreLoading.value = false;

      // final List<ReelsModel> items = value.map((data) => ReelsModel.fromJson(value)).toList();
      // reelsData.assignAll(items);
      debugPrint("More_REELS_Length_1=>${reelsList!.length}");
      reelsData.value = ReelsModel.fromJson(value);

      _reelsList?.assignAll(List<Result>.generate(
          reelsData.value.result!.length, (index) => reelsData.value.result![index]));

      reelsList!.addAll(List<Result>.from(_reelsList!));
      debugPrint("More_REELS_Length_2=>${reelsList!.length}");
      // _reelsList?.assignAll(List<List<Result>>.generate(
      //     reelsData.value.result!.length,
      //         (index) => reelsData.value.result!));
      // reelsList!.addAll(List<List<Result>>.from(_reelsList!));
      // reelsData.addAll(value);
    }).onError((error, stackTrace) {
      isMoreLoading.value = false;
      debugPrint("REELS_ERROR=>${error}");
    });
  }

  Future<void> reelsById(var questionId) async{
    isLoading.value = true;
    _reelsList!.clear();
    reelsList!.clear();
    _reelsRepo.viewReels(questionId).then((value) {
      isLoading.value = false;
      reelsData.value = ReelsModel.fromJson(value);
      _reelsList?.assignAll(List<Result>.generate(
          reelsData.value.result!.length,
              (index) => reelsData.value.result![index]));

      reelsList!.addAll(List<Result>.from(_reelsList!));
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("REELS_BY_ID_ERROR=>$error");
    });
  }

  Future<void> saveReelsForSeen() async {
    // Utils.showToastMessage("Counter : ${_counter.value}");
    await SharedPreferencesUtils.init();
    stopTimer();
    Map<String, dynamic> body = {
      'question': questionId.value,
      'duration': _counter.value,
      'profile' : SharedPreferencesUtils.getString(AppConstants.PROFILE_ID),
      'correctAnswer' : correctAnswer.value
    };
    _reelsRepo.saveSeenReels(body).then((value) {
      saveReelsData.value = SaveReelsSeenModel.fromJson(value);
      if (saveReelsData.value.errMsg == false) {
        _counter.value = 0;
      } else {
        Utils.showToastMessage(saveReelsData.value.message!);
        _counter.value = 0;
      }
    }).onError((error, stackTrace) {
      // Utils.showToastMessage(error.toString());
      _counter.value = 0;
      debugPrint(error.toString());
    });
  }
}
