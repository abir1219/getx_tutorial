import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionController extends GetxController {

  List<Permission> statuses = [
      Permission.camera,
      Permission.photos,
      Permission.notification
  ];


  @override
  void onInit() {
    super.onInit();
    // Initialize permission statuses
    resetPermissions();
  }

  Future<void> requestPermissions() async {
    // Map<Permission, PermissionStatus> statuses = await [
    //   Permission.camera,
    //   Permission.photos,
    // ].request();

    debugPrint("--statuses--${statuses}");
    Map<Permission, PermissionStatus> status = await statuses.request();
    debugPrint("--statuses.request--${status}");

    // statuses.request();

  }

  void resetPermissions() {
    statuses.forEach((permission) async {
      await permission.request(); // Explicitly request to reset to undetermined
    });
  }

  Future<bool> checkPermission() async{
    if (statuses[0] == PermissionStatus.granted &&
        statuses[1] == PermissionStatus.granted) {
      // Both permissions granted, you can proceed
      //Get.toNamed('/your_home_screen');

      return true;
    } else {
      // Handle the case when permissions are not granted
      //requestPermissions();
      // Get.snackbar(
      //   'Permission Denied',
      //   'Please grant camera and gallery permissions to use the app.',
      //   snackPosition: SnackPosition.BOTTOM,
      // );
      return false;
    }
  }
}
