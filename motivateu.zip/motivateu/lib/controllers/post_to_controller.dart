import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/connection_my_list_model.dart';
import '../repository/connection_my_list_repository.dart';

class PostToController extends GetxController {
  final myListRepo = ConnectionMyListRepository();
  RxBool isLoading = false.obs;
  RxBool isMoreLoading = false.obs;

  RxList<Connection>? _connectionList = <Connection>[].obs;

  // List<List<Connection>?> get connectionList => _connectionList;

  RxList<Connection>? connectionList = <Connection>[].obs;

  RxList<List<Group>?> _groupList = <List<Group>?>[].obs;

  List<List<Group>?> get groupList => _groupList;

  RxList<bool> myGroupSelection = <bool>[].obs;
  RxList<bool> myConnectionSelection = <bool>[].obs;

  RxList<String> myConnectionNameList = <String>[].obs;
  RxList<String> myConnectionIdList = <String>[].obs;

  RxList<String> myGroupNameList = <String>[].obs;
  RxList<String> myGroupIdList = <String>[].obs;

  Rx<TextEditingController> searchTextController = TextEditingController().obs;
  Rx<TextEditingController> postController = TextEditingController().obs;

  Rx<ConnectionMyListModel> myListModel = ConnectionMyListModel().obs;

  @override
  void onInit() {
    super.onInit();
    // _connectionList?.clear();
    // connectionList?.clear();
    // _groupList.clear();
    // groupList.clear();
  }

  void toggleGroupSelectionStatus(int position) {
    myGroupSelection[position] = !myGroupSelection[position];
  }

  void toggleConnectionSelectionStatus(int position) {
    myConnectionSelection[position] = !myConnectionSelection[position];
  }

  void toggleSelectedGroupList(int position) {
    //myGroupNameList
    myGroupNameList.contains(myListModel
            .value.connectionMyListModelReturn!.group![position].name)
        ? myGroupNameList.remove(myListModel
            .value.connectionMyListModelReturn!.group![position].name)
        : myGroupNameList.add(_groupList[0]![position].name);
    //myGroupIdList
    myGroupIdList.contains(
            myListModel.value.connectionMyListModelReturn!.group![position].id)
        ? myGroupIdList.remove(
            myListModel.value.connectionMyListModelReturn!.group![position].id)
        : myGroupIdList.add(_groupList[0]![position].id);
  }

  void toggleSelectedConnectionList(int position) {
    //myConnectionNameList
    /*myConnectionNameList.contains(myListModel.value.connectionMyListModelReturn!.connection![position].name)
        ? myConnectionNameList.remove(myListModel
            .value.connectionMyListModelReturn!.connection![position].name)
        : myConnectionNameList.add(_connectionList![position].name);*/

    myConnectionNameList.contains(connectionList![position].name)
        ? myConnectionNameList.remove(connectionList![position].name)
        : myConnectionNameList.add(connectionList![position].name);

    //myConnectionIdList
    /*myConnectionIdList.contains(myListModel
            .value.connectionMyListModelReturn!.connection![position].id)
        ? myConnectionIdList.remove(myListModel
            .value.connectionMyListModelReturn!.connection![position].id)
        : myConnectionIdList.add(_connectionList![position].id);*/

    myConnectionIdList.contains(connectionList![position].id)
        ? myConnectionIdList.remove(connectionList![position].id)
        : myConnectionIdList.add(connectionList![position].id);
  }

  Future<void> getConnectionMyList(var pageNo, var type) async {
    isLoading.value = true;
    myListRepo
        .getMyConnectionList(
            pageNumber: pageNo,
            type: type,
            searchName: searchTextController.value.text.toString())
        .then((value) {
      isLoading.value = false;
      myListModel.value = ConnectionMyListModel.fromJson(value);

      if (myListModel.value.connectionMyListModelReturn!.group!.length > 0) {
        debugPrint(
            "value['return']['group']=>${myListModel.value.connectionMyListModelReturn!.group!.length}");

        _groupList.assignAll(List<List<Group>>.generate(
            myListModel.value.connectionMyListModelReturn!.group!.length,
            (index) => myListModel.value.connectionMyListModelReturn!.group!));

        if (myGroupSelection.length == 0) {
          myGroupSelection.assignAll(List<bool>.generate(
              myListModel.value.connectionMyListModelReturn!.group!.length,
              (index) => false));
        }
      } else {
        _groupList.clear();
      }

      if (myListModel.value.connectionMyListModelReturn!.connection!.length >
          0) {
        debugPrint(
            "value['return']['connection']=>${myListModel.value.connectionMyListModelReturn!.connection!.length}");

        debugPrint(
            "myConnectionSelection.length==>${myConnectionSelection.length}");

        _connectionList?.assignAll(List<Connection>.generate(
            myListModel.value.connectionMyListModelReturn!.connection!.length,
            (index) => myListModel
                .value.connectionMyListModelReturn!.connection![index]));

        connectionList!.addAll(List<Connection>.from(_connectionList!));

        debugPrint("connectionList Length => ${connectionList!.length}");

        //_connectionList.add(myListModel.value.connectionMyListModelReturn!.connection);

        /*for(int i = connectionList!.length;i<=connectionList!.length+_connectionList!.length;i++){
          //_connectionList.add(myListModel.value.connectionMyListModelReturn!.connection);
          connectionList!.add(_connectionList![i]);
        }*/

        if (connectionList!.length > 0) {
          //myConnectionSelection.length == 0 &&
          debugPrint("---------------->>> ${connectionList!.length}");
          debugPrint("-------------->>> ${connectionList!.length}");

          //myConnectionSelection.addAll(List<bool>.from(connectionList!));

          /*for(int i=0;i<myConnectionSelection.length;i++){
              debugPrint("connectionList[index]--->${myConnectionSelection[i]}");
            }*/
          if (myConnectionSelection.length == 0) {
            myConnectionSelection.assignAll(
                List<bool>.generate(connectionList!.length, (index) => false));
          }
        } else {
          _connectionList!.clear();
        }
      }
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("CONNECTION_MY_LIST_ERROR=>$error");
    });
  }

  Future<void> getMoreConnectionMyList(var pageNo, var type) async {
    isMoreLoading.value = true;
    myListRepo
        .getMyConnectionList(
            pageNumber: pageNo,
            type: type,
            searchName: searchTextController.value.text.toString())
        .then((value) {
      isMoreLoading.value = false;
      myListModel.value = ConnectionMyListModel.fromJson(value);

      if (myListModel.value.connectionMyListModelReturn!.group!.length > 0) {
        debugPrint(
            "value['return']['group']=>${myListModel.value.connectionMyListModelReturn!.group!.length}");
        _groupList.assignAll(List<List<Group>>.generate(
            myListModel.value.connectionMyListModelReturn!.group!.length,
            (index) => myListModel.value.connectionMyListModelReturn!.group!));

        if (myGroupSelection.length == 0) {
          myGroupSelection.assignAll(List<bool>.generate(
              myListModel.value.connectionMyListModelReturn!.group!.length,
              (index) => false));
        }
      } else {
        _groupList.clear();
      }

      if (myListModel.value.connectionMyListModelReturn!.connection!.length >
          0) {
        debugPrint(
            "value['return']['connection']=>${myListModel.value.connectionMyListModelReturn!.connection!.length}");
        debugPrint(
            "myConnectionSelection.length==>${myConnectionSelection.length}");
        _connectionList?.assignAll(List<Connection>.generate(
            myListModel.value.connectionMyListModelReturn!.connection!.length,
            (index) => myListModel
                .value.connectionMyListModelReturn!.connection![index]));

        connectionList!.addAll(List<Connection>.from(_connectionList!));

        debugPrint("connectionList Length => ${connectionList!.length}");

        //_connectionList.add(myListModel.value.connectionMyListModelReturn!.connection);

        /*for(int i = connectionList!.length;i<=connectionList!.length+_connectionList!.length;i++){
          //_connectionList.add(myListModel.value.connectionMyListModelReturn!.connection);
          connectionList!.add(_connectionList![i]);
        }*/

        if (connectionList!.length > 0) {
          //myConnectionSelection.length == 0 &&
          debugPrint("---------------->>> ${connectionList!.length}");
          debugPrint("<<------------->>> ${myConnectionSelection.length}");
          // for(int i=0;i<myConnectionSelection.length;i++){
          //   debugPrint("<<<------->>> ${myConnectionSelection[i]}");
          // }
          // myConnectionSelection.clear();

          //myConnectionSelection.addAll(List<bool>.from(connectionList!));
          if (myConnectionSelection.length > 0) {
            //myConnectionSelection.clear();
            // myConnectionSelection.assignAll(
            //     List<bool>.generate(connectionList!.length, (index) => false));
            for(int i = connectionList!.length; i<connectionList!.length+myListModel.value.connectionMyListModelReturn!.connection!.length;i++){
              myConnectionSelection.add(false);
            }

            debugPrint("<<-------new------>>> ${myConnectionSelection.length}");
         }
        }
      } else {
        _connectionList!.clear();
      }
    }).onError((error, stackTrace) {
      isMoreLoading.value = false;
      debugPrint("CONNECTION_MY_LIST_ERROR=>$error");
    });
  }

  Future<void> addPost(String questionId, String type) async {
    isLoading.value = true;
    Map<String, dynamic> body = {};
    if(type == "reel"){
      body={
        'groups': myGroupIdList,
        'connections': myConnectionIdList,
        'question' : questionId
      };
    }else if(type == "post"){
      body={
        'postContent': postController.value.text.toString(),
        'groups': myGroupIdList,
        'connections': myConnectionIdList
      };
    }

    myListRepo.addPost(body,type).then((value) {
      if (value['errMsg'] == false) {
        Utils.showToastMessage(value['message']);
        // Get.offNamed(AppRoutes.dashboard, arguments: [3]);
        Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'3'});
        postController.value.text = "";
      } else {
        Utils.showToastMessage(value['message']);
      }
      isLoading.value = false;
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("ADD_POST_ERROR=>$error");
    });
  }


  void clearData() {
    //Utils.showToastMessage("clear");
    myConnectionSelection.clear();
    myGroupSelection.clear();
    myGroupNameList.clear();
    myConnectionNameList.clear();
    myConnectionIdList.clear();
    myGroupIdList.clear();
    postController.value.text = "";

    /*RxList<bool> myGroupSelection = <bool>[].obs;
    RxList<bool> myConnectionSelection = <bool>[].obs;

    RxList<String> myConnectionNameList = <String>[].obs;
    RxList<String> myConnectionIdList = <String>[].obs;

    RxList<String> myGroupNameList = <String>[].obs;
    RxList<String> myGroupIdList = <String>[].obs;*/
  }
}
