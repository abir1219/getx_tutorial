import 'package:MotivateU/helper/api_end_points.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

import '../models/get_comments_model.dart';
import '../repository/comment_repository.dart';

class CommentController extends GetxController {
  final _commentRepo = CommentRepository();
  Rx<GetCommentsModel> getCommentsModel = GetCommentsModel().obs;

  RxBool isCommentsLoading = false.obs;

  Rx<TextEditingController> commentController = TextEditingController().obs;

  RxString commentType = "main".obs;
  RxString commentId = "".obs;
  RxString tagged_user_id = "".obs;
  RxString tagged_username = "".obs;

  void addUserName(String name){
    tagged_username.value = name+"  ";
    commentController.value.text = "${tagged_username.value}";
  }

// Initialize Socket.io connection
  final socket = io.io(ApiEndPoints.baseUrl);

  @override
  void onInit() {
    super.onInit();

    // Handle incoming events
    socket.on('connect', (_) {
      print('Connected to Socket.io');
    });

    socket.on('newComment', (data) {});
  }

  Future<void> deletePostComment(var commentId,void Function() func) async{
    debugPrint("commentId=>$commentId");
    _commentRepo.deleteComments(commentId).then((value) {
      debugPrint("value-------->${value}");
      if(value['errMsg']==false) {
        func();
        Utils.showToastMessage("${value['message']}");

      }else{
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace) {
      debugPrint("DELETE_COMMENT_ERROR,$error");
      Utils.showToastMessage(error.toString());
    });

  }

  Future<void> deleteReelsComment(var commentId,void Function() func) async{
    debugPrint("commentId=>$commentId");
    _commentRepo.deleteComments(commentId).then((value) {
      debugPrint("value-------->${value}");
      if(value['errMsg']==false) {
        func();
        Utils.showToastMessage("${value['message']}");
      }else{
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace) {
      debugPrint("DELETE_COMMENT_ERROR,$error");
      Utils.showToastMessage(error.toString());
    });

  }

  Future<void> getComments(var questionId) async {
    isCommentsLoading.value = true;
    debugPrint("questionId=>$questionId");
    commentType.value = "main";
    commentId.value = "";
    tagged_user_id.value = "";
    commentController.value.text="";
    tagged_username.value = "";
    _commentRepo.getComments(questionId).then((value) {
      isCommentsLoading.value = false;
      getCommentsModel.value = GetCommentsModel.fromJson(value);
      if (getCommentsModel.value.errMsg == false) {
        debugPrint("GET_COMMENTS_MESSAGE->${getCommentsModel.value.message!}");
        commentType.value = "main";
      } else {
        Utils.showToastMessage(getCommentsModel.value.message!);
      }
    }).onError((error, stackTrace) {
      isCommentsLoading.value = false;
      debugPrint("GET_COMMENTS_ERROR->$error");
      Utils.showToastMessage(error.toString());
    });
  }

  Future<void> postComment(String questionId, String comment) async {

    debugPrint("question_id=>${questionId}\ncomment=>$comment\ncomment_type=>${commentType.value}\ncomment_id=>${commentId.value}\ntagged_user_id=>${tagged_user_id}");

    Map<String, dynamic> body = {};

    String originalString = 'Abir Chanda abcd message sdlkfjlskdfj';
    String substringToRemove = tagged_username.value;

    debugPrint("tagged_username.value->${tagged_username.value}");

    comment = comment.replaceAll(tagged_username.value, '');

    debugPrint("COMMENT->$comment");

    if(commentType.value=="inner"){
      body = {
        "question_id": questionId,
        "comment": comment,
        "comment_type": commentType.value,
        "comment_id": commentId.value,
        "tagged_user_id": tagged_user_id.value
      };
    }else if(commentType.value=="main"){
      body = {
        "question_id": questionId,
        "comment": comment,
        "comment_type": commentType.value,
      };
    }
    debugPrint("POST_COMMENT_BODY=>$body");

    _commentRepo.postComments(body).then((value){
      if(value['errMsg']==false){
        getComments(questionId);
        commentType.value = "main";
        commentId.value = "";
        tagged_user_id.value = "";
        commentController.value.text = "";
        tagged_username.value = "";
        _connectionSocket();
        socket.emit('reel-action',questionId);
      }else{
        debugPrint("POST_COMMENTS_FALSE=>${value['message']}");
        Utils.showToastMessage("${value['message']}");
      }
    }).onError((error, stackTrace){
      debugPrint("POST_COMMENTS_ERROR=>$error}");
      Utils.showToastMessage("$error");
    });
  }

  _connectionSocket(){
    print("SOCket->${socket.connected}");
    socket.onConnect((data) => print("Connection Established"));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("SOCket->${socket.json.connected}");
  }

}
