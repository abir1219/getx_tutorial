
import 'dart:convert';

import 'package:MotivateU/controllers/otp_controller.dart';
import 'package:MotivateU/repository/login_repository.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';
import '../main.dart';
import '../models/login_model.dart';
import '../models/send_otp_model.dart';
import '../models/time_tracker_model.dart';
import '../repository/otp_repository.dart';
import '../res/routes/app_routes.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class LoginController extends GetxController {
  final _loginRepo = LoginRepository();
  Rx<LoginModel> loginData = LoginModel().obs;

  final _otpRepository = OtpRepository();
  Rx<SendOtpModel> sendOtpData = SendOtpModel().obs;

  //GetConnect implements
  RxBool isRemembered = false.obs;

  Rx<TextEditingController> phoneController = TextEditingController().obs;
  Rx<TextEditingController> passwordController = TextEditingController().obs;

  Rx<FocusNode> phoneFocusNode = FocusNode().obs;
  Rx<FocusNode> passwordFocusNode = FocusNode().obs;


  Rx<bool> isPasswordVisible = false.obs;

  Rx<bool> isLoading = false.obs;

  Future<void> checkIfRemembered() async{
    await SharedPreferencesUtils.init();
    if(SharedPreferencesUtils.containsKey(AppConstants.isREMEMBERED))
      isRemembered.value = true;

    if(SharedPreferencesUtils.containsKey(AppConstants.PHONE_NUMBER))
      phoneController.value.text = SharedPreferencesUtils.getString(AppConstants.PHONE_NUMBER)!;

    if(SharedPreferencesUtils.containsKey(AppConstants.PASSWORD))
      passwordController.value.text = SharedPreferencesUtils.getString(AppConstants.PASSWORD)!;
  }

  Future<void> login() async {
    isLoading.value = true;

    try {
      // String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.login;
      // debugPrint("LOGIN_URL======>$url");

      Map<String, dynamic> body = {
        'phone': phoneController.value.text.trim(),
        'password': base64Encode(utf8.encode(passwordController.value.text))
      };

      _loginRepo
          .loginApi(body)
          .then((value) async {
            //debugPrint("LOGIN_VALUE->${value['errMsg']}");
        loginData.value = LoginModel.fromJson(value) ;
        isRemembered.value?saveData():clearData();
        await SharedPreferencesUtils.init();
        SharedPreferencesUtils.saveString(AppConstants.LOGIN_TIME, DateTime.now().toString());
        SharedPreferencesUtils.saveString(AppConstants.ACCESS_TOKEN, loginData.value.accessToken.toString());
        SharedPreferencesUtils.saveString(AppConstants.REFRESH_TOKEN, loginData.value.refreshToken.toString());
        SharedPreferencesUtils.saveString(AppConstants.REFERRAL_NO, loginData.value.myReferralCode??"");
        SharedPreferencesUtils.saveString(AppConstants.PROFILE_ID, loginData.value.profile![0].id!);
        debugPrint("LOGIN_statusCode======>$value");
        _connectionSocket();
        socket.emit('connected-student',loginData.value.profile![0].id!);
        // Get.offNamed(AppRoutes.dashboard,arguments: [0]);
        Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex': '0'});
        // if (kDebugMode) alice.onHttpResponse(value);
        // if (kDebugMode) alice.showInspector();
        isLoading.value = false;
        getTimeApiCall();
        addFCM();
      })
          .onError((error, stackTrace) {
        // if (kDebugMode) alice.showInspector();
            Utils.showToastMessage("${error.toString()}");
            isLoading.value = false;
      });

      // var response = await post(url,jsonEncode(body));
      /*var response = await post(Uri.parse(url), body: jsonEncode(body));
      debugPrint("LOGIN_RESPONSE======>${response.body}");
      debugPrint("LOGIN_statusCode======>${response.statusCode}");
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        debugPrint("Login RES => $json");
      } else {
        //throw jsonDecode(response.body)["message"] ?? "Unknown Error Occurred";
        //Get.snackbar("Login Failed", "",snackPosition: SnackPosition.BOTTOM);
      }*/
    } catch (error) {
      debugPrint("ERROR======>$error");
      isLoading.value = false;
      Get.back();
    }
  }

  Future<void> addFCM() async{
    Map<String,dynamic> body = {
      'profile': '${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}',
      'fcm': '${SharedPreferencesUtils.getString(AppConstants.TOKEN)}',
    };
    try{
      _loginRepo.addFcm(body);
    }catch(e){
      debugPrint("Failed to add fcm Token with the profile");
    }
  }

  _connectionSocket(){
    print("Socket Start->${socket.connected}");
    socket.onConnect((data) => print("Connection Established LOIN"));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("Socket After->${socket.json.connected}");
  }


  Future<void> sendOtp() async {
    Map<String, dynamic> body = {
      'phone': phoneController.value.text.toString().trim(),
    };

    _otpRepository.sendOtp(body).then(
          (value) {
        sendOtpData.value = SendOtpModel.fromJson(value);
        if(sendOtpData.value.errMsg == false) {
          Get.put(OtpController()).phController.value.text = phoneController.value.text.trim().toString();
          Get.toNamed(AppRoutes.otp,
              arguments: [phoneController.value.text.trim().toString(),'login']);
        }
      },
    ).onError(
          (error, stackTrace) {
        debugPrint("SEND_OTP_ERROR====>${error}");
      },
    );
  }

  void saveData() async{
    await SharedPreferencesUtils.init();
    SharedPreferencesUtils.saveString(AppConstants.PHONE_NUMBER, Get.find<LoginController>().phoneController.value.text.toString());
    SharedPreferencesUtils.saveString(AppConstants.PASSWORD, Get.find<LoginController>().passwordController.value.text.toString());
    SharedPreferencesUtils.saveBool(AppConstants.isREMEMBERED, true);
  }

  void clearData() async{
    await SharedPreferencesUtils.init();
    SharedPreferencesUtils.remove(AppConstants.PHONE_NUMBER,);
    SharedPreferencesUtils.remove(AppConstants.PASSWORD);
    SharedPreferencesUtils.remove(AppConstants.isREMEMBERED);
  }

}
