import 'dart:io';

import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../main.dart';
import '../models/add_profile_model.dart';
import '../models/board_model.dart';
import '../models/class_model.dart';
import '../models/medium_model.dart';
import '../models/school_model.dart';
import '../repository/add_profile_repository.dart';
import '../repository/signup_repository.dart';

class AddProfileController extends GetxController{
  final repo = SignupRepository();
  final addProfileRepo = AddProfileRepository();

  Rx<ClassModel> classData = ClassModel().obs;
  Rx<MediumModel> mediumData = MediumModel().obs;
  Rx<BoardModel> boardData = BoardModel().obs;
  Rx<SchoolModel> schoolData = SchoolModel().obs;
  Rx<AddProfileModel> addProfileModel = AddProfileModel().obs;

  Rx<File?> imageFile = Rx<File?>(null);

  Rx<bool> isLoading = false.obs;

  Rx<bool> isSelectClass = false.obs;
  Rx<bool> isSelectSchool = false.obs;
  Rx<bool> isSelectOtherSchool = false.obs;
  Rx<bool> isSelectMedium = false.obs;
  Rx<bool> isSelectBoard = false.obs;
  Rx<bool> isSelectGroup = false.obs;

  Rx<String> classId = "".obs;
  Rx<String> mediumId = "".obs;
  Rx<String> boardId = "".obs;
  Rx<String> schoolId = "".obs;

  Rx<TextEditingController> nameController = TextEditingController().obs;
  Rx<TextEditingController> authPinController = TextEditingController().obs;
  Rx<TextEditingController> classController = TextEditingController().obs;
  Rx<TextEditingController> schoolController = TextEditingController().obs;
  Rx<TextEditingController> otherSchoolController = TextEditingController().obs;
  Rx<TextEditingController> mediumController = TextEditingController().obs;
  Rx<TextEditingController> boardController = TextEditingController().obs;

  Future<void> getClass() async {
    repo.getClass().then(
          (value) {
        classData.value = ClassModel.fromJson(value);
        debugPrint("classData_type=>${classData.runtimeType}");

        debugPrint("CLASS_RES====>${classData.value.result![0].sId}");
        debugPrint("CLASS_RES_TYPE====>${value.runtimeType}");
      },
    ).onError(
          (error, stackTrace) {
        debugPrint("CLASS_ERROR====>${error}");
      },
    );
  }

  void updateImageFile(File newFile) {
    imageFile.value = newFile;
  }

  Future<void> getMedium() async {
    repo.getMedium().then(
          (value) {
        mediumData.value = MediumModel.fromJson(value);
        debugPrint("mediumData_type=>${mediumData.runtimeType}");

        debugPrint("MEDIUM_RES====>${mediumData.value.result![0].id}");
        debugPrint("MEDIUM_RES_TYPE====>${value.runtimeType}");
        // if (kDebugMode) alice.onHttpResponse(value);
        // if (kDebugMode) alice.showInspector();
      },
    ).onError(
          (error, stackTrace) {
        debugPrint("MEDIUM_ERROR====>${error}");
        if (kDebugMode) alice.showInspector();
      },
    );
  }

  Future<void> getBoard() async {
    repo.getBoard().then(
          (value) {
        boardData.value = BoardModel.fromJson(value);
        debugPrint("boardData_type=>${boardData.runtimeType}");

        debugPrint("BOARD_RES====>${boardData.value.result![0].id}");
        debugPrint("BOARD_RES_TYPE====>${value.runtimeType}");
        // if (kDebugMode) alice.onHttpResponse(value);
        // if (kDebugMode) alice.showInspector();
      },
    ).onError(
          (error, stackTrace) {
        debugPrint("BOARD_ERROR====>${error}");
        if (kDebugMode) alice.showInspector();
      },
    );
  }

  Future<void> getSchool() async {
    repo.getSchool().then(
          (value) {
        schoolData.value = SchoolModel.fromJson(value);
        debugPrint("SchoolData_type=>${schoolData.runtimeType}");

        debugPrint("SCHOOL_RES====>${schoolData.value.result![0].id}");
        debugPrint("SCHOOL_RES_TYPE====>${value.runtimeType}");
        // if (kDebugMode) alice.onHttpResponse(value);
        // if (kDebugMode) alice.showInspector();
      },
    ).onError(
          (error, stackTrace) {
        debugPrint("SCHOOL_ERROR====>${error}");
        if (kDebugMode) alice.showInspector();
      },
    );
  }


  Future<void> addProfile() async{
    isLoading.value = true;
    Map<String,dynamic> body = {
      'name' : nameController.value.text.toString(),
      'std' : classId.value,
      'medium' : mediumId.value,
      'school' : schoolController.value.text.toString(),
      'board' : boardId.value,
      'pin' : authPinController.value.text.toString(),
      'groupCreation' : isSelectGroup.value,
    };

    addProfileRepo.addProfile(body).then((value) {
      isLoading.value = false;
      addProfileModel.value = AddProfileModel.fromJson(value);
      if(addProfileModel.value.errMsg == false){
        if(imageFile.value != null){
          addProfileRepo.profileUpload(addProfileModel.value.result!.id!, imageFile.value!);
          /*debugPrint("UPLOAD_AVATAR=>$result");
          if(result== false){
            Utils.showToastMessage("Image upload failed");
          }else{
            doneData();
          }*/
          doneData();
        }else{
          doneData();
        }
      }else{
        Utils.showToastMessage(addProfileModel.value.message!);
      }
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("ADD_PROFILE_ERROR->$error");
    });
  }


  void doneData(){
    Utils.showToastMessage(addProfileModel.value.message!);
    nameController.value.text = "";
    schoolController.value.text = "";
    authPinController.value.text = "";
    classController.value.text = "";
    boardController.value.text = "";
    mediumController.value.text = "";
    classId.value = "";
    mediumId.value = "";
    boardId.value = "";
    isSelectGroup.value = false;
    isSelectClass.value = false;
    isSelectSchool.value = false;
    isSelectOtherSchool.value = false;
    isSelectMedium.value = false;
    isSelectBoard.value = false;
    imageFile.value = null;
    // Get.back();
    Get.toNamed(AppRoutes.dashboard,arguments: [4]);
  }
}