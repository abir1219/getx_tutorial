import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/forget_pw_model.dart';
import '../repository/forgot_pw_repository.dart';
import '../utils/utils.dart';

class ForgetPwController extends GetxController {
  final forgetPwRepo = ForgotPwRepository();
  RxBool isLoading = false.obs;


  Rx<bool> isPasswordVisible = false.obs;
  Rx<bool> isCnfrmPasswordVisible = false.obs;


  Rx<ForgetPwModel> forgetPwData = ForgetPwModel().obs;
  Rx<TextEditingController> newPwController = TextEditingController().obs;
  Rx<TextEditingController> retypePwController = TextEditingController().obs;

  Future<void> updatePw() async {
    isLoading.value = true;
    Map<String, dynamic> body = {
      'password': newPwController.value.text.toString().trim(),
    };

    forgetPwRepo.UpdatePwApi(body).then((value) {
      isLoading.value = false;
      forgetPwData.value = ForgetPwModel.fromJson(value);
      if (forgetPwData.value.errMsg == false) {
        Utils.showToastMessage(forgetPwData.value.message.toString());
        Get.offNamed(AppRoutes.login);
      } else {
        Utils.showToastMessage(forgetPwData.value.message.toString());
      }
    }).onError((error, stackTrace) {
      isLoading.value = false;
      Utils.showToastMessage("ERROR: ${error.toString()}");
    });
  }
}
