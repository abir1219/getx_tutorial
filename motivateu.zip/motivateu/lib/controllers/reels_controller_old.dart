import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/reels_model_old.dart';

class ReelsControllerOld extends GetxService {
  RxInt correctAnswerIndex = RxInt(-1);
  RxInt selectedAnswerIndex = RxInt(-1);

  RxBool isSelect = false.obs;


  final List<ReelsModelOld> _reels = <ReelsModelOld>[].obs;

  List<ReelsModelOld> get reels => _reels;

  void loadReels() {
    List<Map<String, dynamic>> jsonData = [
      {
        "reels_type": "descriptive",
        "reel_url": [
          "https://assets.mixkit.co/videos/preview/mixkit-mother-with-her-little-daughter-eating-a-marshmallow-in-nature-39764-large.mp4"
        ],
        "reels_question": "",
        "reel_options": [],
        "correct_answer": -1
      },
      {
        "reels_type": "short",
        "reel_url": [
          "https://wallpapercave.com/wp/wp3246752.jpg",
          "https://wallpapercave.com/wp/wp3246751.jpg"
        ],
        "reels_question": "",
        "reel_options": [],
        "correct_answer": -1
      },
      {
        "reels_type": "mcq",
        "reel_url": [
          "https://images.pexels.com/photos/3290065/pexels-photo-3290065.jpeg?auto=compress&cs=tinysrgb&w=600"
        ],
        "reels_question": "What is the capital of France?",
        "reel_options": [
          "Berlin", "Paris", "London", "Madrid"],
        "correct_answer": 1
      },
    ];

    _reels.assignAll(jsonData.map((json) {
      return ReelsModelOld(
          reelsType: json['reels_type'],
          reelUrls: List<String>.from(json['reel_url']),
          reelsQuestion: json['reels_question'],
          reelOptions: List<String>.from(json['reel_options']),
          correctAnswer: json['correct_answer']);
    }));
  }

  void setCorrectAnswer(int index) {
    correctAnswerIndex.value = index;
  }

  void setSelectedAnswer(int index) {
    selectedAnswerIndex.value = index;
  }


  bool checkAnswer(
      {required int currentQuestionIndex, required int selectedOptionIndex}) {
    //debugPrint("------Checked------${reels[currentQuestionIndex].reelOptions![selectedOptionIndex]} & ${reels[currentQuestionIndex].reelOptions![_reels[currentQuestionIndex].correctAnswer!]}");
    if (_reels[currentQuestionIndex].reelOptions![selectedOptionIndex] ==
        reels[currentQuestionIndex].reelOptions![_reels[currentQuestionIndex].correctAnswer!]) {
      // debugPrint("INSIDE IF");
      // _reels[currentQuestionIndex].answeredCorrectly = true;
      correctAnswerIndex.value = _reels[currentQuestionIndex].correctAnswer!;
      selectedAnswerIndex.value = selectedOptionIndex;
      debugPrint("CorrectOption--->${correctAnswerIndex.value}");
      return true;
    }
    return false;

    // debugPrint("Your ans is : ${_reels[currentQuestionIndex].answeredCorrectly}");
  }
}
