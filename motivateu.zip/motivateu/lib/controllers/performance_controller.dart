import 'package:MotivateU/models/dashboard_model.dart';
import 'package:MotivateU/repository/dashboard_repository.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/dashboard_details_model.dart';
import '../models/terms_condition_model.dart';

class PerformanceController extends GetxController {
  var _repo = DashboardRepository();
  RxBool isLoading = false.obs;
  RxBool isAnotherLoading = false.obs;
  Rx<DashboardModel> dashboardModel = DashboardModel().obs;
  late Rx<DashboardDetailsModel> dashboardDetailsModel;

  Rx<TermsConditionModel> tncData = TermsConditionModel().obs;

  RxList<Results>? MCQList = <Results>[].obs;
  RxList<Results>? OthersList = <Results>[].obs;

  Rx<int> mcqCount = 0.obs;
  Rx<int> othersCount = 0.obs;

  Future<void> getDashboardData() async {
    isLoading.value = true;
    _repo.getDashboardData().then((value) {
      isLoading.value = false;
      dashboardModel.value = DashboardModel.fromJson(value);

      // for(int i = 0;i<dashboardDetailsModel.value.result!.length; i++){
      /*if(dashboardDetailsModel.value.result![i].sId!.contains("MCQ")){
          mcqCount.value = mcqCount.value + 1;
        }else{
          othersCount.value = othersCount.value + 1;
        }*/
      // }
    }).onError((error, stackTrace) {
      isLoading.value = false;
      Utils.showToastMessage("Getting some troubles");
    });
  }

  Future<void> checkTnC(void Function() func) async {
    _repo.checkTnC().then((value) {
      tncData.value = TermsConditionModel.fromJson(value);
      func();
      // tncData.value.acceptTermsAndCondition == false ? func : null;
    }).onError((error, stackTrace) {});
  }

  Future<void> getDashboardDetailsData(var subjectId) async {
    MCQList!.clear();
    OthersList!.clear();
    dashboardDetailsModel = DashboardDetailsModel().obs;
    isAnotherLoading.value = true;
    _repo.getDashboardDetailsData(subjectId).then((value) {
      isAnotherLoading.value = false;
      dashboardDetailsModel.value = DashboardDetailsModel.fromJson(value);
      dashboardDetailsModel.value.result!.forEach((item) {
        debugPrint("MCQ:::${item.sId!.contains("MCQ")}");
        if (item.sId!.contains("MCQ")) {
          mcqCount.value += 1;
          MCQList!.add(item);
        } else {
          othersCount.value += 1;
          OthersList!.add(item);
        }
      });
    }).onError((error, stackTrace) {
      isAnotherLoading.value = false;
      Utils.showToastMessage("Getting some troubles");
    });
  }
}
