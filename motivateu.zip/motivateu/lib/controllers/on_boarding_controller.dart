import 'package:get/get.dart';

class OnBoardingController extends GetxController{
  Rx<int> index = 0.obs;

  void changeIndex(int position) {
    index.value = position;
  }
}