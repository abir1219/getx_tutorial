import 'package:MotivateU/controllers/get_profile_controller.dart';
import 'package:MotivateU/models/get_profile_model.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:get/get.dart';

import '../repository/verify_pin_repository.dart';

class VerifyPinController extends GetxController{
  final repo = VerifyPinRepository();
  RxBool isLoading = false.obs;

  Future<void> verifyAuthPin(String pin,int position,Result result) async{
    isLoading.value = true;
    await SharedPreferencesUtils.init();
    Map<String,dynamic> body = {
      'profile':SharedPreferencesUtils.getString(AppConstants.PROFILE_ID),
      'pin':pin,
    };
    repo.verifyAuthPin(body).then((value) {
      if(value['errMsg']==false){
        Utils.showToastMessage(value['message']);
        SharedPreferencesUtils.saveString(
            AppConstants.PROFILE_ID,
            position == 0
                ? result.profile![position + 1].sId!
                : result.profile![position - 1].sId!);
        // Get.find<GetProfileController>().changeProfileId(position);
      }else{
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace){

    });
  }
}