import 'package:MotivateU/models/get_profile_model.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';
import '../main.dart';
import '../models/time_tracker_model.dart';
import '../repository/profile_repository.dart';
import '../repository/verify_pin_repository.dart';
import '../screens/verify_auth_pin.dart';
import '../utils/utils.dart';

import 'package:socket_io_client/socket_io_client.dart' as IO;

class GetProfileController extends GetxController{
  final getProfileRepo = ProfileRepository();
  final repo = VerifyPinRepository();

  Rx<GetProfileModel> getProfileModel = GetProfileModel().obs;
  RxBool isLoading = false.obs;

  RxString PROFILE = "".obs;
  RxInt position = 0.obs;

  RxBool isVerifyLoading = false.obs;

  RxBool isVerified = false.obs;

  RxBool isShowChangePinScreen = false.obs;

  // late IO.Socket _socket;
  /*IO.Socket _socket = IO.io('http://192.168.1.184:5007', {
  // _socket = IO.io('https://api.motivateuedutech.com',{
  'transports': ['websocket'],
  // 'transport': ['websocket','polling'],
  'timeout': 5000, // set a timeout in milliseconds
  });*/



  /*void changeProfileId([int? pos]) async{
    if(pos!=null){
      position.value = pos;
    }
    PROFILE.value = SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!;
  }*/



  @override
  void onInit() async{
    super.onInit();
    debugPrint("sjowjpejer");
    await SharedPreferencesUtils.init();
    // changeProfileId();
    PROFILE.value = SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!;
    getProfile();
  }

  void changeVerificationStatus(){
    isVerified.value = true;
  }


  Future<void> getProfile() async{
    isLoading.value = true;
    getProfileRepo.getProfile().then((value) {
      isLoading.value = false;
      getProfileModel.value = GetProfileModel.fromJson(value);
      if(getProfileModel.value.errMsg== false){

      }
    }).onError((error, stackTrace) {
      isLoading.value = false;
    });
  }

  Future<void> verifyAuthPin(String pin,int? pos,Result? result, String type) async{
    position.value = pos??0;
    isVerifyLoading.value = true;
    await SharedPreferencesUtils.init();
    Map<String,dynamic> body = {
      'profile':type == 'switch'?SharedPreferencesUtils.getString(AppConstants.ANOTHER_PROFILE_ID):PROFILE.value,
      'pin':pin,
    };
    repo.verifyAuthPin(body).then((value) {
      isVerifyLoading.value = false;
      if(value['errMsg']==false){
        if(type == 'switch'){
          debugPrint("Type=>$type and Position=>$pos");
          Utils.showToastMessage(value['message']);
          SharedPreferencesUtils.saveString(
              AppConstants.PROFILE_ID,
              pos == 0 ? result!.profile![pos! + 1].sId! : result!.profile![pos! - 1].sId!);
          debugPrint("PROFILE_ID=>${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}");
          Get.back(result: true);
          PROFILE.value = SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!;
          getProfile();
          getTimeApiCall(PROFILE.value);
          if(socket.connected)
            socket.io.disconnect();
          _connectionSocket();
          addFCM();

        }else if(type == 'change'){
          debugPrint("CHANGE");
          isShowChangePinScreen.value = true;
          // showChangePinDialog();
          VerifyAuthPin();
        }
        //Get.find<GetProfileController>().changeProfileId(position);
      }else{
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace){
      isVerifyLoading.value = false;
      debugPrint("VERIFY_PIN_ERROR->$error");
      Utils.showToastMessage("$error");
    });

  }

  Future<void> addFCM() async{
    Map<String,dynamic> body = {
      'profile': '${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}',
      'fcm': '${SharedPreferencesUtils.getString(AppConstants.TOKEN)}',
    };
    try{
      repo.addFcm(body);
    }catch(e){
      debugPrint("Failed to add fcm Token with the profile");
    }
  }

  Future<void> getTimeApiCall(String profileId) async{
    SharedPreferencesUtils.init();
    debugPrint("----Profile LEFT TIME MAIN---- ${SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)}");
    TimeTrackerModel model = TimeTrackerModel();
    final _apiClient = NetworkApiServices();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.GET_FREE_MINUTES+"/${profileId}";
    _apiClient.getApi(url).then((value) {
      debugPrint(".........Profile call getTimeApiCall response.........\n${value}");
      model = TimeTrackerModel.fromJson(value);
      if(!model.subscribed!){
        SharedPreferencesUtils.saveInt(AppConstants.LEFT_TIME, model.leftTime!);
        SharedPreferencesUtils.saveInt(AppConstants.USED_TIME, model.usedTime!);
        SharedPreferencesUtils.saveBool(AppConstants.isSUBSCRIBED, model.subscribed!);
      }else{
        SharedPreferencesUtils.saveBool(AppConstants.isSUBSCRIBED, model.subscribed!);
      }

      debugPrint(".........Profile call getTimeApiCall leftTime.........\n${model.leftTime}");
    });
  }

  Future<void> changePin(String pin) async{
    isVerifyLoading.value = true;
    await SharedPreferencesUtils.init();
    Map<String,dynamic> body = {
      'profile' : SharedPreferencesUtils.getString(AppConstants.PROFILE_ID),
      'pin' : pin
    };
    repo.changeAuthPin(body).then((value) {
      isShowChangePinScreen.value = false;
      isVerifyLoading.value = false;
      Utils.showToastMessage("Pin change successful");
      Get.back(result: true);
      getProfile();
    }).onError((error, stackTrace) {
      isVerifyLoading.value = false;
      debugPrint("CHANGE_PIN_ERROR->$error");
    });
  }

  @override
  void onClose() {
    isLoading.value = false;
  }

  _connectionSocket(){
    print("SOCket->${socket.connected}");
    socket.io.connect();
    socket.onConnect((data) => print("Connection Established Profile"));
    socket.emit('connected-student',SharedPreferencesUtils.getString(AppConstants.PROFILE_ID));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("SOCket->${socket.json.connected}");
    //_socket.io..disconnect()..connect();
    print("SOCket->${socket.json.connected}");
    print("Socket Connected: ${socket.connected}");
  }
}

