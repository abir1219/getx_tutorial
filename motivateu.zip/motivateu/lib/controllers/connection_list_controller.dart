import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/connection_model.dart';
import '../models/sent_pending_model.dart';
import '../repository/connection_list_repository.dart';

class ConnectionListController extends GetxController{
  final repo = ConnectionListRepository();

  RxBool isLoading = false.obs;
  RxBool isMoreLoading = false.obs;
  RxBool isActionLoading = false.obs;

  Rx<TextEditingController> searchTextController = TextEditingController().obs;

  Rx<ConnectionModel> myListModel = ConnectionModel().obs;
  Rx<SentPendingModel> sentPendingModel = SentPendingModel().obs;

  RxList<Results>? _sentPendingList = <Results>[].obs;
  RxList<Results>? sentPendingList = <Results>[].obs;

  RxList<Result>? _connectionList = <Result>[].obs;
  RxList<Result>? connectionList = <Result>[].obs;

  Future<void> getConnection(var pageNumber) async{
    _connectionList!.clear();
    connectionList!.clear();
    isLoading.value = true;
    repo.searchConnections(pageNumber,searchTextController.value.text.toString()).then((value) {
      isLoading.value = false;
      myListModel.value = ConnectionModel.fromJson(value);
      /*_connectionList?.assignAll(List<Result>.generate(
          myListModel.value.result!.length,
              (index) => myListModel.value.result![index]));*/

      _connectionList?.assignAll(myListModel.value.result!
          .where((item) => item.isConnection == true && item.requestStatus == "none")
          .toList());

      connectionList!.addAll(List<Result>.from(_connectionList!));
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("FETCH_CONNECTION_LIST_ERROR===>$error");
    });
  }

  Future<void> getMoreConnections(var pageNumber) async{
    isMoreLoading.value = true;
    repo.searchConnections(pageNumber,searchTextController.value.text.toString()).then((value) {
      isMoreLoading.value = false;
      myListModel.value = ConnectionModel.fromJson(value);
      debugPrint("connectionList!=>>${connectionList!.length}");

      /*_connectionList?.assignAll(List<Result>.generate(
          myListModel.value.result!.length,
              (index) {
            debugPrint("TYPE____________>${myListModel.value.result![index].runtimeType}");
            return myListModel.value.result![index];
              }));*/

      _connectionList?.assignAll(myListModel.value.result!
          .where((item) => item.isConnection == true && item.requestStatus == "none")
          .toList());

      connectionList!.addAll(List<Result>.from(_connectionList!));
    }).onError((error, stackTrace) {
      isMoreLoading.value = false;
      debugPrint("FETCH_CONNECTION_LIST_ERROR===>$error");
    });
  }

  Future<void> sendConnectionRequest(var connectionId,void Function() func) async{
    isActionLoading.value = true;
    repo.sendConnectionRequest(connectionId).then((value) {
      isActionLoading.value = false;
      if(value['errMsg'] == false){
        //connectionList![index].requestStatus = "send";
        func();
        Utils.showToastMessage(value['message']);
      }else{
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace) {
      isActionLoading.value = false;
      debugPrint("SEND_CONNECTION_REQUEST_ERROR=>$error");
    });
  }

  Future<void> actionAgainstConnectionRequest(var connectionId,String action,void Function() func) async{
    Map<String,dynamic> body = {
      "cId": connectionId,
      "action": action
    };
    repo.actionAgainstConnectionRequest(body).then((value) {
      if(value['errMsg'] == false){
        //connectionList![index].requestStatus = "send";
        //getConnection(1);
        func();
        Utils.showToastMessage(value['message']);
      }else{
        Utils.showToastMessage(value['message']);
      }
    }).onError((error, stackTrace) {
      debugPrint("ACTION_AGAINST_CONNECTION_REQUEST_ERROR=>$error");
    });
  }

  Future<void> getRequestList({String type="",required pageNo}) async{
    sentPendingList!.clear();
    isLoading.value = true;
    repo.getRequestList(pageNo: pageNo,type: type).then((value) {
      isLoading.value = false;
      sentPendingModel.value = SentPendingModel.fromJson(value);
      _sentPendingList?.assignAll(List<Results>.generate(
          sentPendingModel.value.result!.length,
              (index) => sentPendingModel.value.result![index]));

      sentPendingList!.addAll(List<Results>.from(_sentPendingList!));
    }).onError((error, stackTrace) {
      isLoading.value = false;
      Utils.showToastMessage("Getting some troubles");
    });
  }

  Future<void> getMoreRequestList({String type="",required pageNo}) async{
    // sentPendingList!.clear();
    isMoreLoading.value = true;
    repo.getRequestList(pageNo: pageNo,type: type).then((value) {
      isMoreLoading.value = false;
      sentPendingModel.value = SentPendingModel.fromJson(value);
      _sentPendingList?.assignAll(List<Results>.generate(
          sentPendingModel.value.result!.length,
              (index) => sentPendingModel.value.result![index]));

      sentPendingList!.addAll(List<Results>.from(_sentPendingList!));
    }).onError((error, stackTrace) {
      isMoreLoading.value = false;
      Utils.showToastMessage("Getting some troubles");
    });
  }


  // Future<void> searchConnection(){
  //
  // }

}