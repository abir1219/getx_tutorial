import 'package:flutter/material.dart';
import 'package:get/get.dart';

class DashboardController extends GetxService{
  RxInt pageIndex = 0.obs;

  void changePageIndex(int index){
    debugPrint("Index=>$index");
    pageIndex.value = index;
  }
}