import 'dart:convert';

import 'package:MotivateU/models/medium_model.dart';
import 'package:MotivateU/models/sign_up_model.dart';
import 'package:MotivateU/repository/signup_repository.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart';

import '../main.dart';
import '../models/board_model.dart';
import '../models/city_model.dart';
import '../models/class_model.dart';
import '../models/school_model.dart';
import '../models/terms_condition_model.dart';
import '../res/routes/app_routes.dart';

class SignUpController extends GetxController {
  final signupRepo = SignupRepository();

  Rx<ClassModel> classData = ClassModel().obs;
  Rx<MediumModel> mediumData = MediumModel().obs;
  Rx<BoardModel> boardData = BoardModel().obs;
  Rx<SchoolModel> schoolData = SchoolModel().obs;
  Rx<SignUpModel> signupData = SignUpModel().obs;
  Rx<CityModel> cityData = CityModel().obs;
  Rx<CityModel> stateData = CityModel().obs;
  Rx<TermsConditionModel> tncData = TermsConditionModel().obs;

  RxList<String>? cityNameList = <String>[].obs;
  RxString? selectedValue = "".obs;

  // List<ClassModel> get data => _data;
  Rx<bool> isLoading = false.obs;
  Rx<bool> isCityLoading = false.obs;

  Rx<bool> isSelectClass = false.obs;
  Rx<bool> isSelectSchool = false.obs;
  Rx<bool> isSelectOtherSchool = false.obs;
  Rx<bool> isSelectCity = false.obs;
  Rx<bool> isSelectMedium = false.obs;
  Rx<bool> isSelectBoard = false.obs;
  Rx<bool> isSelectState = false.obs;
  Rx<bool> isCityOpen = false.obs;

  Rx<bool> isPasswordVisible = false.obs;
  Rx<bool> isCnfrmPasswordVisible = false.obs;

  Rx<bool> isSelectTnC = false.obs;
  Rx<bool> isSelectGroup = false.obs;
  Rx<bool> isSelectWp = false.obs;

  Rx<String> classId = "".obs;
  Rx<String> mediumId = "".obs;
  Rx<String> boardId = "".obs;
  Rx<String> schoolId = "".obs;



  // final data

  Rx<TextEditingController> nameController = TextEditingController().obs;
  Rx<TextEditingController> passwordController = TextEditingController().obs;
  Rx<TextEditingController> cnfrmPasswordController = TextEditingController().obs;
  Rx<TextEditingController> authPinController = TextEditingController().obs;
  Rx<TextEditingController> emailController = TextEditingController().obs;
  Rx<TextEditingController> addressController = TextEditingController().obs;
  Rx<TextEditingController> pinController = TextEditingController().obs;
  Rx<TextEditingController> classController = TextEditingController().obs;
  Rx<TextEditingController> schoolController = TextEditingController().obs;
  Rx<TextEditingController> otherSchoolController = TextEditingController().obs;
  Rx<TextEditingController> otherCityController = TextEditingController().obs;
  Rx<TextEditingController> mediumController = TextEditingController().obs;
  Rx<TextEditingController> boardController = TextEditingController().obs;
  Rx<TextEditingController> cityController = TextEditingController().obs;
  Rx<TextEditingController> stateController = TextEditingController().obs;

  // @override
  // void onInit() {
  //   super.onInit();
  //   getClass(); // Fetch data when the controller is initialized
  // }

  Future<void> getClass() async {
    signupRepo.getClass().then(
      (value) {
        classData.value = ClassModel.fromJson(value);
        debugPrint("classData_type=>${classData.runtimeType}");

        debugPrint("CLASS_RES====>${classData.value.result![0].sId}");
        debugPrint("CLASS_RES_TYPE====>${value.runtimeType}");
      },
    ).onError(
      (error, stackTrace) {
        debugPrint("CLASS_ERROR====>${error}");
      },
    );
  }

  Rx<bool> isAccept = false.obs;

  Future<void> acceptTnC() async{
    isAccept.value = true;
    signupRepo.acceptTnC().then((value) {
      isAccept.value = false;
    }).onError((error, stackTrace) {
      isAccept.value = false;
    });
  }

  Future<void> getTnC() async {
    signupRepo.getTnC().then(
          (value) {
        tncData.value = TermsConditionModel.fromJson(value);
        debugPrint("tncData_type=>${tncData.runtimeType}");

        debugPrint("tncData_RES====>${classData.value.result![0].sId}");
        debugPrint("tncData_RES_TYPE====>${value.runtimeType}");
      },
    ).onError(
          (error, stackTrace) {
        debugPrint("tncData_ERROR====>${error}");
      },
    );
  }

  Future<void> getState() async {
    signupRepo.getState().then(
          (value) {
            stateData.value = CityModel.fromJson(value);
        // debugPrint("classData_type=>${classData.runtimeType}");
        //
        // debugPrint("CLASS_RES====>${classData.value.result![0].sId}");
        // debugPrint("CLASS_RES_TYPE====>${value.runtimeType}");
      },
    ).onError(
          (error, stackTrace) {
        debugPrint("STATE_ERROR====>${error}");
      },
    );
  }

  Future<void> getCity() async{
    cityNameList!.clear();
    String city = cityController.value.text.trim();
    //if(city.isNotEmpty){
      isCityLoading.value = true;
    //}
    signupRepo.getCity(city).then((value) {
      isCityLoading.value = false;
      cityData.value = CityModel.fromJson(value);
      cityNameList!.assignAll(List<String>.generate(
          cityData.value.result!.length,
              (index) => cityData.value.result![index].name!));

      selectedValue!.value = cityNameList![0];
      if(city.isNotEmpty){
        isCityOpen.value = true;
      }else{
        isCityOpen.value = false;
      }

      // debugPrint("CITY_Name_list=>$cityNameList");
      // debugPrint("selectedValue.value ==>${selectedValue!.value}");
    }).onError((error, stackTrace) {
      isCityLoading.value = false;
      debugPrint("CITY_ERROR=>$error");
    });
  }

  Future<void> getMedium() async {
    signupRepo.getMedium().then(
      (value) {
        mediumData.value = MediumModel.fromJson(value);
        debugPrint("mediumData_type=>${mediumData.runtimeType}");

        debugPrint("MEDIUM_RES====>${mediumData.value.result![0].id}");
        debugPrint("MEDIUM_RES_TYPE====>${value.runtimeType}");
        // if (kDebugMode) alice.onHttpResponse(value);
        // if (kDebugMode) alice.showInspector();
      },
    ).onError(
      (error, stackTrace) {
        debugPrint("MEDIUM_ERROR====>${error}");
        if (kDebugMode) alice.showInspector();
      },
    );
  }

  Future<void> getBoard() async {
    signupRepo.getBoard().then(
      (value) {
        boardData.value = BoardModel.fromJson(value);
        debugPrint("boardData_type=>${boardData.runtimeType}");

        debugPrint("BOARD_RES====>${boardData.value.result![0].id}");
        debugPrint("BOARD_RES_TYPE====>${value.runtimeType}");
        // if (kDebugMode) alice.onHttpResponse(value);
        // if (kDebugMode) alice.showInspector();
      },
    ).onError(
      (error, stackTrace) {
        debugPrint("BOARD_ERROR====>${error}");
        if (kDebugMode) alice.showInspector();
      },
    );
  }

  Future<void> getSchool() async {
    signupRepo.getSchool().then(
      (value) {
        schoolData.value = SchoolModel.fromJson(value);
        debugPrint("SchoolData_type=>${schoolData.runtimeType}");

        debugPrint("SCHOOL_RES====>${schoolData.value.result![0].id}");
        debugPrint("SCHOOL_RES_TYPE====>${value.runtimeType}");
        // if (kDebugMode) alice.onHttpResponse(value);
        // if (kDebugMode) alice.showInspector();
      },
    ).onError(
      (error, stackTrace) {
        debugPrint("SCHOOL_ERROR====>${error}");
        if (kDebugMode) alice.showInspector();
      },
    );
  }

  Future<void> signUp({required String ph}) async {
    debugPrint("signup------>");
    isLoading.value = true;
    Map<String, dynamic> body = {
      'phone': ph,
      'name': nameController.value.text.toString(),
      'password': base64Encode(utf8.encode(passwordController.value.text.toString())),
      'email': emailController.value.text.toString(),
      'address': addressController.value.text.toString(),
      'pin': authPinController.value.text.toString(),
      'city':!isSelectCity.value
          ? cityController.value.text.toString()
          : otherCityController.value.text.toString(),

    //'Kolkata',
      'state':stateController.value.text.toString(),
      'pincode': pinController.value.text.toString(),
      'whatsappNotification': isSelectWp.value?"yes":"no",
      'groupCreation': isSelectGroup.value,
      'std': classId.value,
      'medium': mediumId.value,
      /*'school': isSelectOtherSchool.value
          ? otherSchoolController.value.text.toString()
          : classId.value,*/
    'school':isSelectOtherSchool.value
        ? otherSchoolController.value.text.toString()
        : schoolController.value.text.toString(),
    'board': boardId.value,
    'referBy': '',
    };
    signupRepo
        .signup(body)
        .then(
          (value) {
            isLoading.value = false;
            signupData.value = SignUpModel.fromJson(value);
            if(signupData.value.errMsg! == false){
              //Utils.saveSharedPref(AppConstants.ACCESS_TOKEN,signupData.value.accessToken!);
              SharedPreferencesUtils.saveString(AppConstants.ACCESS_TOKEN,signupData.value.accessToken!);
              SharedPreferencesUtils.saveString(AppConstants.REFERRAL_NO, signupData.value.myReferralCode!);
              SharedPreferencesUtils.saveString(AppConstants.PROFILE_ID, signupData.value.profile![0].id!);
              _connectionSocket();
              socket.emit('connected-student',signupData.value.profile![0].id!);
              Utils.showToastMessage(signupData.value.message!);
              clearController();
              getTimeApiCall();
              addFCM();
              Get.toNamed(AppRoutes.dashboard);
            }else{
              Utils.showToastMessage(signupData.value.message!);
            }
          },
        )
        .onError((error, stackTrace) {
      isLoading.value = false;
      Utils.showToastMessage("ERROR: ${error.toString()}");
    });
  }

  Future<void> addFCM() async{
    Map<String,dynamic> body = {
      'profile': '${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}',
      'fcm': '${SharedPreferencesUtils.getString(AppConstants.TOKEN)}',
    };
    try{
      signupRepo.addFcm(body);
    }catch(e){
      debugPrint("Failed to add fcm Token with the profile");
    }
  }

  _connectionSocket(){
    print("SOCket->${socket.connected}");
    socket.onConnect((data) => print("Connection Established"));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("SOCket->${socket.json.connected}");
  }

  @override
  void onClose() {
    debugPrint("Controller close");
  }

  void clearController() {
    nameController.value.text = "";
    passwordController.value.text = "";
    cnfrmPasswordController.value.text = "";
    authPinController.value.text = "";
    emailController.value.text = "";
    addressController.value.text = "";
    pinController.value.text = "";
    classController.value.text = "";
    schoolController.value.text = "";
    otherSchoolController.value.text = "";
    mediumController.value.text = "";
    boardController.value.text = "";


  }
}
