import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/hots_topics_model.dart';
import '../repository/hots_topics_repository.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';
import '../utils/utils.dart';

class HotsTopicsController extends GetxController{

  final _hotsTopicsRepository = HotsTopicsRepository();
  Rx<HotsTopicsModel> hotsTopicModel = HotsTopicsModel().obs;

  RxBool isLoading = false.obs;

  Timer? timerTrack;
  Rx<int> counterTracker = 0.obs;
  Rx<bool> haveTime = true.obs;

  void startTimerTrack() {
    debugPrint("--------Hots Topics Start---------");
    // haveTime.value = true;
    // counterTracker.value = 0;
    timerTrack = Timer.periodic(Duration(seconds: 1), (timer) {
      // if(SharedPreferencesUtils.getInt(AppConstants.USED_TIME)! > counterTracker.value){
      if (haveTime.value) {
        if (SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! >= counterTracker.value) {
          debugPrint("HOTS_TOPICS_counterTracker_Timer====>${counterTracker.value}");
          counterTracker.value += 1000;
        } else {
          haveTime.value = false;
          timer.cancel(); // Stop the timer when haveTime.value becomes false
          debugPrint("<<<<<<<==Stop==>>>>>>>>>");
          stopTimerTrack();
        }
      } else {
        haveTime.value = false;
        timer.cancel(); // Stop the timer if haveTime.value is already false
      }
    });

  }

  void stopTimerTrack([String? questionID]) {
    debugPrint("--------Hots Topics Stop---------");
    if (timerTrack != null && timerTrack!.isActive) {
      timerTrack!.cancel();
      debugPrint("HOTS_TOPICS_counterTracker_STOP====>${counterTracker.value}");
     sendTimeTrack(questionID);
      counterTracker.value = 0;
    }
  }

  Future<void> sendTimeTrack([String? questionId = null]) async{
    debugPrint("--------Hots Topics Send Track---------");
    Map<String,dynamic> body = {
      "profile" : SharedPreferencesUtils.getString(AppConstants.PROFILE_ID),
      "question" : questionId,
      "time" : counterTracker.value
    };

    _hotsTopicsRepository.sendTimeTrack(body).then((value) {
      if(value['errMsg'] == false){
        //Utils.showToastMessage(value['message']);
        SharedPreferencesUtils.saveInt(AppConstants.LEFT_TIME,value['leftTime']);
      }
    }).onError((error, stackTrace) {
      debugPrint("TIME_TRACK_ERROR->$error");
    });
  }

  Future<void> getTopicsList(String subjectId) async{
    isLoading.value = true;
    _hotsTopicsRepository.getHotsTopicsList(subjectId).then((value) {
      isLoading.value = false;
      hotsTopicModel.value = HotsTopicsModel.fromJson(value);
    }).onError((error, stackTrace) {
      isLoading.value = false;
      debugPrint("HOTS_TOPICS_ERROR=>$error");
      Utils.showToastMessage(error.toString());
    });
  }
}