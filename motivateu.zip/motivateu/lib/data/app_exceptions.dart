class AppExceptions implements Exception {
  final _message, _prefix;

  AppExceptions([this._message, this._prefix]);

  @override
  String toString() {
    // return "$_message$_prefix";
    return "$_message";
  }
}

class NoInternetException extends AppExceptions {
  NoInternetException([String? message]) : super(message, "No Internet");
}

class RequestTimeOut extends AppExceptions {
  RequestTimeOut([String? message]) : super(message, "Request Time Out");
}

class ServerException extends AppExceptions {
  ServerException([String? message]) : super(message, "Internal Server Error");
}

class InvalidUrlException extends AppExceptions {
  InvalidUrlException([String? message]) : super(message, "Invalid Url");
}

class FetchDataException extends AppExceptions {
  FetchDataException([String? message]) : super(message, "Communication Error");
}

class UnAuthorizeAccessException extends AppExceptions {
  UnAuthorizeAccessException([String? message]) : super(message, "Unauthorized Access");
}
