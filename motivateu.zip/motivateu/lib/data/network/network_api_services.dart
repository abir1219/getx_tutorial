import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:MotivateU/data/app_exceptions.dart';
import 'package:MotivateU/data/network/base_api_services.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:dio/dio.dart' as dio;
import 'package:flutter/material.dart';
import 'package:http_parser/http_parser.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:pointycastle/pointycastle.dart';


import '../../helper/api_end_points.dart';
import '../../main.dart';

class NetworkApiServices extends BaseApiServices {
  dynamic responseJSON;


  @override
  Future<dynamic> getApi(String url) async {
    Map<String, String> headers;
    if (url.contains('medium') ||
        url.contains('board') && !url.contains('dashboard') ||
        url.contains('school') ||
        url.contains('search-city') ||
        url.contains('std')) {
      headers = {
        //'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
        'apikey' : createAuth()
      };
    }/*else if(url.contains('my-subscriptions')){
      headers = {
        'Content-Type': 'application/json',
        'Authorization':
        'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NTJlNTJlYjUxODRlMDA2ZTI3YmI5OWIiLCJyb2xlIjoiU3R1ZGVudCIsInBob25lIjoiMTIzNDU2Nzg5MSIsInRpbWVzdGFtcCI6MTY5OTMzNDIzMTA2MiwiaWF0IjoxNjk5MzM0MjMxLCJleHAiOjE2OTk0MjA2MzF9.QHZihEWCDHczFk0oD9HtW96RLu499-fCW5R3p7BWqrE',
        // 'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
      };
    }*/



    else {
      debugPrint("url.contains('std')===>Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}");
      headers = {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}',
        // 'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
        'apikey' : createAuth()
      };
    }

    debugPrint("HEADER---->$headers");

    try {
      var response = await http
          .get(Uri.parse(url), headers: headers);
          //.timeout(Duration(seconds: 10));

      // if (kDebugMode) alice.onHttpResponse(response);
      // if (kDebugMode) alice.showInspector();
      debugPrint("$url => ${response.body}");
      responseJSON =
          returnResponse(response, jsonDecode(response.body)['message']??"",() => getApi(url));
      debugPrint("GET_responseJSON_TYPE=> ${responseJSON.runtimeType}");
    } on SocketException {
      throw NoInternetException();
    } on RequestTimeOut {
      throw RequestTimeOut();
    }

    return responseJSON;
  }

  dynamic returnResponse(http.Response response, String msg,Future<dynamic> Function() apiCall) async {
    switch (response.statusCode) {
      case 200:
        dynamic responseJSON =
            response.body.isNotEmpty ? json.decode(response.body) : null;
        // jsonDecode(response.body);
        return responseJSON;
      case 201:
        dynamic responseJSON = jsonDecode(response.body);
        return responseJSON;
      case 400:
        throw InvalidUrlException(msg);
      case 401:
        // throw UnAuthorizeAccessException;
        // await _refreshAndRetry(() => apiCall());
        await _refreshAndRetry(() => apiCall());
      case 500:
        throw ServerException;
      default:
        throw FetchDataException(
            'Error occurred while communicating with the server ${response.statusCode}');
    }
  }

  @override
  Future<dynamic> postApi(String url, dynamic body) async {
    debugPrint("url->$url\nbody=>${jsonEncode(body)}");
    Map<String, String> headers;
    if (url.contains('login') ||
        url.contains('registration') ||
        url.contains('send-otp') ||
        url.contains('verify-otp') ||
        url.contains('new-access-token')) {
      headers = {
        'Content-Type': 'application/json',
        //'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
        'apikey' : createAuth()
      };
    } else {
      headers = {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}',
        //'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
        'apikey' : createAuth()
      };
    }

    try {

      var response = await http
          .post(Uri.parse(url), body: jsonEncode(body), headers: headers);
          // .timeout(Duration(seconds: 10));

      debugPrint("$url ${jsonDecode(response.body)}");
      // if (kDebugMode) alice.onHttpResponse(response);
      // if (kDebugMode) alice.showInspector();
      responseJSON =
          returnResponse(response, jsonDecode(response.body)['message'],() => postApi(url,body));
      debugPrint("POST_responseJSON_TYPE=> ${responseJSON.runtimeType}");
    } on SocketException {
      throw NoInternetException();
    } on RequestTimeOut {
      throw RequestTimeOut();
    }

    return responseJSON;
  }

  int count = 0;
  // Method to refresh the token and retry the suspended API calls.
  Future<void> _refreshAndRetry(Future<dynamic> Function() apiCall,) async {
    debugPrint("refresh&retry=>$count");
    // Refresh the token.
    await refreshTokenApi();

    // Retry the suspended API call.
    try {
      if(count == 0){
        count = 1;
        await apiCall();
      }
      debugPrint("apiCall completed successfully");
    } catch (e, stackTrace) {
      debugPrint("apiCall failed: $e");
      debugPrint("$stackTrace");
    }
  }


  Future<void> refreshTokenApi() async {
    debugPrint("refreshToken");
    // final repo = RefreshTokenRepo();

    Map<String, String> headers = {
      'Content-Type': 'application/json',
      //'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
      'apikey' : createAuth()
    };

    //await SharedPreferencesUtils.init();
    var refreshToken = SharedPreferencesUtils.getString(AppConstants.REFRESH_TOKEN);
    debugPrint("refreshToken->${refreshToken}");

    Map<String, dynamic> body = {
      'refreshToken':'${SharedPreferencesUtils.getString(AppConstants.REFRESH_TOKEN)}'
    };

    debugPrint("body->${jsonEncode(body)}");

    String url =  ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.RefreshToken;
    debugPrint("url->$url");
    try{
      final response = await http.post(Uri.parse(url),body: jsonEncode(body),headers: headers);
      // if (kDebugMode) alice.onHttpResponse(response);
      // if (kDebugMode) alice.showInspector();
      if (response.statusCode == 401) {
        // await SharedPreferencesUtils.init();
        SharedPreferencesUtils.clear();
        Get.toNamed(AppRoutes.login);
      }else if(response.statusCode == 200){
        var body  = jsonDecode(response.body);
        debugPrint("token->${body['accessToken']}");
        await SharedPreferencesUtils.init();
        SharedPreferencesUtils.saveString(
            AppConstants.ACCESS_TOKEN, body['accessToken']);
      }
    }on SocketException {
      throw NoInternetException();
    } on RequestTimeOut {
      throw RequestTimeOut();
    }

    /*repo.refreshToken(body).then((value) {
      SharedPreferencesUtils.saveString(
          AppConstants.ACCESS_TOKEN, value['accessToken']);
    }).onError((error, stackTrace) {
      refreshTokenApi();
      debugPrint("REFRESH_TOKEN_ERROR->$error");
    });*/
  }

  Future<void> multipartFileUpload(String url,String profileId,File file) async{

    debugPrint("URL=>$url");

    // var stream = new http.ByteStream(file.openRead());
    // stream.cast();

    var request = http.MultipartRequest('POST', Uri.parse(url));

    // var length = await file.length();
    // var multipart = new http.MultipartFile('file', stream, length);

    var multipart = await http.MultipartFile.fromPath('file', file.path);
    request.headers['Authorization'] = 'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}';
    request.headers['Content-Type'] = 'multipart/form-data';
    request.headers['apikey'] = createAuth();

    request.files.add(multipart);

    try{
      var response = await request.send();

      if(response.statusCode == 200){
        debugPrint('Image Uploaded Successfully');
      }else{
        debugPrint('Image Upload Failed and status code ====> ${response.statusCode}');
        print('Reason: ${response.reasonPhrase}');
        // You might want to print the response body for more details
        print(await response.stream.bytesToString());
      }
    }catch (error) {
      print('Error during file upload: $error');
    }

  }


  Future<void> imageUpload(String url,File file) async{
    dio.Dio call = dio.Dio();


    if (isFilePathValid(file.path)) {
      print('File exists at ${file.parent.path}');
      // var url = "http://192.168.1.184:5007/api/v1/upload/avatar/655305cc9fe80a251c20f04a";

      // Map<String, dynamic> headers = {
      //   'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NTUzMDVjYzlmZTgwYTI1MWMyMGYwNGMiLCJyb2xlIjoiU3R1ZGVudCIsInBob25lIjoiOTgxNjI0MTMwMCIsInRpbWVzdGFtcCI6MTcwMTA3ODI1MjIxMCwiaWF0IjoxNzAxMDc4MjUyLCJleHAiOjE3MDExNjQ2NTJ9.ezoas6M__9G3t4BLHAU3vuOdo9RbRnnch1QPktBdi10',
      //   'Content-Type': 'multipart/form-data',
      // };

      // var headers = {
      //   'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NTUzMDVjYzlmZTgwYTI1MWMyMGYwNGMiLCJyb2xlIjoiU3R1ZGVudCIsInBob25lIjoiOTgxNjI0MTMwMCIsInRpbWVzdGFtcCI6MTcwMTA3ODI1MjIxMCwiaWF0IjoxNzAxMDc4MjUyLCJleHAiOjE3MDExNjQ2NTJ9.ezoas6M__9G3t4BLHAU3vuOdo9RbRnnch1QPktBdi10',
      //   'Content-Type': 'multipart/form-data'
      // };

      call.options.headers['Authorization'] = 'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}';
      call.options.headers['apikey'] = createAuth();
      // call.options.headers['Content-Type'] = 'multipart/form-data';


      call.options.contentType = dio.Headers.multipartFormDataContentType;
      // call.options.contentType = Headers.jsonContentType;

      call.options.validateStatus = (int? status) {
        debugPrint("----status---- $status");
        return status != null && status >= 200 && status < 500;
      };

      /*FormData formData = FormData.fromMap({
        'avatarFile': await MultipartFile.fromFile(
          file.path,
          filename: name,
        ),
      });*/

      String fileType = file.path.split('.').last; // Get file extension
      MediaType mediaType;
      switch (fileType.toLowerCase()) {
        case 'png':
          mediaType = MediaType('image', 'png');
          break;
        case 'jpg':
        case 'jpeg':
          mediaType = MediaType('image', 'jpeg');
          break;
        case 'gif':
          mediaType = MediaType('image', 'gif');
          break;
      // Add cases for other file types as needed
        default:
          mediaType = MediaType('application', 'octet-stream');
          break;
      }

      dio.FormData formData = dio.FormData();
      print('MultipartFile===> ${file.path},${file.path.split("/").last}');
      print('contentType===> ${mediaType.type}');
      formData.files.add(MapEntry(
        'avatarFile',
        await dio.MultipartFile.fromFile(
            file.path,
            filename: file.path.split("/").last,
            contentType: mediaType
        ),
      ));

// Print the formData to debug
      print('FormData: ${formData.files[0].value.contentType}');

      // Print the formData to debug
      print('FormData: ${formData.fields}');

      call.interceptors.add(dio.LogInterceptor(requestBody: true, responseBody: true));


      try {
        dio.Response response = await call.post(url, data: formData);
        print('Upload successful: ${response.data}');
      } catch (error) {
        if (error is dio.DioException) {
          print('Error uploading image: ${error.message}');
          // Access more error information if needed, e.g., error.response
        } else {
          print('Unexpected error: $error');
        }
      }
    }
  }

  @override
  Future<dynamic> putApi(String url, body) async{
    debugPrint("url->$url\nbody=>${jsonEncode(body)}");
    Map<String, String> headers;
    if (url.contains('login') ||
        url.contains('registration') ||
        url.contains('send-otp') ||
        url.contains('verify-otp') ||
        url.contains('new-access-token')) {
      headers = {
        'Content-Type': 'application/json',
        'apikey' : createAuth()
        //'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
      };
    } else {
      headers = {
        'Content-Type': 'application/json',
        'Authorization':
        'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}',
        //'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
        'apikey' : createAuth()
      };
    }

    try {
      var response = await http
          .put(Uri.parse(url), body: jsonEncode(body), headers: headers);
          // .timeout(Duration(seconds: 10));

      debugPrint("$url ${jsonDecode(response.body)}");
      // if (kDebugMode) alice.onHttpResponse(response);
      // if (kDebugMode) alice.showInspector();
      responseJSON =
          returnResponse(response, jsonDecode(response.body)['message'],() => putApi(url,body));
      debugPrint("PUT_responseJSON_TYPE=> ${responseJSON.runtimeType}");
    } on SocketException {
      throw NoInternetException();
    } on RequestTimeOut {
      throw RequestTimeOut();
    }

    return responseJSON;
  }

  bool isFilePathValid(String filePath) {
    File file = File(filePath);
    return file.existsSync();
  }

  @override
  Future deleteApi(String url) async{
    Map<String, String> headers;
    if (url.contains('medium') ||
        url.contains('board') ||
        url.contains('school') ||
        url.contains('std')) {
      headers = {
        //'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
        'apikey' : createAuth()
      };
    } else {
      headers = {
        'Content-Type': 'application/json',
        'Authorization':
        'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}',
        // 'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
        'apikey' : createAuth()
      };
    }

    try {
      var response = await http
          .delete(Uri.parse(url), headers: headers);
      //.timeout(Duration(seconds: 10));

      // if (kDebugMode) alice.onHttpResponse(response);
      // if (kDebugMode) alice.showInspector();
      debugPrint("$url => ${response.body}");
      responseJSON =
          returnResponse(response, jsonDecode(response.body)['message'],() => getApi(url));
      debugPrint("DELETE_responseJSON_TYPE=> ${responseJSON.runtimeType}");
    } on SocketException {
      throw NoInternetException();
    } on RequestTimeOut {
      throw RequestTimeOut();
    }

    return responseJSON;
  }

  String encrypt(String text, String key) {
    final keyBytes = Uint8List.fromList(base64Url.decode(key));
    final ivBytes = _generateRandomBytes(16);
    final textBytes = Uint8List.fromList(utf8.encode(text));

    final keyParam = KeyParameter(keyBytes);
    final ivParam = ParametersWithIV(keyParam, ivBytes);
    final cipher = BlockCipher('AES/CBC')..init(true, ivParam);

    final paddedTextBytes = _padPkcs7(textBytes);
    final encryptedBytes = cipher.process(paddedTextBytes);

    final ivBase64 = base64Url.encode(ivBytes);
    final encryptedText = base64Url.encode(encryptedBytes);

    return '$ivBase64:$encryptedText:$key';
  }

  Uint8List _generateRandomBytes(int length) {
    final random = Random.secure();
    return Uint8List.fromList(
        List<int>.generate(length, (index) => random.nextInt(256)));
  }

  Uint8List _padPkcs7(Uint8List input) {
    final blockSize = 16;
    final padLength = blockSize - (input.length % blockSize);
    final padded =
    Uint8List.fromList([...input, ...List<int>.filled(padLength, padLength)]);
    return padded;
  }

  String generateKey() {
    final random = Random.secure();
    return base64Url
        .encode(List<int>.generate(32, (index) => random.nextInt(256)));
  }


  String createAuth(){
    // final text = DateFormat("yyMMdd'T'HHmmss").format(DateTime.now().add(Duration(seconds: 30))).toString();//'231106T184132';//YYMMDDTHHmmss timestamp format
    final text = DateFormat("yyMMdd'T'HHmmss").format(DateTime.now().add(Duration(days: 30))).toString();//'231106T184132';//YYMMDDTHHmmss timestamp format
    debugPrint("TEXT--->$text");
    final key = generateKey(); // Generate a new key

    final encryptedText = encrypt(text, key);
    print('Encrypted Text in Dart: $encryptedText');
    print('Generated Key: $key');

    // Encode text to base64
    // String base64Text = base64Encode(utf8.encode("Original Text from dart"));
    //
    // print('Encoded Text: $base64Text');
    return encryptedText;
  }
}
