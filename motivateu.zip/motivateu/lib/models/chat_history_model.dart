class ChatHistoryModel {
  bool? errMsg;
  String? message;
  List<Result>? result;
  Pagination? pagination;

  ChatHistoryModel({this.errMsg, this.message, this.result,this.pagination});

  ChatHistoryModel.fromJson(Map<String, dynamic> json) {
    errMsg = json['errMsg'];
    message = json['message'];
    pagination = json['pagination'] != null
        ? new Pagination.fromJson(json['pagination'])
        : null;
    if (json['result'] != null) {
      result = <Result>[];
      json['result'].forEach((v) {
        result!.add(new Result.fromJson(v));
      });
    }

  }

}

class Pagination {
  int? totalPage;
  int? pageSize;
  int? currentPage;
  int? totalRecord;

  Pagination(
      {this.totalPage, this.pageSize, this.currentPage, this.totalRecord});

  Pagination.fromJson(Map<String, dynamic> json) {
    totalPage = json['totalPage'];
    pageSize = json['pageSize'];
    currentPage = json['currentPage'];
    totalRecord = json['totalRecord'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalPage'] = this.totalPage;
    data['pageSize'] = this.pageSize;
    data['currentPage'] = this.currentPage;
    data['totalRecord'] = this.totalRecord;
    return data;
  }
}

class Result {
  String? message;
  Post? post;
  Reel? reel;
  String? messageType;
  String? seenStatus;
  String? sId;
  String? room;
  Profile? profile;
  int? iV;
  String? createdAt;
  String? updatedAt;

  Result(
      {this.message,
        this.post,
        this.reel,
        this.messageType,
        this.seenStatus,
        this.sId,
        this.room,
        this.profile,
        this.iV,
        this.createdAt,
        this.updatedAt});

  Result.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    post = json['post'] != null ? new Post.fromJson(json['post']) : null;
    reel = json['reel'] != null ? new Reel.fromJson(json['reel']) : null;
    messageType = json['messageType'];
    seenStatus = json['seenStatus'];
    sId = json['_id'];
    room = json['room'];
    profile =
    json['profile'] != null ? new Profile.fromJson(json['profile']) : null;
    iV = json['__v'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }
}

class Post {
  String? postContent;
  Reel? question;
  String? postType;
  String? sId;

  Post({this.postContent, this.question, this.postType, this.sId});

  Post.fromJson(Map<String, dynamic> json) {
    postContent = json['postContent'] as String?;
    question = json['question'] != null
        ? new Reel.fromJson(json['question'])
        : null;
    postType = json['postType'];
    sId = json['_id'];
  }

}

class Reel {
  // int? numId;
  String? typename;
  /*Null? scenario;
  String? explanation;
  String? level;
  String? priority;
  List<String>? keyword;
  List<Null>? sendBackReason;
  String? status;
  int? shareCount;*/
  String? sId;
  /*List<Null>? comments;
  Board? board;
  Board? medium;
  Board? std;
  Board? subject;
  Topic? topic;
  Topic? chapter;
  String? type;
  List<Questions>? questions;
  String? createdBy;
  String? createdAt;
  String? updatedAt;
  int? iV;
  String? likes;
  String? dislikes;*/

  Reel(
      {
        //this.numId,
        this.typename,
        this.sId,
        /*this.scenario,
        this.explanation,
        this.level,
        this.priority,
        this.keyword,
        this.sendBackReason,
        this.status,
        this.shareCount,
        this.sId,
        this.comments,
        this.board,
        this.medium,
        this.std,
        this.subject,
        this.topic,
        this.chapter,
        this.type,
        this.questions,
        this.createdBy,
        this.createdAt,
        this.updatedAt,
        this.iV,
        this.likes,
        this.dislikes*/
      });

  Reel.fromJson(Map<String, dynamic> json) {
    // numId = json['numId'];
    typename = json['typename'] as String?;
    sId = json['_id'] as String?;
    /*scenario = json['scenario'];
    explanation = json['explanation'];
    level = json['level'];
    priority = json['priority'];
    keyword = json['keyword'].cast<String>();
    if (json['sendBackReason'] != null) {
      sendBackReason = <Null>[];
      json['sendBackReason'].forEach((v) {
        sendBackReason!.add(new Null.fromJson(v));
      });
    }
    status = json['status'];
    shareCount = json['shareCount'];
    sId = json['_id'];
    if (json['comments'] != null) {
      comments = <Null>[];
      json['comments'].forEach((v) {
        comments!.add(new Null.fromJson(v));
      });
    }
    board = json['board'] != null ? new Board.fromJson(json['board']) : null;
    medium = json['medium'] != null ? new Board.fromJson(json['medium']) : null;
    std = json['std'] != null ? new Board.fromJson(json['std']) : null;
    subject =
    json['subject'] != null ? new Board.fromJson(json['subject']) : null;
    topic = json['topic'] != null ? new Topic.fromJson(json['topic']) : null;
    chapter =
    json['chapter'] != null ? new Topic.fromJson(json['chapter']) : null;
    type = json['type'];
    if (json['questions'] != null) {
      questions = <Questions>[];
      json['questions'].forEach((v) {
        questions!.add(new Questions.fromJson(v));
      });
    }
    createdBy = json['created_by'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
    likes = json['likes'];
    dislikes = json['dislikes'];*/
  }

}

class Profile {
  String? avatar;
  String? sId;
  String? name;

  Profile({this.avatar, this.sId, this.name});

  Profile.fromJson(Map<String, dynamic> json) {
    avatar = json['avatar'];
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['avatar'] = this.avatar;
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}
