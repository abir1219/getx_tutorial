class HotsTopicsModel {
  bool? errMsg;
  String? message;
  List<Result>? result;
  Pagination? pagination;

  HotsTopicsModel({this.errMsg, this.message, this.result, this.pagination});

  factory HotsTopicsModel.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
        resultData.map((item) => Result.fromJson(item)).toList();
    return HotsTopicsModel(
        errMsg: json['errMsg'] as bool?,
        message: json['message'] as String?,
        result: resultList,
        pagination: Pagination.fromJson(json['pagination'] ?? {}));
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['errMsg'] = errMsg;
    data['message'] = message;
    if (result != null) {
      data['result'] = result!.map((v) => v.toJson()).toList();
    }
    if (pagination != null) {
      data['pagination'] = pagination!.toJson();
    }
    return data;
  }
}

class Result {
  String? title;
  String? passageValue;
  String? passageBackground;
  String? sId;
  Board? board;
  Board? medium;
  Board? std;
  Board? subject;
  Board? topic;
  Board? chapter;
  String? createdBy;
  String? createdAt;
  String? updatedAt;
  int? iV;

  Result(
      {this.title,
      this.passageValue,
      this.passageBackground,
      this.sId,
      this.board,
      this.medium,
      this.std,
      this.subject,
      this.topic,
      this.chapter,
      this.createdBy,
      this.createdAt,
      this.updatedAt,
      this.iV});

  Result.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    passageValue = json['passageValue'];
    passageBackground = json['passageBackground'];
    sId = json['_id'];
    board = json['board'] != null ? Board.fromJson(json['board']) : null;
    medium = json['medium'] != null ? Board.fromJson(json['medium']) : null;
    std = json['std'] != null ? Board.fromJson(json['std']) : null;
    subject =
        json['subject'] != null ? Board.fromJson(json['subject']) : null;
    topic = json['topic'] != null ? Board.fromJson(json['topic']) : null;
    chapter =
        json['chapter'] != null ? Board.fromJson(json['chapter']) : null;
    createdBy = json['created_by'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['title'] = title;
    data['passageValue'] = passageValue;
    data['passageBackground'] = passageBackground;
    data['_id'] = sId;
    if (board != null) {
      data['board'] = board!.toJson();
    }
    if (medium != null) {
      data['medium'] = medium!.toJson();
    }
    if (std != null) {
      data['std'] = std!.toJson();
    }
    if (subject != null) {
      data['subject'] = subject!.toJson();
    }
    if (topic != null) {
      data['topic'] = topic!.toJson();
    }
    if (chapter != null) {
      data['chapter'] = chapter!.toJson();
    }
    data['created_by'] = createdBy;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['__v'] = iV;
    return data;
  }
}

class Board {
  String? sId;
  String? name;

  Board({this.sId, this.name});

  Board.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['name'] = name;
    return data;
  }
}

class Pagination {
  int? totalPage;
  int? pageSize;
  int? currentPage;
  int? totalRecord;

  Pagination(
      {this.totalPage, this.pageSize, this.currentPage, this.totalRecord});

  Pagination.fromJson(Map<String, dynamic> json) {
    totalPage = json['totalPage'];
    pageSize = json['pageSize'];
    currentPage = json['currentPage'];
    totalRecord = json['totalRecord'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['totalPage'] = totalPage;
    data['pageSize'] = pageSize;
    data['currentPage'] = currentPage;
    data['totalRecord'] = totalRecord;
    return data;
  }
}
