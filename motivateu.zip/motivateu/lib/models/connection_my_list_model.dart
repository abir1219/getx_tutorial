class ConnectionMyListModel {
  bool? errMsg;
  String? message;
  Return? connectionMyListModelReturn;
  Pagination? pagination;

  ConnectionMyListModel({
    this.errMsg,
    this.message,
    this.connectionMyListModelReturn,
    this.pagination,
  });

  factory ConnectionMyListModel.fromJson(Map<String, dynamic> json){
    return ConnectionMyListModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      pagination: json['pagination']==null?null:Pagination.fromJson(json['pagination']),
      connectionMyListModelReturn: Return.fromJson(json['return'])
    );
    // errMsg = json['errMsg'];
    // message = json['message'];
    // connectionMyListModelReturn = Return.fromJson(json['return']);
    // pagination = Pagination.fromJson(json['pagination']);
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['errMsg'] = errMsg;
    _data['message'] = message;
    _data['return'] = connectionMyListModelReturn?.toJson();
    // _data['pagination'] = pagination?.toJson();
    return _data;
  }

}

class Return {
  Return({
    required this.group,
    required this.connection,
  });

  List<Group>? group;
  List<Connection>? connection;

  Return.fromJson(Map<String, dynamic> json){
    group = List.from(json['group']).map((e) => Group.fromJson(e)).toList();
    connection = List.from(json['connection'])
        .map((e) => Connection.fromJson(e))
        .toList();
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['group'] = group!.map((e)=>e.toJson()).toList();
    _data['connection'] = connection!.map((e)=>e.toJson()).toList();
    return _data;
  }
}

class Connection {
  Connection({
    required this.id,
    required this.name,
    required this.avatar,
  });
  late final String id;
  late final String name;
  late final String avatar;

  Connection.fromJson(Map<String, dynamic> json){
    id = json['_id'];
    name = json['name'];
    avatar = json['avatar'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['_id'] = id;
    _data['name'] = name;
    _data['avatar'] = avatar;
    return _data;
  }
}

class Group {
  Group({
    required this.id,
    required this.name,
  });
  late final String id;
  late final String name;

  Group.fromJson(Map<String, dynamic> json){
    id = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['_id'] = id;
    _data['name'] = name;
    return _data;
  }
}

class Pagination {
  Pagination({
    required this.totalPage,
    required this.pageSize,
    required this.currentPage,
    required this.totalRecord,
  });
  late final int totalPage;
  late final int pageSize;
  late final int currentPage;
  late final int totalRecord;

  Pagination.fromJson(Map<String, dynamic> json){
    totalPage = json['totalPage'];
    pageSize = json['pageSize'];
    currentPage = json['currentPage'];
    totalRecord = json['totalRecord'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};
    _data['totalPage'] = totalPage;
    _data['pageSize'] = pageSize;
    _data['currentPage'] = currentPage;
    _data['totalRecord'] = totalRecord;
    return _data;
  }
}