class LoginModel {
  bool? errMsg;
  String? sId;
  String? phone;
  String? role;
  String? email;
  String? accessToken;
  String? refreshToken;
  final String? myReferralCode;
  String? message;
  List<Profile>? profile;

  LoginModel(
      {this.errMsg,
      this.sId,
      this.phone,
      this.role,
      this.email,
        this.myReferralCode,
      this.accessToken,
      this.refreshToken,
        this.profile,
      this.message});

  factory LoginModel.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['profile'] ?? [];
    List<Profile> profileList =
    resultData.map((item) => Profile.fromJson(item)).toList();

    return LoginModel(
        errMsg: json['errMsg'] as bool?,
      sId: json['_id'] as String?,
      phone: json['phone'] as String?,
      role: json['role'] as String?,
      email: json['email'] as String?, myReferralCode: json['myReferralCode'] as String?,
      accessToken: json['accessToken'] as String?,
      refreshToken: json['refreshToken'] as String?,
      message: json['message'] as String?,
      profile: profileList
    );
    // errMsg = json['errMsg'];
    // sId = json['_id'];
    // phone = json['phone'];
    // role = json['role'];
    // email = json['email'];
    // if (json['profile'] != null) {
    //   profile = <Profile>[];
    //   json['profile'].forEach((v) {
    //     profile!.add(new Profile.fromJson(v));
    //   });
    // }
    // accessToken = json['accessToken'];
    // refreshToken = json['refreshToken'];
    // message = json['message'];
  }

}

class Profile{
  String? id;

  Profile({this.id});
  Profile.fromJson(Map<String,dynamic> json){
    id = json['_id'] as String?;
  }
}

