class DashboardDetailsModel {
  bool? errMsg;
  List<Results>? result;
  String? message;

  DashboardDetailsModel({this.errMsg, this.result, this.message});

  DashboardDetailsModel.fromJson(Map<String, dynamic> json) {
    errMsg = json['errMsg'];
    if (json['result'] != null) {
      result = <Results>[];
      json['result'].forEach((v) {
        result!.add(new Results.fromJson(v));
      });
    }
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['errMsg'] = this.errMsg;
    if (this.result != null) {
      data['result'] = this.result!.map((v) => v.toJson()).toList();
    }
    data['message'] = this.message;
    return data;
  }
}

class Results {
  String? sId;
  int? correct;
  int? total;
  int? visited;
  int? point;

  Results({this.sId, this.correct, this.total, this.visited, this.point});

  Results.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    correct = json['correct'];
    total = json['total'];
    visited = json['visited'];
    point = json['point'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['correct'] = this.correct;
    data['total'] = this.total;
    data['visited'] = this.visited;
    data['point'] = this.point;
    return data;
  }
}