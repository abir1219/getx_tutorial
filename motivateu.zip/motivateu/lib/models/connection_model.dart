class ConnectionModel{
  bool? errMsg;
  String? message;
  List<Result>? result;
  Pagination? pagination;

  ConnectionModel({this.errMsg, this.message, this.result, this.pagination});

  factory ConnectionModel.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
    resultData.map((item) => Result.fromJson(item)).toList();

    return ConnectionModel(
      errMsg: json['errMsg'] as bool?,
      pagination: json['pagination'] != null ? Pagination?.fromJson(json['pagination']) : null,
      message: json['message'] as String?,
      result: resultList
    );

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['errMsg'] = errMsg;
    data['message'] = message;
    data['result'] =result != null ? result!.map((v) => v.toJson()).toList() : null;
    data['pagination'] = pagination!.toJson();
    return data;
  }
}

class Pagination {
  int? totalPage;
  int? pageSize;
  int? currentPage;
  int? totalRecord;

  Pagination({this.totalPage, this.pageSize, this.currentPage, this.totalRecord});

  Pagination.fromJson(Map<String, dynamic> json) {
    totalPage = json['totalPage'] as int?;
    pageSize = json['pageSize'] as int?;
    currentPage = json['currentPage'] as int?;
    totalRecord = json['totalRecord'] as int?;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['totalPage'] = totalPage;
    data['pageSize'] = pageSize;
    data['currentPage'] = currentPage;
    data['totalRecord'] = totalRecord;
    return data;
  }
}

class Result {
  String? id;
  String? name;
  bool? isConnection;
  String? requestStatus;
  String? avatar;
  String? cancelId;
  String? requestId;

  Result({this.id, this.name, this.isConnection, this.avatar,this.requestStatus,this.cancelId,this.requestId});

  Result.fromJson(Map<String, dynamic> json) {
    id = json['_id'] as String?;
    name = json['name'] as String?;
    requestStatus = json['requestStatus'] as String?;
    isConnection = json['isConnection'] as bool?;
    avatar = json['avatar'] as String?;
    cancelId = json['cancelId'] as String?;
    requestId = json['requestId'] as String?;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['_id'] = id;
    data['name'] = name;
    data['isConnection'] = isConnection;
    data['avatar'] = avatar;
    return data;
  }
}