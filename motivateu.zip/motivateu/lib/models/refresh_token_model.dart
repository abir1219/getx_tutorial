class RefreshTokenModel{
  final bool? errMsg;
  final String? accessToken;
  final String? message;

  RefreshTokenModel({this.errMsg, this.accessToken, this.message});

  factory RefreshTokenModel.fromJson(Map<String,dynamic> json){
    return RefreshTokenModel(
      errMsg: json['errMsg'] as bool?,
      accessToken: json['accessToken'] as String?,
      message: json['message'] as String?,
    );
  }
}