class SaveReelsSeenModel {
  final bool? errMsg;
  final String? message;

  SaveReelsSeenModel({this.errMsg, this.message});

  factory SaveReelsSeenModel.fromJson(Map<String, dynamic> json) {
    return SaveReelsSeenModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
    );
  }
}
