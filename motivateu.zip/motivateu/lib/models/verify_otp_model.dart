import 'package:flutter/material.dart';

class VerifyOtpModel{
  final bool? errMsg;
  final String? message;
  final String? accessToken;
  final String? refreshToken;
  List<Profile>? profile;

  VerifyOtpModel({this.accessToken, this.refreshToken, this.errMsg, this.message,this.profile});

  factory VerifyOtpModel.fromJson(Map<String,dynamic> json){
    // debugPrint("json['accessToken']=>${json['accessToken']} and type=> ${json['accessToken'].runtimeType}");
    List<dynamic> resultData = json['profile'] ?? [];
    List<Profile> profileList =
    resultData.map((item) => Profile.fromJson(item)).toList();
    return VerifyOtpModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      accessToken: json['accessToken'] as String?,
      refreshToken: json['refreshToken'] as String?,
      profile: profileList
    );
  }
}

class Profile{
  String? id;

  Profile({this.id});
  Profile.fromJson(Map<String,dynamic> json){
    id = json['_id'] as String?;
  }
}