class ChapterModel{
  final bool? errMsg;
  final String? message;
  final List<Result>? result;

  ChapterModel({this.errMsg, this.message, this.result});

  factory ChapterModel.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
    resultData.map((item) => Result.fromJson(item)).toList();
    return ChapterModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      result: resultList,
    );
  }
}

class Result{
  final String? id;
  final String? name;

  Result({this.id, this.name});

  factory Result.fromJson(Map<String,dynamic> json){
    return Result(
      id: json['_id'] as String?,
      name: json['name'] as String?,
    );
  }
}