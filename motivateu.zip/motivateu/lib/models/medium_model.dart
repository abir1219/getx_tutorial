import 'package:MotivateU/models/class_model.dart';

class MediumModel {
  final bool? errMsg;
  final String? message;
  final List<Result>? result;
  final Pagination? pagination;

  MediumModel(
      {this.errMsg,
      this.message,
      this.result,
      this.pagination});

  factory MediumModel.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
        resultData.map((item) => Result.fromJson(item)).toList();

    return MediumModel(
        errMsg: json['errMsg'] as bool?,
        result: resultList,
        message: json['message'] as String?,
        pagination: Pagination.fromJson(json['pagination'] ?? {}));
  }
}

class Result {
  final String? id;
  final String? name;
  final String? descriptions;
  final String? createdAt;
  final String? updatedAt;
  final int? iV;

  Result(
      {required this.id,
      required this.name,
      required this.descriptions,
      required this.createdAt,
      required this.updatedAt,
      required this.iV});

  factory Result.fromJson(Map<String, dynamic> json) {
    return Result(
        id: json['_id'] as String?,
        name: json['name'] as String?,
        descriptions: json['descriptions'] as String?,
        createdAt: json['createdAt'] as String?,
        updatedAt: json['updatedAt'] as String?,
        iV: json['__v'] as int?);
  }
}

class Pagination {
  final int? totalPage;
  final int? currentPage;
  final int? totalRecord;

  Pagination(
      {required this.totalPage,
      required this.currentPage,
      required this.totalRecord});

  factory Pagination.fromJson(Map<String, dynamic> json) {
    return Pagination(
        totalPage: json['totalPage'] as int?,
        currentPage: json['currentPage'] as int?,
        totalRecord: json['totalRecord'] as int?);
  }
}
