class CityModel{
  bool? errMsg;
  List<Results>? result;

  CityModel({this.errMsg, this.result});

  factory CityModel.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['result'] ?? [];
    List<Results> resultList =
    resultData.map((item) => Results.fromJson(item)).toList();

    return CityModel(
      errMsg: json['errMsg'] as bool?,
      result: resultList
    );

  }
}

class Results{
  String? name;

  Results({this.name});

  Results.fromJson(Map<String,dynamic> json){
      name = json['name'] as String?;
  }
}