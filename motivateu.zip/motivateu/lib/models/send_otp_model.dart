class SendOtpModel{
  final bool? errMsg;
  final String? message;
  final String? otp;

  SendOtpModel({this.message, this.otp,this.errMsg});

  factory SendOtpModel.fromJson(Map<String,dynamic> json){
    return SendOtpModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      otp: json['otp'] as String?
    );
  }
}