class AddProfileModel{
  bool? errMsg;
  String? message;
  Result? result;

  AddProfileModel({this.errMsg, this.message, this.result});

  factory AddProfileModel.fromJson(Map<String,dynamic> json){
    return AddProfileModel(
      errMsg: json['errMsg'] as bool?,
      message:json['message'] as String?,
      result:  json['result'] != null
          ? Result.fromJson(json['result']):null
    );
  }
}

class Result{
  String? id;

  Result({this.id});

  Result.fromJson(Map<String,dynamic> json){
    id = json['_id'] as String?;
  }
}