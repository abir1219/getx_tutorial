class TermsConditionModel {
  bool? errMsg;
  String? message;
  bool? acceptTermsAndCondition;
  Result? result;
  LastAcceptTerms? lastAcceptTerms;

  TermsConditionModel({this.errMsg, this.message,this.acceptTermsAndCondition, this.result});

  TermsConditionModel.fromJson(Map<String, dynamic> json) {
    errMsg = json['errMsg'] as bool?;
    message = json['message'] as String?;
    acceptTermsAndCondition = json['acceptTermsAndCondition'] as bool?;
    result = json['result'] != null ? new Result.fromJson(json['result']) : null;
    lastAcceptTerms = json['lastAcceptTerms'] != null ? new LastAcceptTerms.fromJson(json['lastAcceptTerms']) : null;
  }

}

class Result {
  String? termsAndCondition;
  String? createdBy;
  String? sId;
  String? createdAt;
  String? updatedAt;
  int? iV;

  Result(
      {this.termsAndCondition,
        this.createdBy,
        this.sId,
        this.createdAt,
        this.updatedAt,
        this.iV});

  Result.fromJson(Map<String, dynamic> json) {
    termsAndCondition = json['termsAndCondition'];
    createdBy = json['createdBy'];
    sId = json['_id'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
  }

}

class LastAcceptTerms {
  String? termsAndCondition;
  String? createdBy;
  String? sId;
  String? createdAt;
  String? updatedAt;
  int? iV;

  LastAcceptTerms(
      {this.termsAndCondition,
        this.createdBy,
        this.sId,
        this.createdAt,
        this.updatedAt,
        this.iV});

  LastAcceptTerms.fromJson(Map<String, dynamic> json) {
    termsAndCondition = json['termsAndCondition'];
    createdBy = json['createdBy'];
    sId = json['_id'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
  }

}