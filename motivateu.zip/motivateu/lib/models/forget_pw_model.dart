class ForgetPwModel{
  final bool? errMsg;
  final String? message;


  ForgetPwModel({this.errMsg, this.message});

  factory ForgetPwModel.fromJson(Map<String,dynamic> json){
    return ForgetPwModel(
      message: json['message'] as String?,
      errMsg: json['errMsg'] as bool?,
    );
  }
}