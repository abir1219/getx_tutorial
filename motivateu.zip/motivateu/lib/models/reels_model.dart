class ReelsModel {
  bool? errMsg;
  String? message;
  List<Result>? result;
  Pagination? pagination;

  ReelsModel({this.errMsg, this.message, this.result, this.pagination});

  ReelsModel.fromJson(Map<String, dynamic> json) {
    errMsg = json['errMsg'];
    message = json['message'];
    if (json['result'] != null) {
      result = <Result>[];
      json['result'].forEach((v) {
        result!.add(new Result.fromJson(v));
      });
    }
    pagination = json['pagination'] != null
        ? new Pagination.fromJson(json['pagination'])
        : null;
  }
}

class Pagination {
  int? totalPage;
  int? pageSize;
  int? currentPage;
  int? totalRecord;

  Pagination(
      {this.totalPage, this.pageSize, this.currentPage, this.totalRecord});

  factory Pagination.fromJson(Map<String, dynamic> json) {
    return Pagination(
      totalPage: json['totalPage'],
      pageSize: json['pageSize'],
      currentPage: json['currentPage'],
      totalRecord: json['totalRecord'],
    );
  }
}

class Result {
  String? level;
  String? status;
  String? sId;
  String? type;
  Scenario? scenario;
  String? explanation;
  List<String>? keywords;
  String? typename;
  List<Questions>? questions;
  bool isLiked = false;
  bool isDisliked = false;
  int? commentsCount;
  int? likesCount;
  int? shareCount;
  int? dislikesCount;

  Result(
      {this.level,
      this.status,
      this.sId,
      this.type,
      this.scenario,
      this.explanation,
      this.keywords,
      this.typename,
      this.questions,
      this.likesCount,
      this.isDisliked = false,
      this.commentsCount,
      this.isLiked = false,
      this.dislikesCount,
      this.shareCount});

  Result.fromJson(Map<String, dynamic> json) {
    level = json['level'];
    status = json['status'];
    sId = json['_id'];
    scenario =
        json['scenario'] != null ? Scenario.fromJson(json['scenario']) : null;
    type = json['type'];
    explanation = json['explanation'];
    keywords = json['keyword'].cast<String>();
    typename = json['typename'];
    likesCount = json['likesCount'];
    shareCount = json['shareCount'];
    isDisliked = json['isDisliked'] ?? false;
    commentsCount = json['commentsCount'];
    dislikesCount = json['dislikesCount'];
    isLiked = json['isLiked'] ?? false;
    if (json['questions'] != null) {
      questions = <Questions>[];
      json['questions'].forEach((v) {
        questions!.add(new Questions.fromJson(v));
      });
    }
  }
}

class Board {
  String? sId;
  String? name;

  Board({this.sId, this.name});

  Board.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
  }
}

class Questions {
  Quest? quest;
  String? pasage;
  List<String>? option;
  String? sId;
  int? correctOption;
  List<Answer>? answer;

  Questions(
      {this.quest,
      this.pasage,
      this.option,
      this.sId,
      this.correctOption,
      this.answer});

  Questions.fromJson(Map<String, dynamic> json) {
    quest = json['quest'] != null ? new Quest.fromJson(json['quest']) : null;
    pasage = json['pasage'];
    option = json['option'].cast<String>();
    sId = json['_id'];
    correctOption = json['correctOption'];
    if (json['answer'] != null) {
      answer = <Answer>[];
      json['answer'].forEach((v) {
        answer!.add(new Answer.fromJson(v));
      });
    }
  }
}

class Quest {
  String? questionValue;
  String? questionBackground;

  Quest({this.questionValue, this.questionBackground});

  Quest.fromJson(Map<String, dynamic> json) {
    questionValue = json['questionValue'];
    questionBackground = json['questionBackground'];
  }
}

class Answer {
  String? answerValue;
  String? answerBackground;
  String? sId;

  Answer({this.answerValue, this.answerBackground, this.sId});

  Answer.fromJson(Map<String, dynamic> json) {
    answerValue = json['answerValue'];
    answerBackground = json['answerBackground'];
    sId = json['_id'];
  }
}

class Scenario {
  String? title;
  String? passageValue;
  String? passageBackground;
  String? sId;

  Scenario({this.title, this.passageValue, this.passageBackground, this.sId});

  Scenario.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    passageValue = json['passageValue'];
    passageBackground = json['passageBackground'];
    sId = json['_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['title'] = title;
    data['passageValue'] = passageValue;
    data['passageBackground'] = passageBackground;
    data['_id'] = sId;
    return data;
  }
}
