class ChatListModel {
  bool? errMsg;
  String? message;
  List<Chats>? chats;

  ChatListModel({this.errMsg, this.message, this.chats});

  ChatListModel.fromJson(Map<String, dynamic> json) {
    errMsg = json['errMsg'];
    message = json['message'];
    if (json['chats'] != null) {
      chats = <Chats>[];
      json['chats'].forEach((v) {
        chats!.add(new Chats.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['errMsg'] = this.errMsg;
    data['message'] = this.message;
    if (this.chats != null) {
      data['chats'] = this.chats!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Chats {
  String? sId;
  List<Participants>? participants;
  LastMessage? lastMessage;

  Chats({this.sId, this.participants, this.lastMessage});

  Chats.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    if (json['participants'] != null) {
      participants = <Participants>[];
      json['participants'].forEach((v) {
        participants!.add(new Participants.fromJson(v));
      });
    }
    lastMessage = json['lastMessage'] != null
        ? new LastMessage.fromJson(json['lastMessage'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    if (this.participants != null) {
      data['participants'] = this.participants!.map((v) => v.toJson()).toList();
    }
    if (this.lastMessage != null) {
      data['lastMessage'] = this.lastMessage!.toJson();
    }
    return data;
  }
}

class Participants {
  String? sId;
  String? name;
  String? avatar;

  Participants({this.sId, this.name, this.avatar});

  Participants.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
    avatar = json['avatar'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    data['avatar'] = this.avatar;
    return data;
  }
}

class LastMessage {
  String? sId;
  String? message;
  String? post;
  String? reel;
  String? messageType;
  String? room;
  String? profile;
  int? iV;
  String? createdAt;
  String? updatedAt;

  LastMessage(
      {this.sId,
        this.message,
        this.post,
        this.reel,
        this.messageType,
        this.room,
        this.profile,
        this.iV,
        this.createdAt,
        this.updatedAt});

  LastMessage.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    message = json['message'];
    post = json['post'];
    reel = json['reel'];
    messageType = json['messageType'];
    room = json['room'];
    profile = json['profile'];
    iV = json['__v'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['message'] = this.message;
    data['post'] = this.post;
    data['reel'] = this.reel;
    data['messageType'] = this.messageType;
    data['room'] = this.room;
    data['profile'] = this.profile;
    data['__v'] = this.iV;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    return data;
  }
}