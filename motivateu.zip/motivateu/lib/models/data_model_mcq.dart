import 'package:hive/hive.dart';
part 'data_model_mcq.g.dart';

@HiveType(typeId: 0)
class DataModelMcq extends HiveObject{

  @HiveField(0)
  final String? questionId;
  @HiveField(1)
  final int? correctAnsIndex;
  @HiveField(2)
  final int? SelectedAnsIndex;
  @HiveField(3)
  final bool? isSelected;

  DataModelMcq({required this.questionId,required this.correctAnsIndex,required this.SelectedAnsIndex,required this.isSelected});
}