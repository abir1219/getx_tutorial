class SentPendingModel {
  bool? errMsg;
  String? message;
  List<Results>? result;
  Pagination? pagination;

  SentPendingModel({this.errMsg, this.message, this.result, this.pagination});

  SentPendingModel.fromJson(Map<String, dynamic> json) {
    errMsg = json['errMsg'];
    message = json['message'];
    if (json['result'] != null) {
      result = <Results>[];
      json['result'].forEach((v) {
        result!.add(new Results.fromJson(v));
      });
    }
    pagination = json['pagination'] != null
        ? new Pagination.fromJson(json['pagination'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['errMsg'] = this.errMsg;
    data['message'] = this.message;
    if (this.result != null) {
      data['result'] = this.result!.map((v) => v.toJson()).toList();
    }
    if (this.pagination != null) {
      data['pagination'] = this.pagination!.toJson();
    }
    return data;
  }
}

class Results {
  String? status;
  String? sId;
  SenderProfile? senderProfile;
  ReceiverProfile? receiverProfile;

  Results({this.status, this.sId, this.senderProfile,this.receiverProfile});

  Results.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    sId = json['_id'];
    senderProfile = json['senderProfile'] != null
        ? new SenderProfile.fromJson(json['senderProfile'])
        : null;
    receiverProfile = json['recieverProfile'] != null
        ? new ReceiverProfile.fromJson(json['recieverProfile'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['_id'] = this.sId;
    if (this.senderProfile != null) {
      data['senderProfile'] = this.senderProfile!.toJson();
    }
    return data;
  }
}

class SenderProfile {
  String? avatar;
  List<Group>? group;
  String? sId;
  String? name;

  SenderProfile({this.avatar, this.group, this.sId, this.name});

  SenderProfile.fromJson(Map<String, dynamic> json) {
    avatar = json['avatar'] as String?;
    if (json['group'] != null) {
      group = <Group>[];
      json['group'].forEach((v) {
        group!.add(new Group.fromJson(v));
      });
    }
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['avatar'] = this.avatar;
    if (this.group != null) {
      data['group'] = this.group!.map((v) => v.toJson()).toList();
    }
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}

class ReceiverProfile {
  String? avatar;
  List<Group>? group;
  String? sId;
  String? name;

  ReceiverProfile({this.avatar, this.group, this.sId, this.name});

  ReceiverProfile.fromJson(Map<String, dynamic> json) {
    avatar = json['avatar'] as String?;
    if (json['group'] != null) {
      group = <Group>[];
      json['group'].forEach((v) {
        group!.add(new Group.fromJson(v));
      });
    }
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['avatar'] = this.avatar;
    if (this.group != null) {
      data['group'] = this.group!.map((v) => v.toJson()).toList();
    }
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}

class Group {
  String? sId;
  String? name;

  Group({this.sId, this.name});

  Group.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}

class Pagination {
  int? totalPage;
  int? pageSize;
  int? currentPage;
  int? totalRecord;

  Pagination(
      {this.totalPage, this.pageSize, this.currentPage, this.totalRecord});

  Pagination.fromJson(Map<String, dynamic> json) {
    totalPage = json['totalPage'];
    pageSize = json['pageSize'];
    currentPage = json['currentPage'];
    totalRecord = json['totalRecord'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalPage'] = this.totalPage;
    data['pageSize'] = this.pageSize;
    data['currentPage'] = this.currentPage;
    data['totalRecord'] = this.totalRecord;
    return data;
  }
}