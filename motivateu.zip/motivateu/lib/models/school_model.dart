import 'package:MotivateU/models/class_model.dart';

class SchoolModel {
  final bool? errMsg;
  final String? message;
  final List<Result>? result;
  final Pagination? pagination;

  SchoolModel(
      {this.errMsg, this.message, this.result, this.pagination});

  factory SchoolModel.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
        resultData.map((item) => Result.fromJson(item)).toList();

    return SchoolModel(
        errMsg: json['errMsg'] as bool?,
        // keywords: keywordList,
        result: resultList,
        message: json['message'] as String?,
        pagination: Pagination.fromJson(json['pagination'] ?? {}));
  }
}


class Result {
  final String? id;
  final String? name;
  final String? descriptions;
  final String? createdAt;
  final String? updatedAt;
  final int? iV;

  Result(
      {required this.id,
      required this.name,
      required this.descriptions,
      required this.createdAt,
      required this.updatedAt,
      required this.iV});

  factory Result.fromJson(Map<String, dynamic> json) {

    return Result(
        id: json['_id'] as String?,
        name: json['name'] as String?,
        descriptions: json['descriptions'] as String?,
        createdAt: json['createdAt'] as String?,
        updatedAt: json['updatedAt'] as String?,
        iV: json['__v'] as int?);
  }
}


class Keyword {

}

class Pagination {
  final int? totalPage;
  final int? currentPage;
  final int? totalRecord;

  Pagination(
      {required this.totalPage,
      required this.currentPage,
      required this.totalRecord});

  factory Pagination.fromJson(Map<String, dynamic> json) {
    return Pagination(
        totalPage: json['totalPage'] as int?,
        currentPage: json['currentPage'] as int?,
        totalRecord: json['totalRecord'] as int?);
  }
}
