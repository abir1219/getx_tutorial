class PostModel{
  final bool? errMsg;
  final String? message;
  final List<Result>? result;
  final Pagination? pagination;

  PostModel({this.errMsg, this.message, this.result,this.pagination});

  factory PostModel.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
    resultData.map((item) => Result.fromJson(item)).toList();
    return PostModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      result: resultList,
      pagination : json['pagination'] != null
          ? new Pagination.fromJson(json['pagination'])
          : null
    );
  }
}

class Result{
  final String? id;
  final String? postContent;
  final QuestionObj? question;
  final String? postType;
  final CreatedBy? createdBy;
  int? likesCount;
  final int? commentsCount;
  bool? isLiked;
  int? dislikesCount;
  bool? isDisliked;
  String? createdAt;

  Result({this.id,this.createdAt, this.postContent,this.question,this.postType,this.createdBy,this.commentsCount,this.dislikesCount,this.isDisliked,this.isLiked,this.likesCount});

  factory Result.fromJson(Map<String,dynamic> json){
    return Result(
      id: json['_id'] as String?,
      postContent: json['postContent'] as String?,
      question: json['question'] != null
          ? new QuestionObj.fromJson(json['question'])
          : null,//json['question'] as String?,
      postType: json['postType'] as String?, createdBy : json['created_by'] != null
            ? new CreatedBy.fromJson(json['created_by'])
            : null,
        commentsCount:json['commentsCount'] as int?,
      dislikesCount: json['dislikesCount'] as int?,
      isDisliked: json['isDisliked'] as bool?,
      isLiked: json['isLiked'] as bool?,
      likesCount: json['likesCount'] as int?,
      createdAt: json['createdAt'] as String?
    );
  }
}

class QuestionObj {
  String? id;
  String? type;

  QuestionObj.fromJson(Map<String, dynamic> json) {
    id = json['_id'];
    type = json['type'];
  }

}

class CreatedBy {
  String? sId;
  String? name;
  // String? createdAt;

  CreatedBy({this.sId, this.name});

  CreatedBy.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
    // createdAt = json['createdAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    return data;
  }
}

class Pagination {
  int? totalPage;
  int? pageSize;
  int? currentPage;
  int? totalRecord;

  Pagination(
      {this.totalPage, this.pageSize, this.currentPage, this.totalRecord});

  Pagination.fromJson(Map<String, dynamic> json) {
    totalPage = json['totalPage'];
    pageSize = json['pageSize'];
    currentPage = json['currentPage'];
    totalRecord = json['totalRecord'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalPage'] = this.totalPage;
    data['pageSize'] = this.pageSize;
    data['currentPage'] = this.currentPage;
    data['totalRecord'] = this.totalRecord;
    return data;
  }
}