class DashboardModel{
  bool? errMsg;
  String? message;
  List<Result>? result;

  DashboardModel({this.errMsg, this.message, this.result});

  factory DashboardModel.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
    resultData.map((item) => Result.fromJson(item)).toList();

    return DashboardModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      result: resultList
    );
  }
}

class Result{
  String? sId;
  String? name;
  int? total;
  int? visited;
  int? point;

  Result({this.sId, this.name, this.total, this.visited, this.point});

  Result.fromJson(Map<String,dynamic> json){
    sId = json['_id'] as String?;
    name = json['name'] as String?;
    total = json['total'] as int?;
    visited = json['visited'] as int?;
    point = json['point'] as int?;
  }
}