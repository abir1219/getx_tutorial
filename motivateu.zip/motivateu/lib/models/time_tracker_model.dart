class TimeTrackerModel{
  bool? errMsg;
  String? message;
  int? usedTime;
  int? leftTime;
  bool? subscribed;

  TimeTrackerModel({this.errMsg, this.message, this.usedTime, this.leftTime,this.subscribed});

  factory TimeTrackerModel.fromJson(Map<String,dynamic> json){
    return TimeTrackerModel(
      errMsg : json['errMsg'] as bool?,
      message : json['message'] as String?,
      usedTime : json['usedTime'] as int?,
      leftTime : json['leftTime'] as int?,
      subscribed : json['subscribed'] as bool?,
    );
  }
}