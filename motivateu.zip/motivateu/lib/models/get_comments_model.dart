class GetCommentsModel{
  bool? errMsg;
  String? message;
  List<Result>? result;

  GetCommentsModel({this.errMsg, this.message, this.result});

  factory GetCommentsModel.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
    resultData.map((item) => Result.fromJson(item)).toList();
    return GetCommentsModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      result: resultList,
    );
  }
}

class Result{
  List<InnerComments>? innerComments;
  String? commentType;
  String? sId;
  String? questionId;
  String? comment;
  // String? userId;
  TaggedUserId? userId;
  String? createdAt;
  String? updatedAt;

  Result({this.innerComments,this.sId,this.comment,this.commentType,this.createdAt,this.questionId,this.updatedAt,this.userId});

  /*Result.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['inner_comment'] ?? [];
    List<InnerComments> resultList =
    resultData.map((item) => InnerComments.fromJson(item)).toList();
    innerComments = resultList;
    commentType = json['comment_type'];
    sId = json['_id'];
    questionId = json['question_id'];
    comment = json['comment'];
    userId = json['user_id'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }*/

  Result.fromJson(Map<String, dynamic> json) {
    if (json['inner_comment'] != null) {
      innerComments = <InnerComments>[];
      json['inner_comment'].forEach((v) {
        innerComments!.add(new InnerComments.fromJson(v));
      });
    }
    commentType = json['comment_type'];
    sId = json['_id'];
    questionId = json['question_id'];
    comment = json['comment'];
    userId = json['user_id'] != null
        ? new TaggedUserId.fromJson(json['user_id'])
        : null;
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }
}

class InnerComments{
  TaggedUserId? taggedUserId;
  String? sId;
  String? comment;
  TaggedUserId? userId;
  String? createdAt;
  String? updatedAt;

  InnerComments(
      {this.taggedUserId,
        this.sId,
        this.comment,
        this.userId,
        this.createdAt,
        this.updatedAt});

  InnerComments.fromJson(Map<String, dynamic> json) {
    taggedUserId = json['tagged_user_id'] != null
        ? new TaggedUserId.fromJson(json['tagged_user_id'])
        : null;
    sId = json['_id'];
    comment = json['comment'];
    userId = json['user_id'] != null
        ? new TaggedUserId.fromJson(json['user_id'])
        : null;
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }
}

class TaggedUserId {
  String? sId;
  String? name;
  String? avatar;

  TaggedUserId({this.sId, this.name, this.avatar});

  TaggedUserId.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
    avatar = json['avatar']??"";
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    data['avatar'] = this.avatar;
    return data;
  }
}

class UserId {
  String? sId;
  String? name;
  String? avatar;

  UserId({this.sId, this.name, this.avatar});

  UserId.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    name = json['name'];
    avatar = json['avatar'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    data['avatar'] = this.avatar;
    return data;
  }
}