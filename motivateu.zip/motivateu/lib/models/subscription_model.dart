class SubscriptionModel{
  final bool? errMsg;
  final String? message;
  final List<Result>? result;

  SubscriptionModel({this.errMsg, this.message, this.result});

  factory SubscriptionModel.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
    resultData.map((item) => Result.fromJson(item)).toList();
    return SubscriptionModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      result: resultList,
    );
  }
}

class Result{
  final int? validDays;
  final int? price;
  final String? description;
  final String? status;
  final String? id;
  final String? name;
  final int? calculatedCgst;
  final int? calculatedSgst;
  final int? totalPrice;
  final HsnCodeDetails? hsnCodeDetails;

  Result({this.validDays, this.price, this.description, this.status, this.id,
    this.name,this.calculatedCgst, this.calculatedSgst, this.totalPrice,this.hsnCodeDetails});

  factory Result.fromJson(Map<String,dynamic> json){
    return Result(
      validDays: json['errMsg'] as int?,
      price: json['price'] as int?,
      description: json['description'] as String?,
      status: json['description'] as String?,
      id: json['_id'] as String?,
      name: json['name'] as String?,
      calculatedSgst: json['calculatedSgst'] as int?,
      calculatedCgst: json['calculatedCgst'] as int?,
      totalPrice: json['totalPrice'] as int?,
      hsnCodeDetails: json['hsnCodeDetails'] != null? HsnCodeDetails.fromJson(json['hsnCodeDetails']) : null,
    );
  }
}

class HsnCodeDetails{
  final String? hsnCode;

  HsnCodeDetails({this.hsnCode});

  factory HsnCodeDetails.fromJson(Map<String,dynamic> json){
    return HsnCodeDetails(
      hsnCode: json['hsnCode'] as String?
    );
  }
}