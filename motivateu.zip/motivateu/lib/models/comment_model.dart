class CommentModel{
  bool? errMsg;
  String? message;
  List<Result>? result;

  CommentModel({this.errMsg, this.message, this.result});

  factory CommentModel.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
    resultData.map((item) => Result.fromJson(item)).toList();

    return CommentModel(
      errMsg: json['errMsg'] as bool?,
      message: json['message'] as String?,
      result: resultList,
    );
  }
}

class Result{
  List<InnerComment>? innerComment;
  String? comment_type;
  String? comment;
  String? createdAt ;
  String? question_id;
  String? user_id;

  Result({this.innerComment, this.comment_type, this.comment, this.createdAt,
    this.question_id, this.user_id});

  factory Result.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['inner_comment'] ?? [];
    List<InnerComment> resultList =
    resultData.map((item) => InnerComment.fromJson(item)).toList();

    return Result(
        innerComment: resultList,
        comment: json['comment'] as String?,
        comment_type: json['comment_type'] as String?,
        createdAt: json['createdAt'] as String?,
        question_id: json['question_id'] as String?,
        user_id: json['user_id'] as String?);
  }
}

class InnerComment{
  List<InnerComment>? innerComment;
  String? comment_type;
  String? sId;
  String? question_id;
  String? comment;
  String? user_id;
  String? createdAt;
  String? updatedAt;
  int? iV;

  InnerComment({this.innerComment, this.comment_type, this.sId, this.question_id,
    this.comment, this.user_id, this.createdAt, this.updatedAt, this.iV});

  factory InnerComment.fromJson(Map<String,dynamic> json){
    List<dynamic> resultData = json['inner_comment'] ?? [];
    List<InnerComment> resultList =
    resultData.map((item) => InnerComment.fromJson(item)).toList();
    return InnerComment(
        innerComment: resultList,
        sId: json['_id'] as String?,
        iV: json['__v'] as int?,
        comment: json['comment'] as String?,
        comment_type: json['comment_type'] as String?,
        createdAt: json['createdAt'] as String?,
        question_id: json['question_id'] as String?,
        user_id: json['user_id'] as String?
    );
  }
}