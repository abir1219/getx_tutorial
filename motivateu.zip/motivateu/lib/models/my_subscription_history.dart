class MySubscriptionHistory {
  bool? errMsg;
  String? message;
  List<Result>? result;

  MySubscriptionHistory({this.errMsg, this.message, this.result});

  factory MySubscriptionHistory.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
        resultData.map((item) => Result.fromJson(item)).toList();

    return MySubscriptionHistory(
        errMsg: json['errMsg'] as bool?,
        message: json['message'] as String?,
        result: resultList);
  }
}

class Result {
  String? startDate;
  String? endDate;
  String? status;
  String? id;
  Subscription? subscription;

  Result(this.startDate, this.endDate, this.status, this.id, this.subscription);

  Result.fromJson(Map<String, dynamic> json) {
    id = json['_id'] as String?;
    startDate = json['startDate'] as String?;
    endDate = json['endDate'] as String?;
    status = json['status'] as String?;
    subscription = json['subscription']!= null?Subscription.fromJson(json['subscription'])
        : null;
  }
}

class Subscription {
  int? validDays;
  int? price;
  String? id;
  String? name;

  Subscription(this.validDays, this.price, this.id,this.name);

  Subscription.fromJson(Map<String, dynamic> json) {
    id = json['_id'] as String?;
    price = json['price'] as int?;
    name = json['name'] as String?;
    validDays = json['validDays'] as int?;
  }
}
