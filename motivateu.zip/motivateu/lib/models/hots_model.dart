class HotsModel{
  bool? errMsg;
  String? message;
  List<Result>? result;

  HotsModel({this.errMsg, this.message,this.result});

    factory HotsModel.fromJson(Map<String,dynamic> json){
      List<dynamic> resultData = json['result'] ?? [];
      List<Result> resultList =
      resultData.map((item) => Result.fromJson(item)).toList();
      return HotsModel(
        errMsg: json['errMsg'] as bool?,
        message: json['message'] as String?,
        result: resultList
      );
    }
}

class Result{
  int? passageCount;
  String? subject;
  String? subjectId;

  Result({this.passageCount, this.subject, this.subjectId});
  Result.fromJson(Map<String,dynamic> json){
    passageCount = json['passageCount'] as int?;
    subject = json['subject'] as String?;
    subjectId = json['subjectId'] as String?;
  }

}