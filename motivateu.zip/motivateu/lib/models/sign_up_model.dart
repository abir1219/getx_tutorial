class SignUpModel {
  final bool? errMsg;
  final String? id;
  final String? accessToken;
  final String? refreshToken;
  final String? message;
  final String? myReferralCode;
  List<Profile>? profile;

  SignUpModel(
      {this.errMsg,
      this.id,
      this.accessToken,
      this.refreshToken,
      this.myReferralCode,
      this.profile,
      this.message});

  factory SignUpModel.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['profile'] ?? [];
    List<Profile> profileList =
        resultData.map((item) => Profile.fromJson(item)).toList();
    return SignUpModel(
        errMsg: json['errMsg'] as bool?,
        id: json['_id'] as String?,
        accessToken: json['accessToken'] as String?,
        refreshToken: json['refreshToken'] as String?,
        myReferralCode: json['myReferralCode'] as String?,
        message: json['message'] as String?,
        profile: profileList);
  }
}

class Profile {
  String? id;

  Profile({this.id});

  Profile.fromJson(Map<String, dynamic> json) {
    id = json['_id'] as String?;
  }
}
