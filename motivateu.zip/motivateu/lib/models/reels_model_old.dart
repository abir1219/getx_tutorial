class ReelsModelOld {
  final String reelsType;
  final List<String>? reelUrls;
  final String? reelsQuestion;
  final List<String>? reelOptions;
  final int? correctAnswer;
  bool answeredCorrectly = false;

  ReelsModelOld({
    required this.reelsType,
    this.reelUrls,
    this.reelsQuestion,
    this.reelOptions,
    this.correctAnswer,
  });

  /*factory ReelsModel.fromJson(Map<String, dynamic> json) {
    return ReelsModel(
      reelsType: json['reels_type'],
      reelUrls: List<String>.from(json['reel_url']),
      reelsQuestion: json['reels_question'],
      reelOptions: json['reel_options'] != null
          ? List<String>.from(json['reel_options'])
          : null,
      correctAnswer: json['correct_answer'],
    );
  }*/
}
