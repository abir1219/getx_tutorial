import 'package:hive/hive.dart';
// part 'data_model_reels.g.dart';

@HiveType(typeId: 1)
class DataModelReels extends HiveObject{
  @HiveField(0)
  bool? errMsg;
  @HiveField(1)
  String? message;
  @HiveField(2)
  List<Result>? result;
  @HiveField(3)
  Pagination? pagination;

  DataModelReels({this.errMsg, this.message, this.result, this.pagination});
}

@HiveType(typeId: 2)
class Pagination {
  @HiveField(0)
  int? totalPage;
  @HiveField(1)
  int? pageSize;
  @HiveField(2)
  int? currentPage;
  @HiveField(3)
  int? totalRecord;

  Pagination({this.totalPage, this.pageSize, this.currentPage, this.totalRecord});
}

@HiveType(typeId: 3)
class Result {
  @HiveField(0)
  String? level;
  @HiveField(1)
  String? status;
  @HiveField(2)
  String? sId;
  @HiveField(3)
  String? type;
  @HiveField(4)
  String? explanation;
  @HiveField(5)
  List<String>? keywords;
  @HiveField(6)
  String? typename;
  @HiveField(7)
  List<Questions>? questions;

  Result({
    this.level,
    this.status,
    this.sId,
    this.type,
    this.explanation,
    this.keywords,
    this.typename,
    this.questions,
  });
}


@HiveType(typeId: 4)
class Board {
  @HiveField(0)
  String? sId;
  @HiveField(1)
  String? name;

  Board({this.sId, this.name});
}

@HiveType(typeId: 5)
class Questions {
  @HiveField(0)
  Quest? quest;
  @HiveField(1)
  String? pasage;
  @HiveField(2)
  List<String>? option;
  @HiveField(3)
  String? sId;
  @HiveField(4)
  int? correctOption;
  @HiveField(5)
  List<Answer>? answer;

  Questions({
    this.quest,
    this.pasage,
    this.option,
    this.sId,
    this.correctOption,
    this.answer,
  });
}

@HiveType(typeId: 6)
class Quest {
  @HiveField(0)
  String? questionValue;
  @HiveField(1)
  String? questionBackground;

  Quest({this.questionValue, this.questionBackground});
}

@HiveType(typeId: 7)
class Answer {
  @HiveField(0)
  String? answerValue;
  @HiveField(1)
  String? answerBackground;
  @HiveField(2)
  String? sId;

  Answer({this.answerValue, this.answerBackground, this.sId});
}