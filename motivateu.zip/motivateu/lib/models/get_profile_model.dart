class GetProfileModel {
  bool? errMsg;
  String? message;
  List<Result>? result;

  GetProfileModel({this.errMsg, this.message, this.result});

  factory GetProfileModel.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
    resultData.map((item) => Result.fromJson(item)).toList();
    return GetProfileModel(
        errMsg: json['errMsg'] as bool?,
        message: json['message'] as String?,
        result: resultList
            //json['result'] != null ? Result.fromJson(json['result']) : null
    );
  }
}

class Result {
  List<Profile>? profile;
  String? sId;
  String? phone;

  Result({this.profile, this.sId, this.phone});

  Result.fromJson(Map<String, dynamic> json) {
    sId = json['_id'] as String?;

    phone = json['phone'] as String?;
    if (json['profile'] != null) {
      profile = <Profile>[];
      json['profile'].forEach((v) {
        profile!.add(Profile.fromJson(v));
      });
    }
  }
}

class Profile {
  String? school;
  List<String>? group;
  String? sId;
  String? name;
  Std? std;
  Medium? medium;
  Board? board;
  String? avatar;
  int? point;

  Profile(
      {this.school,
      this.group,
      this.sId,
      this.name,
      this.std,
      this.medium,
      this.board,
        this.point,
      this.avatar});

  Profile.fromJson(Map<String, dynamic> json) {
    school = json['school'] as String?;
    sId = json['_id'] as String?;
    name = json['name'] as String?;
    name = json['name'] as String?;
    avatar = json['avatar'] as String?;
    point = json['point'] as int?;
    group = json['group'].cast<String>();
    std = json['std'] != null ? Std.fromJson(json['std']) : null;
    medium = json['medium'] != null ? Medium.fromJson(json['medium']) : null;
    board = json['board'] != null ? Board.fromJson(json['board']) : null;
  }
}

class Std {
  String? id;
  String? name;

  Std({this.id, this.name});

  Std.fromJson(Map<String, dynamic> json) {
    id = json['_id'] as String?;
    name = json['name'] as String?;
  }
}

class Medium {
  String? id;
  String? name;

  Medium({this.id, this.name});

  Medium.fromJson(Map<String, dynamic> json) {
    id = json['_id'] as String?;
    name = json['name'] as String?;
  }
}

class Board {
  String? id;
  String? name;

  Board({this.id, this.name});

  Board.fromJson(Map<String, dynamic> json) {
    id = json['_id'] as String?;
    name = json['name'] as String?;
  }
}
