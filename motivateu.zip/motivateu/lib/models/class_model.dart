class ClassModel {
  bool? errMsg;
  String? message;
  List<Result>? result;
  Pagination? pagination;

  ClassModel({this.errMsg, this.message, this.result, this.pagination});

  factory ClassModel.fromJson(Map<String, dynamic> json) {
    List<dynamic> resultData = json['result'] ?? [];
    List<Result> resultList =
        resultData.map((item) => Result.fromJson(item)).toList();

    return ClassModel(
        errMsg: json['errMsg'] as bool?,
        message: json['message'] as String?,
        // pagination: json['pagination'] as Pagination?,
        result: resultList,
        pagination: Pagination.fromJson(json['pagination'] ?? {}));
  } // as List<Result>?

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['errMsg'] = this.errMsg;
    data['message'] = this.message;
    if (this.result != null) {
      data['result'] = this.result!.map((v) => v.toJson()).toList();
    }
    // if (this.pagination != null) {
    //   data['pagination'] = this.pagination!.toJson();
    // }
    return data;
  }
}

class Result {
  String? sId;
  String? name;
  String? descriptions;
  String? createdAt;
  String? updatedAt;
  int? iV;

  Result(
      {this.sId,
      this.name,
      this.descriptions,
      this.createdAt,
      this.updatedAt,
      this.iV});

  factory Result.fromJson(Map<String, dynamic> json) {
    // sId = json['_id'];
    // name = json['name'];
    // descriptions = json['descriptions'];
    // createdAt = json['createdAt'];
    // updatedAt = json['updatedAt'];
    // iV = json['__v'];
    return Result(
        createdAt: json['createdAt'] as String?,
        descriptions: json['descriptions'] as String?,
        iV: json['__v'] as int?,
        name: json['name'] as String?,
        sId: json['_id'] as String?,
        updatedAt: json['updatedAt'] as String?);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['name'] = this.name;
    data['descriptions'] = this.descriptions;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['__v'] = this.iV;
    return data;
  }
}

class Pagination {
  int? totalPage;
  int? currentPage;
  int? totalRecord;

  Pagination({this.totalPage, this.currentPage, this.totalRecord});

  factory Pagination.fromJson(Map<String, dynamic> json) {
    return Pagination(
      totalPage: json['totalPage'] as int?,
      currentPage: json['currentPage'] as int?,
      totalRecord: json['totalRecord'] as int?,
    );
    // totalPage = json['totalPage'];
    // currentPage = json['currentPage'];
    // totalRecord = json['totalRecord'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalPage'] = this.totalPage;
    data['currentPage'] = this.currentPage;
    data['totalRecord'] = this.totalRecord;
    return data;
  }
}
