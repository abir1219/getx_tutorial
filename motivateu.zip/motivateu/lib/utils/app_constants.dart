class AppConstants{
  static String TYPE = "";


  static String DEVICE_ID = "device_id";
  static String PHONE_NUMBER = "phone";
  static String PASSWORD = "password";
  static String ACCESS_TOKEN = "accessToken";
  static String REFRESH_TOKEN = "refreshToken";
  static String LOGIN_TIME = "loginTime";
  static String PROFILE_ID = "profile_id";
  static String ANOTHER_PROFILE_ID = "another_profile_id";
  static String REFERRAL_NO = "";
  static String LEFT_TIME = "left_time";
  static String USED_TIME = "used_time";
  static String isSUBSCRIBED = "isSubscribed";
  static String TOKEN = "token";
  static String isREMEMBERED = "false";
}