import 'package:MotivateU/res/app_colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Utils {

  static void fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }


  static showToastMessage(String msg){
    Fluttertoast.showToast(msg: msg,backgroundColor: AppColors.ON_BOARDING_BUTTON_COLOR);
  }

}
