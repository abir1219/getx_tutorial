import 'dart:convert';
import 'dart:io';

import 'package:MotivateU/firebase_api.dart';
import 'package:MotivateU/models/data_model_mcq.dart';
import 'package:MotivateU/models/time_tracker_model.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/res/routes/app_pages.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:alice/alice.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:path_provider/path_provider.dart' as pathProvider;
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';

import 'controllers/connection_list_controller.dart';
import 'data/app_exceptions.dart';
import 'data/network/network_api_services.dart';
import 'firebase_options.dart';
import 'helper/api_end_points.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:firebase_analytics/firebase_analytics.dart';


final navigatorKey = GlobalKey<NavigatorState>();

Alice alice = Alice(
  // navigatorKey: navigatorKey,
);
var cameraStatus,photoStatus,notificationStatus;

// IO.Socket socket = IO.io('http://192.168.1.184:5007', {
// IO.Socket socket = IO.io('http://192.168.1.177:5007', {
IO.Socket socket = IO.io('https://api.motivateuedutech.com',{
  'transports': ['websocket'],
// 'transport': ['websocket','polling'],
  'timeout': 5000, // set a timeout in milliseconds
});



Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp(
  //   options: DefaultFirebaseOptions.currentPlatform,
  // );
  try {
    // await Firebase.initializeApp();
    await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
    await FirebaseApi().initNotification();
  } catch(e) {
    print("Failed to initialize Firebase: $e");
  }


  // await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // Check if you received the link via `getInitialLink` first
  /*final PendingDynamicLinkData? initialLink = await FirebaseDynamicLinks.instance.getInitialLink();
  if (initialLink != null) {
    final Uri deepLink = initialLink.link;
    // Example of using the dynamic link to push the user to a different screen
    Navigator.pushNamed(context, deepLink.path);
  }*/


  //DefaultFirebaseOptions.currentPlatform,
  Directory directory = await pathProvider.getApplicationDocumentsDirectory();
  Hive.init(directory.path);
  // Check if the box exists before opening it
  if (!Hive.isBoxOpen('motivate_u_mcq')) {
    Hive.registerAdapter(DataModelMcqAdapter());
    await Hive.openBox('motivate_u_mcq');
  } else {
    print('The box motivate_u_mcq already exists.  ');
  }
  // String udid = await FlutterUdid.consistentUdid;
  // // String? deviceId = await PlatformDeviceId.getDeviceId;
  // SharedPreferencesUtils.saveString(AppConstants.DEVICE_ID, udid);

  await SharedPreferencesUtils.init();

  if (SharedPreferencesUtils.containsKey(AppConstants.LOGIN_TIME)) {
    final currentTime = DateTime.now();
    debugPrint("currentTime=>$currentTime");
    final timeDifference = currentTime.difference(DateTime.parse(
        SharedPreferencesUtils.getString(AppConstants.LOGIN_TIME)!));
    debugPrint("timeDifference=>$timeDifference");

    // Define a Duration of 24 hours
    Duration twentyThreeHours = Duration(hours: 23);

    // Check if the time difference is less than 24 hours
    bool isWithin23Hours = (timeDifference >= twentyThreeHours);
    if (isWithin23Hours) {
      debugPrint("isWithin24Hours->$isWithin23Hours");
      await refreshTokenApi();
    }
  }
  if (SharedPreferencesUtils.containsKey(AppConstants.ACCESS_TOKEN)) {
    //accessToken != "accessToken"
    debugPrint(".........call getTimeApiCall function.........");
    await getTimeApiCall();
  }

  SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(statusBarColor: AppColors.BOTTOM_SHEET_BACKGROUND));

  runApp(
    // DevicePreview(
    // enabled: !kReleaseMode,
    // builder: (context) =>
    // const DynamicLinksWidgetHandler(
    //   child:
      MyApp(),
    // ), // Wrap your app
    // ),
    // Initialize InternetCheckController and check for internet connection
    // internetCheckController.checkInternetConnection();
  );

//To stop screen recording
  /*WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
    if (Platform.isAndroid) {
      await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
    }
  });*/
}



Future<void> getTimeApiCall() async {
  SharedPreferencesUtils.init();
  debugPrint(
      "----LEFT TIME MAIN---- ${SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)}");
  TimeTrackerModel model = TimeTrackerModel();
  final _apiClient = NetworkApiServices();
  var url = ApiEndPoints.baseUrl +
      ApiEndPoints.authEndpoints.GET_FREE_MINUTES +
      "/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}";
  _apiClient.getApi(url).then((value) {
    debugPrint(".........call getTimeApiCall response.........\n${value}");
    model = TimeTrackerModel.fromJson(value);
    if (!model.subscribed!) {
      SharedPreferencesUtils.saveInt(AppConstants.LEFT_TIME, model.leftTime!);
      // SharedPreferencesUtils.saveInt(AppConstants.LEFT_TIME, 60000);
      SharedPreferencesUtils.saveInt(AppConstants.USED_TIME, model.usedTime!);
      SharedPreferencesUtils.saveBool(
          AppConstants.isSUBSCRIBED, model.subscribed!);
    } else {
      SharedPreferencesUtils.saveBool(
          AppConstants.isSUBSCRIBED, model.subscribed!);
    }
    debugPrint(
        ".........call getTimeApiCall leftTime.........\n${model.leftTime}");
  });
}


Future<void> refreshTokenApi() async {
  debugPrint("refreshToken");
  // final repo = RefreshTokenRepo();

  Map<String, String> headers = {
    'Content-Type': 'application/json',
    //'device_id' : '${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}'
  };

  //await SharedPreferencesUtils.init();
  var refreshToken =
      SharedPreferencesUtils.getString(AppConstants.REFRESH_TOKEN);
  debugPrint("refreshToken->${refreshToken}");

  Map<String, dynamic> body = {
    'refreshToken':
        '${SharedPreferencesUtils.getString(AppConstants.REFRESH_TOKEN)}'
  };

  debugPrint("body->${jsonEncode(body)}");

  String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.RefreshToken;
  debugPrint("url->$url");
  try {
    final response = await http.post(Uri.parse(url),
        body: jsonEncode(body), headers: headers);
    if (kDebugMode) alice.onHttpResponse(response);
    if (kDebugMode) alice.showInspector();
    if (response.statusCode == 401) {
      // await SharedPreferencesUtils.init();
      SharedPreferencesUtils.clear();
      Get.toNamed(AppRoutes.login);
    } else if (response.statusCode == 200) {
      var body = jsonDecode(response.body);
      debugPrint("token->${body['accessToken']}");
      await SharedPreferencesUtils.init();
      SharedPreferencesUtils.saveString(
          AppConstants.ACCESS_TOKEN, body['accessToken']);
    }
  } on SocketException {
    throw NoInternetException();
  } on RequestTimeOut {
    throw RequestTimeOut();
  }

  /*repo.refreshToken(body).then((value) {
      SharedPreferencesUtils.saveString(
          AppConstants.ACCESS_TOKEN, value['accessToken']);
    }).onError((error, stackTrace) {
      refreshTokenApi();
      debugPrint("REFRESH_TOKEN_ERROR->$error");
    });*/
}

Future<void> setUpPermission() async{
  debugPrint("sdfhkjsdfhlsd");

  cameraStatus = await Permission.camera.status;
  photoStatus = await Permission.photos.status;
  notificationStatus = await Permission.notification.status;

  debugPrint("CameraStatus01==>$cameraStatus\nPhotoStatus==>$photoStatus\nNotificationStatus==>$notificationStatus");

  if(cameraStatus != PermissionStatus.granted){
    await Permission.camera.request();
    //setState(() {});
  }
  if(photoStatus != PermissionStatus.granted){
    await Permission.photos.request();
    // setState(() {});
  }
  if(notificationStatus != PermissionStatus.granted){
    debugPrint("--------------------------------");
    await Permission.notification.request();
    // setState(() {});
  }
  // photoStatus = await Permission.photos.request();
  // notificationStatus = await Permission.notification.request();

  debugPrint("CameraStatus02==>$cameraStatus\nPhotoStatus==>$photoStatus\nNotificationStatus==>$notificationStatus");
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.
  late IO.Socket _socket;
  // FirebaseAnalytics analytics = FirebaseAnalytics.instance;

  /*_connectionSocket(){

    print("SOCket->${_socket.connected}");
    _socket.onConnect((data) => print("Connection Established"));
    _socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    _socket.onDisconnect((data) => print("Socket server disconnected"));
    print("SOCket->${_socket.json.connected}");
  }*/

  // final PermissionController permissionController = Get.put(PermissionController());

  final InAppReview inAppReview = InAppReview.instance;
  static FirebaseAnalytics analytics = FirebaseAnalytics.instance;
  static FirebaseAnalyticsObserver observer =
  FirebaseAnalyticsObserver(analytics: analytics);

  @override
  Widget build(BuildContext context) {
    // permissionController.requestPermissions();

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      // DeviceOrientation.portraitDown,
      // DeviceOrientation.landscapeLeft,
      // DeviceOrientation.landscapeRight,
    ]);

    return ScreenUtilInit(
        designSize: const Size(375, 812),
        builder: (context, child) {
          return GetMaterialApp(
            debugShowCheckedModeBanner: false,
          //     navigatorObservers: [
          //     FirebaseAnalyticsObserver(analytics: FirebaseAnalytics.instance)
          // ],
            title: 'MotivateU',
            navigatorObservers: <NavigatorObserver>[observer],
            navigatorKey: navigatorKey,//alice.getNavigatorKey(),
            theme: ThemeData(
                // colorScheme: ColorScheme.fromSeed(seedColor: Colors.white),
                colorScheme: ColorScheme.light(
                  primary: Colors.blue,
                  // Change this to your desired primary color
                  secondary: Colors
                      .green, // Change this to your desired secondary color
                ),
                useMaterial3: false,
                visualDensity: VisualDensity.adaptivePlatformDensity),
            // initialBinding: OnBoardingBinding(),
            getPages: AppPages.pages,
            initialBinding: BindingsBuilder(() {
              // Get.put<ConnectionListScreen>(ConnectionListScreen());
              Get.put<ConnectionListController>(ConnectionListController());
              // You can put other controllers or dependencies here
            }),
            initialRoute: AppRoutes.initial,
            // home: const SplashScreen(), //MyHomePage(title: 'Flutter Demo Home Page'),
          );
        });
  }

  @override
  void initState() {
    super.initState();
    // _socket = IO.io('wss://api.motivateuedutech.com'
    // _socket = IO.io('http://192.168.1.184:5007'
    //     // ,IO.OptionBuilder()
    //     //     .setTransports(['websocket']) // for Flutter or Dart VM
    //     //    // .disableAutoConnect() // disable auto-connection
    //     // //.setExtraHeaders({'foo': 'bar'}) // optional
    //     //     .build()
    // );

    /*_socket = IO.io('http://192.168.1.184:5007', {
    // _socket = IO.io('https://api.motivateuedutech.com',{
      'transports': ['websocket'],
      // 'transport': ['websocket','polling'],
     'timeout': 5000, // set a timeout in milliseconds
    });
    _connectionSocket();*/
    // inAppReviewFunc();
    // debugPrint("--analytics--${analytics.app.name}");
    setUpPermission();

  }

  Future<void> inAppReviewFunc() async{
    // Utils.showToastMessage("${await inAppReview.isAvailable()}");
    if (await inAppReview.isAvailable()) {
    // inAppReview.requestReview();
    inAppReview.openStoreListing(appStoreId: '',microsoftStoreId: '');
    }else{
      debugPrint("Not Available");
    }
  }



}
