import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import '../controllers/comment_controller.dart';
import '../helper/api_end_points.dart';
import '../res/app_colors.dart';

class PostCommentListScreen extends StatefulWidget {
  final String postId;

  const PostCommentListScreen({super.key, required this.postId});

  @override
  State<PostCommentListScreen> createState() => _PostCommentListScreenState();
}

class _PostCommentListScreenState extends State<PostCommentListScreen> {
  var controller = Get.isRegistered<CommentController>()
      ? Get.find<CommentController>()
      : Get.put(CommentController());

  @override
  void initState() {
    super.initState();
    // controller.getComments('64f5664175ebf2323060cdde');
    controller.getComments(widget.postId);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      // height: 450.h,
      child: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (OverscrollIndicatorNotification notification) {
          notification.disallowIndicator();
          return true;
        },
        child: Obx(
          () => controller.isCommentsLoading.value
              ? Container(
                  width: double.maxFinite,
                  margin: EdgeInsets.only(top: 5.h),
                  // height: double.maxFinite,
                  child: Center(
                    child: SizedBox(
                      height: 24.h,
                      width: 24.w,
                      child: CircularProgressIndicator(
                        color: Colors.black,
                      ),
                    ),
                  ),
                )
              : controller.getCommentsModel.value.result!.length > 0
                  ? NotificationListener<OverscrollIndicatorNotification>(
                      onNotification:
                          (OverscrollIndicatorNotification notification) {
                        notification.disallowIndicator();
                        return true;
                      },
                      child: ListView.builder(
                        itemCount:
                            controller.getCommentsModel.value.result!.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return Container(
                            margin: EdgeInsets.symmetric(
                                vertical: 5.h, horizontal: 10.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 18,
                                      backgroundImage: NetworkImage(controller
                                                  .getCommentsModel
                                                  .value
                                                  .result![index]
                                                  .userId!
                                                  .avatar != ""
                                          /*|| controller
                                                      .getCommentsModel
                                                      .value
                                                      .result![index]
                                                      .userId!
                                                      .avatar !=
                                                  null*/
                                          ? ApiEndPoints.IMAGE_URL +
                                              "" +
                                              controller
                                                  .getCommentsModel
                                                  .value
                                                  .result![index]
                                                  .userId!
                                                  .avatar!
                                          : "https://media.istockphoto.com/id/1300845620/vector/user-icon-flat-isolated-on-white-background-user-symbol-vector-illustration.jpg?s=612x612&w=0&k=20&c=yBeyba0hUkh14_jgv1OKqIH0CCSWU_4ckRkAoy2p73o="),
                                    ),
                                    Expanded(
                                      child: Container(
                                        margin: EdgeInsets.only(left: 5),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisSize: MainAxisSize.max,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Container(
                                                    child: Text(
                                                  "${controller.getCommentsModel.value.result![index].userId!.name}",
                                                  style: TextStyle(
                                                      fontSize: 14.sp,
                                                      color: Colors.black,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      fontFamily: "Alata"),
                                                )),
                                                Container(
                                                    margin: EdgeInsets.only(
                                                        right: 8.w),
                                                    child: Text(
                                                      "${controller.getCommentsModel.value.result![index].createdAt!}",
                                                      style: TextStyle(
                                                          fontSize: 12.sp,
                                                          color: Colors.grey,
                                                          fontFamily: "Alata"),
                                                    )),
                                              ],
                                            ),
                                            Container(
                                                margin: EdgeInsets.symmetric(
                                                    horizontal: 4.w,
                                                    vertical: 4.h),
                                                child: Text(
                                                    "${controller.getCommentsModel.value.result![index].comment}",
                                                    style: TextStyle(
                                                        fontSize: 14.sp,
                                                        color: AppColors
                                                            .TITLE_TEXT_BLACK,
                                                        fontFamily: "Alata"))),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                buildInteractiveIcons(context, "main", index),
                                buildReplyComments(context, index),
                              ],
                            ),
                          );
                        },
                      ),
                    )
                  : Container(
                      width: double.maxFinite,
                      height: double.maxFinite,
                      child: Center(child: Text("No Comments")),
                    ),
        ),
      ),
    );
  }

  buildInteractiveIcons(BuildContext context, String type, int index,
      [int? innerIndex]) {
    return Container(
      margin: EdgeInsets.only(left: 50.w, top: 4.h),
      child: Row(
        children: [
          GestureDetector(
              onTap: () {
                controller.commentType.value = "inner";
                if (type == "main") {
                  controller.addUserName(controller
                      .getCommentsModel.value.result![index].userId!.name!);
                  controller.commentId.value =
                      controller.getCommentsModel.value.result![index].sId!;
                  controller.tagged_user_id.value = controller
                      .getCommentsModel.value.result![index].userId!.sId!;
                } else if (type == "inner") {
                  controller.addUserName(controller
                      .getCommentsModel
                      .value
                      .result![index]
                      .innerComments![innerIndex!]
                      .userId!
                      .name!);
                  controller.commentId.value = controller.getCommentsModel.value
                      .result![index].innerComments![innerIndex].sId!;
                  controller.tagged_user_id.value = controller
                      .getCommentsModel
                      .value
                      .result![index]
                      .innerComments![innerIndex]
                      .userId!
                      .sId!;
                }
              },
              child: Container(
                  child: Text("Reply",
                      style: TextStyle(
                          fontSize: 14.sp,
                          color: Colors.grey,
                          fontFamily: "Alata")))),
          Gap(10.w),
          GestureDetector(
            onTap: () {
              if (type == "main") {
                showDialog(
                    context: context,
                    builder: (context) => showAlertDialog(
                        controller.getCommentsModel.value.result![index].sId,
                        index));
              } else if (type == "inner") {
                showDialog(
                    context: context,
                    builder: (context) => showAlertDialog(
                        controller.getCommentsModel.value.result![index]
                            .innerComments![innerIndex!].sId!,
                        index));
              }
            },
            child: Container(
                child: Text("Delete",
                    style: TextStyle(
                        fontSize: 14.sp,
                        color: Colors.grey,
                        fontFamily: "Alata"))),
          ),
        ],
      ),
    );
  }

  Widget showAlertDialog(String? sId, int index) {
    debugPrint("SID===========>$sId");
    return AlertDialog(
      title: Text(
        "Are you sure you want to delete this comment?",
        style: TextStyle(
            fontSize: 14.sp,
            color: Colors.grey,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.normal),
      ),
      actions: <Widget>[
        TextButton(
          style: TextButton.styleFrom(
            textStyle: Theme.of(context).textTheme.labelLarge,
          ),
          child: Text('CANCEL',
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.grey,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.normal,
              )),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          style: TextButton.styleFrom(
            textStyle: Theme.of(context).textTheme.labelLarge,
          ),
          child: Text('DELETE',
              style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.blue,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.normal)),
          onPressed: () {
            controller.deletePostComment(
                sId, () => controller.getComments(widget.postId));
            Navigator.of(context).pop();
            setState(() {});
          },
        ),
      ],
    );
  }

  buildReplyComments(BuildContext context, int index) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemBuilder: (context, i) {
        return Container(
          margin: EdgeInsets.only(left: 24.w, top: 10.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 15,
                    backgroundImage: NetworkImage(controller
                                .getCommentsModel
                                .value
                                .result![index]
                                .innerComments![i]
                                .userId!
                                .avatar !=
                            ""
                        ? ApiEndPoints.IMAGE_URL +
                            "" +
                            controller.getCommentsModel.value.result![index]
                                .innerComments![i].userId!.avatar!
                        : "https://media.istockphoto.com/id/1300845620/vector/user-icon-flat-isolated-on-white-background-user-symbol-vector-illustration.jpg?s=612x612&w=0&k=20&c=yBeyba0hUkh14_jgv1OKqIH0CCSWU_4ckRkAoy2p73o="),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                                child: Text(
                              "${controller.getCommentsModel.value.result![index].innerComments![i].userId!.name}",
                              style: TextStyle(
                                  fontSize: 13.sp,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "Alata"),
                            )),
                            Container(
                                margin: EdgeInsets.only(right: 8.w),
                                child: Text(
                                  "${controller.getCommentsModel.value.result![index].innerComments![i].createdAt}",
                                  style: TextStyle(
                                      fontSize: 11.sp,
                                      color: Colors.grey,
                                      fontFamily: "Alata"),
                                )),
                          ],
                        ),
                        Container(
                            margin: EdgeInsets.symmetric(
                                horizontal: 4.w, vertical: 4.h),
                            child: Text(
                                "${controller.getCommentsModel.value.result![index].innerComments![i].comment}",
                                style: TextStyle(
                                    fontSize: 13.sp,
                                    color: AppColors.TITLE_TEXT_BLACK,
                                    fontFamily: "Alata"))),
                      ],
                    ),
                  ),
                ],
              ),
              buildInteractiveIcons(context, "inner", index, i),
              // buildReplyComments(context),
            ],
          ),
        );
      },
      itemCount: controller
          .getCommentsModel.value.result![index].innerComments!.length,
    );
  }
}
