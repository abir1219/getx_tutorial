import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import '../controllers/reels_controller.dart';
import '../helper/api_end_points.dart';
import '../main.dart';
import '../res/app_colors.dart';
import '../widgets/qreels_widget.dart';

class ShortReels extends StatefulWidget {
  final int index;

  const ShortReels({super.key, required this.index});

  @override
  State<ShortReels> createState() => _ShortReelsState();
}

class _ShortReelsState extends State<ShortReels> {
  dynamic socketData;
  var result;
  @override
  void initState() {
    super.initState();
    /*if(socket.connected){
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        socketData = data['data'];
      });
    }*/

  }

  @override
  void dispose() {
    super.dispose();
    debugPrint("<<<<<Short_DISPOSE>>>>>");
  }

  @override
  Widget build(BuildContext context) {

    result =
    Get.find<ReelsController>().reelsList![widget.index];

    if(socket.connected){
      debugPrint("<<<<<Short_DATA>>>>> ${result.sId}");
      //socket.emit('reel-action',result.sId);
      //socket.on('reel-action', (data) => debugPrint("<<<<<DATA>>>>> $data"));
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        /*setState(() {
              socketData = data['data'];
            });*/
        // Get.find<ReelsController>().socketData = data['data'];
        Get.find<ReelsController>().socketData.assignAll(data['data']);
        debugPrint("<<<<<socketData short>>>>> ${socketData}");


      });
    }
    debugPrint("<<<<<Short_build>>>>>");

    return Container(
      height: double.maxFinite,
      width: double.maxFinite,
      // color: Colors.red,
      decoration: BoxDecoration(
         /* gradient: result.questions![0].quest!.questionBackground == ""
              ? LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.purple, Colors.orange])
              : null,*/
          // color: result.questions![0].quest!.questionBackground == ""?Colors.white:null,
          color: result.questions![0].quest!.questionBackground == "" ||
              result.questions![0].quest!.questionBackground == null
              ? Colors.transparent
              : Colors.black,
          image: result.questions![0].quest!.questionBackground != ""
              ? DecorationImage(
              image: NetworkImage(
                  ApiEndPoints.IMAGE_URL+result.questions![0].quest!.questionBackground!),
              fit: BoxFit.cover)
              : null),
      child: Scaffold(
          //backgroundColor:
              // result.questions![0].quest!.questionBackground == ""
              //     ? AppColors.BOTTOM_SHEET_BACKGROUND.withOpacity(0.85) :
              //Colors.transparent,
          body: Stack(
            children: [
              Container(
                width: double.maxFinite,
                //padding: EdgeInsets.only(left: 8.w, right: 8.w),
                decoration:
                BoxDecoration(
                    color: result.questionObj!.questions![0].answer![0].answerBackground ==
                        ""||
                        result.questionObj!.questions![0].quest!.questionBackground==null?Colors.black:Colors.transparent,
                    image: result.questionObj!.questions![0].answer![0].answerBackground !=
                        ""
                        ? DecorationImage(
                        image: NetworkImage('${ApiEndPoints.IMAGE_URL}${result.questionObj!.questions![0]
                            .answer![0].answerBackground!}'),
                        fit: BoxFit.cover,
                        opacity: 0.45
                    )
                        : null),

                /*BoxDecoration(
                    color: result.questions![0].answer![0].answerBackground !=
                        ""?Colors.black:Colors.transparent,
                    image: result.questions![0].answer![0].answerBackground !=
                        ""
                        ? DecorationImage(
                        image: NetworkImage(ApiEndPoints.IMAGE_URL+result.questions![0]
                            .answer![0].answerBackground!),
                        fit: BoxFit.cover,
                        opacity: 0.45
                    )
                        : null),*/
                child: Container(
                  margin: EdgeInsets.only(right: 50),
                  padding: EdgeInsets.only(left: 12.w,top: 20.h,bottom: 20.h),
                  color: Colors.black.withOpacity(0.3),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10.w,vertical: 10.h),
                        decoration: BoxDecoration(
                            color: AppColors.BOTTOM_SHEET_BACKGROUND,
                            borderRadius: BorderRadius.circular(10.w)
                        ),
                        child: TeXView(
                            child: TeXViewDocument(
                                "Question:${result.questionObj!.questions![0].quest!.questionValue!}",
                                style: result.questionObj!.questions![0].quest!.questionBackground==""||
                                    result.questionObj!.questions![0].quest!.questionBackground==null?const TeXViewStyle.fromCSS(
                                  'font-size: 16px; font-weight: bold; color: white;text-align:center;font-family:"Alata";text-align:left',
                                ):const TeXViewStyle.fromCSS(
                                  'font-size: 16px; font-weight: bold; color: white;text-align:center;font-family:"Alata";text-align:left',
                                )
                            )
                        ),
                      ),
                      // Text(
                      //   result.questions![0].quest!.questionValue!,
                      //   style: TextStyle(fontSize: 22.0,fontWeight: FontWeight.bold,color: Colors.white,fontFamily: "Alata"),
                      // ),
                      Gap(20.h),
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10.w,vertical: 10.h),
                        decoration: BoxDecoration(
                            color: AppColors.BOTTOM_SHEET_BACKGROUND,
                            borderRadius: BorderRadius.circular(10.w)
                        ),
                        child: TeXView(
                          child: TeXViewDocument(
                              "Ans-:${result.questionObj!.questions![0].answer![0].answerValue!}",
                              style: result.questionObj!.questions![0].quest!.questionBackground==""||
                                  result.questionObj!.questions![0].quest!.questionBackground==null?const TeXViewStyle.fromCSS(
                                'font-size: 16px; font-weight: bold; color: white;text-align:center;font-family:"Alata";text-align:left',
                              ):const TeXViewStyle.fromCSS(
                                'font-size: 16px; font-weight: bold; color: white;text-align:center;font-family:"Alata";text-align:left',
                              )
                          ),
                        ),
                      ),
                      // Text(
                      //   result.questions![0].answer![0].answerValue!,
                      //   style: TextStyle(fontSize: 20.0,color: Colors.white,height:1.3,fontFamily: "Alata"),
                      // ),
                    ],
                    /*children: [
                      TeXView(
                        child: TeXViewDocument(
                            result.questions![0].quest!.questionValue!,
                            style: result.questions![0].quest!.questionBackground==""?TeXViewStyle.fromCSS(
                              'font-size: 18px; font-weight: bold; color: black;text-align:center;font-family:"Alata"',
                            ):TeXViewStyle.fromCSS(
                              'font-size: 18px; font-weight: bold; color: white;text-align:center;font-family:"Alata"',
                            )
                        ),
                      ),
                      // Text(
                      //   result.questions![0].quest!.questionValue!,
                      //   style: TextStyle(fontSize: 22.0,fontWeight: FontWeight.bold,color: Colors.white,fontFamily: "Alata"),
                      // ),
                      Gap(10.h),
                      TeXView(
                        child: TeXViewDocument(
                            result.questions![0].answer![0].answerValue!,
                            style: result.questions![0].quest!.questionBackground==""?TeXViewStyle.fromCSS(
                              'font-size: 16px; font-weight: bold; color: black;text-align:center;font-family:"Alata"',
                            ):TeXViewStyle.fromCSS(
                              'font-size: 16px; font-weight: bold; color: white;text-align:center;font-family:"Alata"',
                            )
                        ),
                      ),
                      // Text(
                      //   result.questions![0].answer![0].answerValue!,
                      //   style: TextStyle(fontSize: 20.0,color: Colors.white,height:1.3,fontFamily: "Alata"),
                      // ),
                    ],*/
                  ),
                ),
              ),
              Positioned(
                left: 0,
                bottom: 0,
                child: footerKeyword(keyword: result.keywords),
              ),
              Positioned(right: 0, bottom: 0,child: Obx(() => interactiveIcons(reelsId: result.sId!,context: context,isBackground:result.questions![0].quest!.questionBackground == ""?false:true, result: result,socketData: Get.find<ReelsController>().socketData))),
            ],
          )),
    );
  }
}
