import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/widgets/sign_up_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: WillPopScope(
          onWillPop: () async{
            Get.offNamed(AppRoutes.login);
            return false;
          },
          child: Scaffold(
      body: Container(
          height: double.maxFinite,
          decoration: BoxDecoration(
              // color: Colors.red,
              image: DecorationImage(
                  image: AssetImage("assets/icons/login_bg.jpg"),
                  fit: BoxFit.cover
              )
          ),
          child: SignUpWidget(),
      ),
    ),
        ));
  }
}
