import 'package:MotivateU/screens/sent_pending_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../controllers/connection_list_controller.dart';
import '../res/app_colors.dart';
import '../res/routes/app_routes.dart';
import '../widgets/q_connect_header_top.dart';
import 'connection_list_screen.dart';

class SearchConnect extends StatefulWidget {
  const SearchConnect({super.key});

  @override
  State<SearchConnect> createState() => _SearchConnectState();
}

class _SearchConnectState extends State<SearchConnect> {
  int selectedIndex = 1;
  
  var controller = Get.find<ConnectionListController>();

  @override
  void initState() {
    super.initState();
    // controller.getConnection(1);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: WillPopScope(
      onWillPop: () async {
        // Get.offNamed(AppRoutes.dashboard,arguments: [3]);
        Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'3'});
        return true;
      },
      child: Scaffold(
          body: Container(
            height: double.maxFinite,
            width: double.maxFinite,
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("assets/icons/login_bg.jpg"),
                    fit: BoxFit.cover)),
            child: Column(
              children: [
                QConnectHeaderTop(),
                Gap(20.h),
                Container(
                  width: double.maxFinite,
                  color: Colors.white,
                  margin: EdgeInsets.symmetric(horizontal: 10.w,vertical: 10.h),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        buildTagButton(context,'Connections',() {
                          setState(() {
                            selectedIndex = 1;
                          });
                        },1),
                        buildTagButton(context,'Sent List',() {
                          setState(() {
                            selectedIndex = 2;
                          });
                        },2),
                        buildTagButton(context,'Pending List',() {
                          setState(() {
                            selectedIndex = 3;
                          });
                        },3),
                      ],
                    ),
                  ),
                ),
                Container(
                  height: 65.h,
                  margin: EdgeInsets.only(top: 10.h,left: 10.w,right: 10.w),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8.w),
                      color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR
                  ),
                  child:  Center(child: Container(
                    height: 45,
                    margin: EdgeInsets.symmetric(horizontal: 15.w),
                    padding: EdgeInsets.only(left: 10.w),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(30.w)
                    ),
                    child: TextField(
                      controller: controller.searchTextController.value,
                      onChanged: (value) {
                        //controller.connectionList!.clear();
                        controller.getConnection(1);
                      },
                      decoration: InputDecoration(
                        hintText: "Search connections...",
                        suffixIcon: Obx(() => controller.searchTextController.value.text.length > 0?
                          IconButton(onPressed: () {
                            controller.getConnection(1);
                            controller.searchTextController.value.text = "";
                          }, icon: Icon(Icons.close,color: Color(0xFFB8C2C6),))
                          :Icon(Icons.search,color: Color(0xFFB8C2C6),),
                        ),
                        hintStyle: TextStyle(
                            color: AppColors.FIELD_HINT_COLOR,
                            fontFamily: 'Poppins',
                            fontSize: 14.sp),
                        border: InputBorder.none,
                        focusColor: Colors.transparent,
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none,
                      ),
                    ),
                  )),
                ),
                if(selectedIndex == 1)
                  Expanded(child: ConnectionListScreen()),
                if(selectedIndex == 2)
                  Expanded(child: SentPendingScreen(type: 'self',)),
                if(selectedIndex == 3)
                  Expanded(child: SentPendingScreen(type: '',)),
              ],
            ),
          )
      ),
    ));
  }

  Widget buildTagButton(
      BuildContext context, String title, void Function() func,int position) {
    return GestureDetector(
      onTap: () {
        func();
        setState(() {
          selectedIndex = position;
        });
      },
      child: Container(
        height: 40.h,
        // width: MediaQuery.of(context).size.width * 0.3,
        margin: EdgeInsets.symmetric(horizontal: 4.w),
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 6.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(100.sp),
          color: selectedIndex == position?AppColors.BOTTOM_SHEET_BACKGROUND:AppColors.ACCOUNT_PAGE_BUTTON_BG_COLOR,
        ),
        child: Center(
          child: Text(title,
              style: TextStyle(
                  color: selectedIndex == position?AppColors.TITLE_TEXT_WHITE:AppColors.ON_BOARDING_BUTTON_COLOR, fontSize: 12.sp)),
        ),
      ),
    );
  }
}
