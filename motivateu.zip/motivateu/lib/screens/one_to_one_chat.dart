import 'package:MotivateU/controllers/chat_controller.dart';
import 'package:MotivateU/main.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/widgets/qconnect_reusable_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../widgets/one_to_one_chat_widget.dart';

class OneToOneChat extends StatefulWidget {
  const OneToOneChat({super.key});

  @override
  State<OneToOneChat> createState() => _OneToOneChatState();
}

class _OneToOneChatState extends State<OneToOneChat> {
  var controller = Get.find<ChatController>();
  var roomId = "";
  var participantName = "";


  @override
  void initState() {
    super.initState();
    if(Get.arguments!=null){
      roomId = Get.arguments[0];
      participantName = Get.arguments[1];
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: WillPopScope(
        onWillPop: () async{
          Get.offNamed(AppRoutes.ChatHistoryList);
          socket.emit('leave',roomId);
          return true;
        },
        child: Scaffold(
          appBar: PreferredSize(preferredSize: Size.fromHeight(70.h),
          child: Padding(padding: EdgeInsets.only(top: 5.h),
          child: AppBar(
            backgroundColor: Colors.white,
            elevation: 0.5,
            leadingWidth: 30.w,
            leading: BackButton(
              color: Colors.black,
              onPressed: () => Get.offNamed(AppRoutes.ChatHistoryList),
            ),
            title: Row(
              children: [
                CircleAvatar(
                  backgroundImage: AssetImage("assets/icons/avatar_img.png"),
                  radius: 20,
                ),
                reusableTitleText("$participantName"),
              ],
            ),
          ),
          ),),
          body: Container(
            height: double.maxFinite,
            color: Colors.white,
            child: OneToOneChatWidget(roomId: roomId,),
          ),
        ),
      ),
    );
  }
}
