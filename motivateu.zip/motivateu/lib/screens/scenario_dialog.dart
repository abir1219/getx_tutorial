import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:gap/gap.dart';

import '../models/reels_model.dart';

class ScenarioDialog extends StatefulWidget {
  final Scenario scenario;
  const ScenarioDialog({super.key, required this.scenario});

  @override
  State<ScenarioDialog> createState() => _ScenarioDialogState();
}

class _ScenarioDialogState extends State<ScenarioDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
      ),
      child: Container(
        width: double.infinity,
       // height: double.infinity,
        padding: const EdgeInsets.all(4.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Align(
              alignment: Alignment.topRight,
              child: IconButton(
                icon: const Icon(Icons.close),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ),
            Gap(15.h),
            // Add your dialog content here
            Text(widget.scenario.title!,style: TextStyle(fontSize: 18.sp,fontFamily: 'Alata',color: Colors.black, fontWeight: FontWeight.bold),),
            Gap(15.h),
            Expanded(
              child: Scrollbar(
                child: SingleChildScrollView(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 10.w),
                    padding: EdgeInsets.only(top: 8.h),
                    // padding: EdgeInsets.symmetric(vertical: 4.h),
                    child: TeXView(
                      child: TeXViewDocument(
                          widget.scenario.passageValue!,
                          style: const TeXViewStyle.fromCSS(
                            'font-size: 16px; font-weight: normal; color: black; font-family:Alata',
                          )),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
