import 'package:MotivateU/controllers/sign_up_controller.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:get/get.dart';

import '../controllers/performance_controller.dart';

class TermsCondition extends StatefulWidget {
  const TermsCondition({super.key});

  @override
  State<TermsCondition> createState() => _TermsConditionState();
}

class _TermsConditionState extends State<TermsCondition> {
  var controller;
  var tnc = "";

  @override
  void initState() {
    super.initState();
    iniSp();
  }

  Future<void> iniSp() async {
    await SharedPreferencesUtils.init();
    if (SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN) != null) {
      /*controller = Get.isRegistered<PerformanceController>()
          ? Get.find<PerformanceController>().tncData.value.result!.termsAndCondition
          : Get.put(PerformanceController()).tncData.value.result!.termsAndCondition;*/
      tnc = (Get.isRegistered<PerformanceController>()
          ? Get.find<PerformanceController>()
              .tncData
              .value
              .lastAcceptTerms!
              .termsAndCondition
          : Get.put(PerformanceController())
              .tncData
              .value
              .lastAcceptTerms!
              .termsAndCondition)!;
      //controller.tncData.value.result!.termsAndCondition;
    } else {
      /*controller = Get.isRegistered<SignUpController>()
          ? Get.find<SignUpController>()
          : Get.put(SignUpController());*/

      tnc = (Get.isRegistered<SignUpController>()
          ? Get.find<SignUpController>().tncData.value.result!.termsAndCondition
          : Get.put(SignUpController())
              .tncData
              .value
              .result!
              .termsAndCondition)!;
      //controller.tncData.value.lastAcceptTerms!.termsAndCondition;
    }
  }

  /*Get.isRegistered<SignUpController>()
      ? Get.find<SignUpController>()
      : Get.put(SignUpController());*/

  /*var perfController = Get.isRegistered<PerformanceController>()
      ? Get.find<PerformanceController>()
      : Get.put(PerformanceController());*/

  //Get.find<SignUpController>();
  final _scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          // mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              margin: EdgeInsets.symmetric(vertical: 12.h),
              child: Center(
                child: Text(
                  "Terms & Conditions",
                  style: TextStyle(
                      fontSize: 14.sp,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Poppins"),
                ),
              ),
            ),
            Expanded(
              child: Scrollbar(
                controller: _scrollController,
                thickness: 5,
                //trackVisibility: true,
                interactive: true,
                thumbVisibility: true,
                child: NotificationListener<OverscrollIndicatorNotification>(
                  onNotification:
                      (OverscrollIndicatorNotification notification) {
                    notification.disallowIndicator();
                    return true;
                  },
                  child: SingleChildScrollView(
                    controller: _scrollController,
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12.w),
                      child: TeXView(
                        child: TeXViewDocument(
                            //"${tnc}",
                            "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.",
                            style: const TeXViewStyle.fromCSS(
                              'font-size: 14px; font-weight: normal; color: black; font-family:Poppins;line-height:1.2',
                            )),
                      ),
                      /*Text(
                          // "${controller.tncData.value.result!.termsAndCondition}",
                          "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.",
                          style: TextStyle(fontFamily: "Poppins",fontSize: 14.sp,color: Colors.black),),*/
                    ),
                  ),
                ),
              ),
            ),
            Row(
              children: [
                // await SharedPreferencesUtils.init();
                SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN) !=
                        null
                    ? Container()
                    : Expanded(
                        child: GestureDetector(
                          onTap: () => Navigator.pop(context), //Get.back(),
                          child: Container(
                            height: 40.h,
                            margin: EdgeInsets.only(
                                left: 10.w,
                                right: 5.w,
                                top: 10.h,
                                bottom: 10.h),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12.sp),
                                border: Border.all(
                                    color: AppColors.DEEP_BLUE_COLOR)),
                            child: Center(
                                child: Text(
                              "Decline",
                              style:
                                  TextStyle(color: AppColors.DEEP_BLUE_COLOR),
                            )),
                          ),
                        ),
                      ),
                Expanded(
                  child: GestureDetector(
                    onTap: () {
                      if (SharedPreferencesUtils.getString(
                              AppConstants.ACCESS_TOKEN) !=
                          null) {
                        (Get.isRegistered<SignUpController>()
                            ? Get.find<SignUpController>().acceptTnC()
                            : Get.put(SignUpController()).acceptTnC());
                        ;
                      } else {
                        Get.isRegistered<SignUpController>()
                            ? Get.find<SignUpController>().isSelectTnC.value =
                                true
                            : Get.put(SignUpController()).isSelectTnC.value =
                                true;
                      }
                      //Get.back();
                      Navigator.pop(context);
                    },
                    child: Container(
                      margin: EdgeInsets.only(
                          right: 10.w, left: 5.w, top: 10.h, bottom: 10.h),
                      height: 40.h,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12.sp),
                          color: AppColors.DEEP_BLUE_COLOR),
                      child: Center(
                        child: Text(
                          "Accept",
                          style: TextStyle(color: AppColors.TITLE_TEXT_WHITE),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
