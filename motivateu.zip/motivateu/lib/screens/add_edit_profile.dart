import 'package:flutter/material.dart';

import '../widgets/add_profile_widget.dart';

class AddProfile extends StatelessWidget {
  const AddProfile({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          body: Container(
            height: double.maxFinite,
            decoration: BoxDecoration(
              // color: Colors.red,
                image: DecorationImage(
                    image: AssetImage("assets/icons/login_bg.jpg"),
                    fit: BoxFit.cover
                )
            ),
            child: AddProfileWidget()
          ),
        ));
  }
}
