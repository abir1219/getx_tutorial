import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';
import '../res/routes/app_routes.dart';
import '../widgets/chat_history_list_widget.dart';
import '../widgets/q_connect_header_top.dart';

class ChatHistory extends StatelessWidget {
  const ChatHistory({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: WillPopScope(
          onWillPop: () async {
            // Get.offNamed(AppRoutes.dashboard,arguments: [3]);
            Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'3'});
            return true;
          },
          child: Scaffold(
              body: Container(
      height: double.maxFinite,
      width: double.maxFinite,
      decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/icons/login_bg.jpg"),
                fit: BoxFit.cover)),
      child: NotificationListener<OverscrollIndicatorNotification>(
          onNotification: (OverscrollIndicatorNotification notification) {
            notification.disallowIndicator();
            return true;
          } ,
          child: ListView(
            shrinkWrap: true,
            children: [
              QConnectHeaderTop(),
              Container(
                width: double.maxFinite,
                // padding: EdgeInsets.only(top: 35.h),
                padding: EdgeInsets.only(top: 35.h,left: 15.w,right: 15.w),
                color: Colors.white,
                height: 678.h,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text("Chats", style: TextStyle(
                            fontSize: 20.sp,
                            color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR.withOpacity(0.75),
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Poppins')),
                    Container(
                      height: 65.h,
                      margin: EdgeInsets.only(top: 15.h),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8.w),
                          color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR
                      ),
                      child:  Center(child: Container(
                        height: 45,
                        margin: EdgeInsets.symmetric(horizontal: 15.w),
                        padding: EdgeInsets.only(left: 10.w),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30.w)
                        ),
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: "Search here...",
                            suffixIcon: Icon(Icons.search,color: Color(0xFFB8C2C6),),
                            hintStyle: TextStyle(
                                color: AppColors.FIELD_HINT_COLOR,
                                fontFamily: 'Poppins',
                                fontSize: 14.sp),
                            border: InputBorder.none,
                            focusColor: Colors.transparent,
                            focusedBorder: InputBorder.none,
                            enabledBorder: InputBorder.none,
                          ),
                        ),
                      )),
                    ),
                    ChatHistoryListWidget()
                  ],
                ),
              )
            ],
          ),
      ),
    )),
        ));
  }
}
