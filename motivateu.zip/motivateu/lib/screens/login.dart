import 'dart:io';

import 'package:flutter/material.dart';

import '../widgets/login_form_widgets.dart';

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {

    // Get.find<LoginController>();

    return SafeArea(
        child: WillPopScope(
          onWillPop: () async{
            exit(0);
          },
          child: Scaffold(
            // resizeToAvoidBottomInset: false,
      body: Container(
          height: double.maxFinite,
          decoration: BoxDecoration(
            // color: Colors.red,
              image: DecorationImage(
                  image: AssetImage("assets/icons/login_bg.jpg"),
                  fit: BoxFit.cover
              )
          ),
          child: Center(child: LoginFormWidgets()),
      ),
    ),
        ));
  }
}
