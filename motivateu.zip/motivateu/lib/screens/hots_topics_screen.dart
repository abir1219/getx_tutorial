import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../controllers/reels_controller.dart';
import '../res/app_colors.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';
import '../widgets/topic_lists_widget.dart';

class HotsTopicsScreen extends StatefulWidget {
  const HotsTopicsScreen({super.key});

  @override
  State<HotsTopicsScreen> createState() => _HotsTopicsScreenState();
}

class _HotsTopicsScreenState extends State<HotsTopicsScreen> {


  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: AppColors.BOTTOM_SHEET_BACKGROUND,
          title: Text('Higher Order Thinking Skills (HOTS)',style: TextStyle(fontSize: 16.sp,),),
          centerTitle: true,
        ),
        body: Container(
          color: AppColors.TITLE_TEXT_WHITE,
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.only(top:12.h),
          child: NotificationListener<OverscrollIndicatorNotification>(
            onNotification: (OverscrollIndicatorNotification notification) {
              notification.disallowIndicator();
              return true;
            },
            child: TopicListsWidget(subjectId: Get.arguments[0],))
        ),
      ),
    );
  }
}
