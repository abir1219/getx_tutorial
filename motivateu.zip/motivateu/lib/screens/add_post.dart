import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:MotivateU/widgets/qconnect_reusable_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import '../controllers/post_to_controller.dart';
import '../widgets/q_connect_header_top.dart';

class AddPost extends StatefulWidget {
  const AddPost({super.key});

  @override
  State<AddPost> createState() => _AddPostState();
}

class _AddPostState extends State<AddPost> {


  @override
  Widget build(BuildContext context) {
    // Get.isRegistered<PostToController>()?debugPrint("Get.isRegistered<PostToController>()=>${Get.find<PostToController>().myGroupList.length > 0 ||
    //     Get.find<PostToController>().myConnectionList.length > 0}"):null;

    debugPrint("LENGTH---->><<<??${Get.isRegistered<PostToController>()?Get.find<PostToController>().myConnectionNameList.length:Get.put(PostToController()).myConnectionNameList.length}");

    if(!Get.isRegistered<PostToController>()){
      Get.put(PostToController());
    }

    return SafeArea(
        child: WillPopScope(
      onWillPop: () async {
        // Get.offNamed(AppRoutes.dashboard, arguments: [3]);
        Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'3'});
        return true;
      },
      child: Scaffold(
          body: Container(
        height: double.maxFinite,
        width: double.maxFinite,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/icons/login_bg.jpg"),
                fit: BoxFit.cover)),
        child: Column(
          children: [
            QConnectHeaderTop(),
            Expanded(
              child: Container(
                padding: EdgeInsets.only(top: 15.h, left: 4.w, right: 8.w),
                margin: EdgeInsets.only(
                    left: 12.w, right: 12.w, top: 12.h, bottom: 20.h),
                //height: 600.h,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.white, //Color(0xFFF0F0F0)
                    border: Border.all(color: Color(0xFFF0F0F0))),
                child: Column(
                  // mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(bottom: 10.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Container(
                                child: reusableTitleText('Create post')),
                          ),
                          GestureDetector(
                            onTap: () {
                              if(Get.find<PostToController>().postController.value.text.isNotEmpty){
                                Get.find<PostToController>().myGroupNameList.length == 0 &&
                                    Get.find<PostToController>().myConnectionNameList.length == 0?
                                Get.toNamed(AppRoutes.postTo)
                                    : Get.find<PostToController>().addPost("","post");
                              }else{
                                Utils.showToastMessage("Write something to post");
                              }
                            },
                            child: Container(
                              height: 40.h,
                              width: 130.w,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR),
                              child: Center(
                                child: Text(
                                  "POST",
                                  style: TextStyle(
                                      fontSize: 14.sp,
                                      color: AppColors.TITLE_TEXT_WHITE,
                                      fontFamily: 'Alata'),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Get.isRegistered<PostToController>()
                        ? Get.find<PostToController>().myGroupNameList.length > 0 ||
                                Get.find<PostToController>()
                                        .myConnectionNameList
                                        .length >
                                    0
                            ? GestureDetector(
                      onTap: () => Get.toNamed(AppRoutes.postTo),
                              child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                    color: Colors.transparent,
                                    margin: EdgeInsets.only(bottom: 20.h,top: 10.h),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(bottom: 20.h),
                                          child: Divider(color: Colors.grey,height: 0.5,),
                                        ),
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            /*Text(
                                              "Post with - ",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14.sp,
                                                  fontFamily: 'Alata',
                                                  color: Colors.black),
                                            ),*/
                                            Column(
                                              crossAxisAlignment:CrossAxisAlignment.start,
                                              mainAxisAlignment:MainAxisAlignment.center,
                                              children: [
                                                Get.find<PostToController>().myGroupNameList.length >0
                                                    ? Container(
                                                        child: Row(
                                                        children: [
                                                          Get.find<PostToController>().myGroupNameList.length > 2
                                                              ? Text(
                                                                  "${Get.find<PostToController>().myGroupNameList[0]},${Get.find<PostToController>().myGroupNameList[1]} and others...",
                                                                  style: TextStyle(
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                      fontSize: 14.sp,
                                                                      fontFamily:
                                                                          'Alata',
                                                                      color: Colors
                                                                          .black),
                                                                )
                                                          :Get.find<PostToController>().myGroupNameList.length == 2
                                                              ? Text(
                                                            "${Get.find<PostToController>().myGroupNameList[0]} and ${Get.find<PostToController>().myGroupNameList[1]}",
                                                            style: TextStyle(fontWeight:FontWeight.normal,
                                                                fontSize: 14.sp,
                                                                fontFamily:'Alata',
                                                                color: Colors.black),)
                                                              : Get.find<PostToController>().myGroupNameList.length == 1
                                                                  ? Text(
                                                                      "${Get.find<PostToController>().myGroupNameList[0]}",
                                                            style: TextStyle(fontWeight:FontWeight.normal,
                                                            fontSize: 14.sp,
                                                            fontFamily:'Alata',
                                                            color: Colors.black),)
                                                                  : Container(),
                                                        ],
                                                      ))
                                                    : Container(),
                                                Get.find<PostToController>().myConnectionNameList.length >0
                                                    ? Container(
                                                  margin: EdgeInsets.only(top: 5.h),
                                                        child: Get.find<PostToController>().myConnectionNameList.length >2
                                                            ? Text(
                                                                "${Get.find<PostToController>().myConnectionNameList[0]},${Get.find<PostToController>().myConnectionNameList[1]} and others...",
                                                                style: TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .normal,
                                                                    fontSize: 14.sp,
                                                                    fontFamily:
                                                                        'Alata',
                                                                    color:
                                                                        Colors.black),
                                                              )
                                                            : Get.find<PostToController>()
                                                                        .myConnectionNameList
                                                                        .length == 2
                                                                ? Text(
                                                                    "${Get.find<PostToController>().myConnectionNameList[0]} and ${Get.find<PostToController>().myConnectionNameList[1]}",style: TextStyle(
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                            fontSize: 14.sp,
                                                            fontFamily:
                                                            'Alata',
                                                            color: Colors
                                                                .black),)

                                                            : Get.find<PostToController>()
                                                            .myConnectionNameList
                                                            .length == 1
                                                            ? Text(
                                                          "${Get.find<PostToController>().myConnectionNameList[0]}",style: TextStyle(
                                                            fontWeight:
                                                            FontWeight
                                                                .normal,
                                                            fontSize: 14.sp,
                                                            fontFamily:
                                                            'Alata',
                                                            color: Colors
                                                                .black),)
                                                            : Container())
                                                    : Container(),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                            )
                            : Container()
                        : Container(),
                    Container(
                      margin: EdgeInsets.only(bottom: 6.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          buildTagButton(context, 'Groups & Connections', () {
                            Get.toNamed(AppRoutes.postTo, arguments: ["all"]);
                          }),
                          buildTagButton(context, 'Connections', () {
                            Get.toNamed(AppRoutes.postTo,
                                arguments: ["connection"]);
                          }),
                          buildTagButton(context, 'Groups', () {
                            Get.toNamed(AppRoutes.postTo, arguments: ["group"]);
                          }),
                        ],
                      ),
                    ),
                    Expanded(
                      child:
                          NotificationListener<OverscrollIndicatorNotification>(
                        onNotification:
                            (OverscrollIndicatorNotification notification) {
                          notification.disallowIndicator();
                          return true;
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              vertical: 8.h, horizontal: 12.w),
                          margin: EdgeInsets.only(
                              top: 12.h, left: 10.w, right: 10.w, bottom: 12.h),
                          color: Color(0xFFF7F7F7),
                          child: TextField(
                            controller: Get.find<PostToController>().postController.value,
                            enableSuggestions: false,
                            autocorrect: false,
                            // controller: controller.otherSchoolController.value,
                            autofocus: true,
                            keyboardType: TextInputType.text,
                            maxLines: null,
                            style: TextStyle(
                                decoration: TextDecoration.none,
                                color: Colors.black,
                                fontSize: 20.sp,
                                fontFamily: 'Montserrat'),
                            cursorColor: Colors.grey.withOpacity(0.8),
                            decoration: InputDecoration(
                              hintText: "What’s on your mind...",
                              // counterText: "",
                              // errorStyle: TextStyle(
                              //     height: 0,
                              //     color: Colors.transparent),
                              disabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(100),
                                borderSide: BorderSide.none,
                              ),
                              hintStyle: TextStyle(
                                  color: AppColors.FIELD_HINT_COLOR,
                                  fontFamily: 'Alata',
                                  fontSize: 18.sp),
                              border: InputBorder.none,
                              focusColor: Colors.transparent,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            )
          ],
        ),
      )),
    ));
  }

  Widget buildTagButton(
      BuildContext context, String title, void Function() func) {
    return GestureDetector(
      onTap: () => func(),
      child: Container(
        height: 40.h,
        // width: MediaQuery.of(context).size.width * 0.3,
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 6.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(100.sp),
          color: AppColors.ACCOUNT_PAGE_BUTTON_BG_COLOR,
        ),
        child: Center(
          child: Text(title,
              style: TextStyle(
                  color: AppColors.ON_BOARDING_BUTTON_COLOR, fontSize: 12.sp)),
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    debugPrint("<<<<<<<<<<<Close>>>>>>>>>>>>>");
    Get.find<PostToController>().clearData();
  }
}
