import 'package:MotivateU/controllers/reels_controller.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

class NoDataFound extends StatefulWidget {
  final String type;
  final String scenarioId;
  const NoDataFound({super.key, required this.type, required this.scenarioId});

  @override
  State<NoDataFound> createState() => _NoDataFoundState();
}

class _NoDataFoundState extends State<NoDataFound> {
  bool isLoading = false;
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
              child: Lottie.asset('assets/lottie/no_data_found.json')),
          Text("No Records found"),
          CustomButton(buttonName: "REFRESH REEL", callback: () {
            debugPrint("refresh");
            setState(() {
              Get.find<ReelsController>().chapterId.value = "";
              Get.find<ReelsController>().subjectId.value = "";
              Get.find<ReelsController>().topicId.value = "";
              Get.find<ReelsController>().keywordList.value = [];
              isLoading = true;
            });

            Future.delayed(Duration(seconds: 1,),() {
              setState(() {
                isLoading = false;
              });
              Get.find<ReelsController>().getReels(1,widget.scenarioId);
              // Get.toNamed(AppRoutes.dashboard,arguments: [4]);
            });


          },loading: isLoading,)
        ],
      ),
    ));
  }
}
