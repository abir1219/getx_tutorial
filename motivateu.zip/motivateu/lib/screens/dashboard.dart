import 'package:MotivateU/controllers/dashboard_controller.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/widgets/dashboard_widget.dart';
import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';


class Dashboard extends StatefulWidget {
  final String pageIndex;
  final dynamic message;
  const Dashboard({super.key, required this.pageIndex, this.message});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {


  late int pageIndex;
  // int pageIndex = int.parse(widget.pageIndex);


  @override
  void initState() {
    super.initState();
    // debugPrint("DASHBOARD_INIT => ${Get.arguments.length}");
    // var arguments = Get.arguments;
    // if (arguments != null) {
    //   //Get.find<DashboardController>().pageIndex.value = Get.arguments[0];
    //   // Get.find<DashboardController>().changePageIndex(Get.arguments[0]);
    //   pageIndex = Get.arguments[0];
    // }
    //Get.find<DashboardController>().pageIndex.value = pageIndex;
    //pageIndex = int.parse(widget.pageIndex);
    if(Get.parameters != null){
      debugPrint("Get.parameters != null");
      debugPrint("Get.parameters.value = ${Get.parameters['pageIndex']}");
      pageIndex = int.parse(Get.parameters['pageIndex']??'0');
    }else{
      debugPrint("Get.parameters == null");
    }
    /*if(Get.parameters != null){
      pageIndex = int.parse(Get.parameters['pageIndex']!);
    }*/
  }


  @override
  Widget build(BuildContext context) {
    // int pageIndex = int.parse(widget.pageIndex);


    final message = ModalRoute.of(context)!.settings.arguments;
    debugPrint("Message-->$message");
    debugPrint("pageIndexdsfsdf-->$pageIndex");
    if(message != null){
      if (message is List) {
        int messageLength = message.length;
        debugPrint("---message---$message and length: $messageLength");
        debugPrint("---message---${message} and ${message.length}");
        if(messageLength > 1){
          pageIndex = int.parse((message as Map)['pageIndex']);
          //debugPrint("MESSAGE--->${(message as Map)['message'].data}");
        }

      } else {
        debugPrint("Message is not a list.");
      }
    }else{
      debugPrint("PAGE_INDEX=>$pageIndex");
    }

    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.white,
      body: pageIndex != -1 ? buildPage(pageIndex) : Obx(() => buildPage(Get.find<DashboardController>().pageIndex.value,),),
      bottomNavigationBar: StyleProvider(
        style: Style(),
        child: ConvexAppBar(
          initialActiveIndex: pageIndex != -1? pageIndex: Get.find<DashboardController>().pageIndex.value,
          backgroundColor: AppColors.BOTTOM_SHEET_BACKGROUND,
          items: bottomTabs,
          elevation: 0,
          top: -20,
          style: TabStyle.fixedCircle,
          color: Colors.white,
          // showSelectedLabels: false,
          // showUnselectedLabels: false,
          // type: BottomNavigationBarType.fixed,
          onTap: (value) {
            Get.find<DashboardController>().pageIndex.value = value;
            setState(() {
              pageIndex = -1;
              // Get.parameters = {};
            });
          },
        ),
      ),
    ));
  }
}

class Style extends StyleHook {
  @override
  double get activeIconMargin => 10.sp;

  @override
  double get activeIconSize => 40.sp;

  @override
  double? get iconSize => 34.sp;

  @override
  TextStyle textStyle(Color color, String? fontFamily) {
    return TextStyle(fontSize: 20, color: color);
  }
}
