import 'package:MotivateU/controllers/performance_controller.dart';
import 'package:MotivateU/screens/performance_details.dart';
import 'package:MotivateU/screens/terms_condition.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';

import '../res/app_colors.dart';
import '../utils/utils.dart';

class PerformanceInfo extends StatefulWidget {
  const PerformanceInfo({super.key});

  @override
  State<PerformanceInfo> createState() => _PerformanceInfoState();
}

class _PerformanceInfoState extends State<PerformanceInfo> {
  var controller = Get.isRegistered<PerformanceController>()
      ? Get.find<PerformanceController>()
      : Get.put(PerformanceController());

  @override
  void initState() {
    super.initState();
    //ManageTimeTracker.pauseTimer();
    // FirebaseAnalytics.instance.setCurrentScreen(
    //   screenName: 'screen_name',
    //   screenClassOverride: 'screen_class',
    // );
    controller.getDashboardData();
    clearHive();
    controller.checkTnC(() {
      debugPrint("controller.tncData.value.acceptTermsAndCondition==>${controller.tncData.value.acceptTermsAndCondition}");
      controller.tncData.value.acceptTermsAndCondition == false?_openAnimationDialog(context): null;
    },);
  }

  Future<void> clearHive() async {
    var box = await Hive.openBox('motivate_u_mcq');
    box.clear();
  }

  @override
  Widget build(BuildContext context) {
    DateTime? currentBackPressTime;

    /*controller.checkTnC(() {
      debugPrint("controller.tncData.value.acceptTermsAndCondition==>${controller.tncData.value.acceptTermsAndCondition}");
      controller.tncData.value.acceptTermsAndCondition == false?_openAnimationDialog(context): null;
    },);*/

    // final message = ModalRoute.of(context)!.settings.arguments;
    // debugPrint("---message---${message}");



    return SafeArea(
        child: PopScope(
          canPop: false,
            onPopInvoked: (didPop) {
              DateTime now = DateTime.now();
              if (currentBackPressTime == null ||
                  now.difference(currentBackPressTime!) >
                      Duration(seconds: 2)) {
                currentBackPressTime = now;
                Utils.showToastMessage("Press back again to exit");
                //return false;
              }else{
                // currentBackPressTime = null;
                SystemNavigator.pop();
              }
            },
            /*onWillPop: () async {
              DateTime now = DateTime.now();
              if (currentBackPressTime == null ||
                  now.difference(currentBackPressTime!) >
                      Duration(seconds: 2)) {
                currentBackPressTime = now;
                Utils.showToastMessage("Press back again to exit");
                return false;
              }
              SystemNavigator.pop();
              return true;
            },*/
            child: Scaffold(
                appBar: AppBar(
                  elevation: 0,
                  backgroundColor: AppColors.BOTTOM_SHEET_BACKGROUND,
                  title: Text(
                    'Dashboard',
                    style: TextStyle(
                      fontSize: 16.sp,
                    ),
                  ),
                  centerTitle: true,
                ),
                body: Obx(
                  () => controller.isLoading.value
                      ? Container(
                          height: double.maxFinite,
                          width: double.maxFinite,
                          child: Center(
                            child: SizedBox(
                              width: 20.w,
                              height: 20.h,
                              child: CircularProgressIndicator(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        )
                      : Obx(() => controller.dashboardModel.value.result!.length > 0 ?Container(
                            margin: EdgeInsets.symmetric(
                                horizontal: 8.sp, vertical: 10.h),
                            child: GridView.builder(
                              shrinkWrap: true,
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      mainAxisSpacing: 8,
                                      crossAxisSpacing: 8,
                                      childAspectRatio: 1.4),
                              itemBuilder: (context, index) =>
                                  buildSubjectContainer(
                                      subject: controller.dashboardModel.value.result![index].name!,
                                      index: index,
                                      totalQuestion: controller.dashboardModel.value.result![index].total!,
                                      correctedQuestion: controller.dashboardModel.value.result![index].visited!, subjectId: controller.dashboardModel.value.result![index].sId!),
                              itemCount: controller.dashboardModel.value.result!.length,
                            ),
                          )
                                          :Container(child: Center(child: Text("No records found"),),),
                      ),
                ))));
  }

  Widget buildSubjectContainer(
      {required String subject,
      required String subjectId,
      required int index,
      required var totalQuestion,
      required var correctedQuestion}) {
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => PerformanceDetails(subjectName: subject, subjectId: subjectId),)),
      child: Container(
        margin: EdgeInsets.all(4.sp),
        padding: EdgeInsets.symmetric(horizontal: 10.sp),
        decoration: BoxDecoration(
            color: Colors.white, //color,
            border: Border(
                top: BorderSide(color: AppColors.SLIDER_DOTTED_COLOR, width: 4.sp)),
            boxShadow: [
              BoxShadow(
                  spreadRadius: 1.sp,
                  color: Colors.grey,
                  blurRadius: 2,
                  offset: Offset(.5.sp, .5.sp),
                  blurStyle: BlurStyle.outer)
            ]
            // borderRadius: BorderRadius.circular(12.0),
            ),
        child: Row(
          // mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        child: Text(
                          "$subject",
                          style: TextStyle(
                              fontSize: 12.sp,
                              fontFamily: 'Poppins',
                              color: AppColors.OTP_PIN_VIEW_COLOR),
                        ),
                      ),
                      Container(
                        child: Text(
                          "View/Total Qst.",
                          style: TextStyle(
                              fontSize: 10.sp,
                              fontFamily: 'Poppins',
                              color: AppColors.OTP_PIN_VIEW_COLOR),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    child: Text(
                      "$correctedQuestion/$totalQuestion",
                      style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Poppins',
                          color: AppColors.BOTTOM_NAVIGATION_BAR_COLOR),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 60.h,
              width: 60.w,
              child: SvgPicture.asset(
                "assets/icons/chart_sm.svg",
              ),
            )
          ],
        ),
      ),
    );
  }

  void _openAnimationDialog(BuildContext context) {
    showGeneralDialog(context: context,
      barrierDismissible: false,
      barrierLabel: '',
      // transitionDuration: Duration(microseconds: 900),
      pageBuilder: (context, animation1, animation2 ) {
        return Container();
      },
      transitionBuilder: (context, animation1, animation2, child) {
        return ScaleTransition(scale: Tween<double>(begin: 0.5,end: 1.0).animate(animation1),
          child: FadeTransition(
            opacity: Tween<double>(begin: 0.5,end: 1.0).animate(animation1),
            child: Dialog(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16.0),
                ),
                // title: Text("Terms & Conditions"),
                child: TermsCondition()
            ),
          ),);
      },
    );
  }
}
