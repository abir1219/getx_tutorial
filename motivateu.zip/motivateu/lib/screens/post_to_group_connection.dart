import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../controllers/post_to_controller.dart';
import '../res/app_colors.dart';

class PostToGroupConnection extends StatefulWidget {
  const PostToGroupConnection({super.key});

  @override
  State<PostToGroupConnection> createState() => _PostToGroupConnectionState();
}

class _PostToGroupConnectionState extends State<PostToGroupConnection> {
  // List<String> groupList=['Group 1','Group 2','Group 3','Group 4'];
  // List<String> connectionList=['Connection 1','Connection 2','Connection 3','Connection 4','Connection 5','Connection 6','Connection 7'];

  var controller = Get.find<PostToController>();
  var type = "";
  int pageNo = 1;

  ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    controller.connectionList!.clear();
    // controller.myConnectionSelection.clear();
    if (Get.arguments != null) {
      Get.arguments[0] != "all" && Get.arguments[0] != "reels" ? type = "/" + Get.arguments[0] : "";
    }
    controller.getConnectionMyList(pageNo, type);
    _scrollController.addListener(_scrollListener);

  }

  // @override
  // void didChangeDependencies() {
  //   super.didChangeDependencies();
  //   _scrollController.addListener(_scrollListener);
  // }

  @override
  void dispose() {
    _scrollController.dispose();
    /*controller.connectionList!.clear();
    controller.myConnectionSelection.clear();*/
    super.dispose();
  }

  void _scrollListener() {
    // Utils.showToastMessage("hii");
    if (_scrollController.offset >=
        _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {

      // SchedulerBinding.instance.addPostFrameCallback((_) {
      Future.microtask(() {
        if (controller.myListModel.value.pagination!.totalRecord !=
            controller.connectionList!.length) {
          debugPrint("_scrollController.position====>${_scrollController.position}");
          setState(() {
            pageNo++;
          });
          controller.getMoreConnectionMyList(pageNo, type);
        }
      });
      // Reach the end of the list, load more data
      /*if (controller.myListModel.value.pagination!.totalRecord != controller.connectionList!.length) {
        debugPrint("_scrollController.position====>${_scrollController.position}");
        setState(() {
          pageNo++;
        });
        controller.getMoreConnectionMyList(pageNo, type);
        //_loadMoreData();
      }*/
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: WillPopScope(
      onWillPop: () async {
        controller.connectionList!.clear();
        Get.back();
        controller.searchTextController.value.text = "";
        return true;
      },
      child: Scaffold(
        body: RefreshIndicator(
          color: Colors.black,
          onRefresh: () async{
            setState(() {
              pageNo = 1;
            });
            controller.getConnectionMyList(pageNo, type);
          },
          child: Container(
            width: double.maxFinite,
            // padding: EdgeInsets.only(top: 35.h),
            padding: EdgeInsets.only(top: 35.h, left: 15.w, right: 15.w),
            decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("assets/icons/login_bg.jpg"),
                  fit: BoxFit.cover),
              color: Colors.white,
            ),
            // height: 678.h,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Post to",
                        style: TextStyle(
                            fontSize: 20.sp,
                            color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR
                                .withOpacity(0.75),
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Poppins')),
                    Obx(() => Get.find<PostToController>().myGroupNameList.length > 0 || Get.find<PostToController>().myConnectionNameList.length > 0?
                    GestureDetector(
                      onTap: () {
                        if(Get.arguments!=null && Get.arguments[0] == "reels"){
                          Get.find<PostToController>().addPost(Get.arguments[1],"reel");
                          //Get.offNamed(AppRoutes.dashboard,arguments: [0]);
                        }else{
                          Get.offNamed(AppRoutes.AddPost);
                          controller.searchTextController.value.text = "";
                        }
                      },
                      child: Container(
                          height: 40.h,
                          width: 40.w,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: AppColors.ON_BOARDING_BUTTON_COLOR),
                          child: Center(
                            child: Icon(
                              Icons.arrow_forward,
                              color: Colors.white,
                            ),
                          ),
                        ),
                    ): Container()
                    /*Container(
                      height: 40.h,
                      width: 40.w,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(100),
                          color: AppColors.BACK_ARROW_COLOR),
                      child: Center(
                        child: Icon(
                          Icons.arrow_forward,
                          color: Colors.white,
                        ),
                      ),
                    ),*/
                    )
                  ],
                ),
                Container(
                  height: 65.h,
                  margin: EdgeInsets.only(top: 18.h),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8.w),
                      color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR),
                  child: Center(
                      child: Container(
                    height: 45,
                    margin: EdgeInsets.symmetric(horizontal: 15.w),
                    padding: EdgeInsets.only(left: 10.w),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(30.w)),
                    child: TextField(
                      controller: controller.searchTextController.value,
                      decoration: InputDecoration(
                        hintText: "Search group or connection...",
                        suffixIcon: Icon(
                          Icons.search,
                          color: Color(0xFFB8C2C6),
                        ),
                        hintStyle: TextStyle(
                            color: AppColors.FIELD_HINT_COLOR,
                            fontFamily: 'Poppins',
                            fontSize: 14.sp),
                        border: InputBorder.none,
                        focusColor: Colors.transparent,
                        focusedBorder: InputBorder.none,
                        enabledBorder: InputBorder.none,
                      ),
                      onChanged: (value) => controller.getConnectionMyList(pageNo, type),
                    ),
                  )),
                ),
                // PostToWidget()
                Obx(() => controller.isLoading.value?
                    Container(
                      child: Center(
                        child: SizedBox(
                          height: 24.h,
                          width: 24.w,
                          child: CircularProgressIndicator(color: Colors.black,),
                        ),
                      ),
                    )
                    :Expanded(
                    child: Scrollbar(
                      child: NotificationListener<OverscrollIndicatorNotification>(
                        onNotification:
                            (OverscrollIndicatorNotification notification) {
                          notification.disallowIndicator();
                          return true;
                        },
                        child: ListView(
                          shrinkWrap: true,
                          controller: _scrollController,
                          children: [
                            Obx(() => controller.groupList.length > 0
                                ?Container(
                                  margin: EdgeInsets.only(top: 10.h, bottom: 15.h),
                                  padding: EdgeInsets.all(6.sp),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                      color: Colors.white,
                                      border: Border.all(color: Color(0xFFF7F7F7))),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                          margin: EdgeInsets.only(
                                              top: 10.h, bottom: 15.h),
                                          child: Text(
                                            "Group",
                                            style: TextStyle(
                                                fontFamily: 'Alata',
                                                color: Colors.black,
                                                fontSize: 18.sp,
                                                fontWeight: FontWeight.bold),
                                          )),
                                      ListView.builder(
                                        shrinkWrap: true,
                                        physics: NeverScrollableScrollPhysics(),
                                        itemBuilder: (context, index) {
                                          debugPrint("INDEX_____${controller.groupList.length}");
                                          debugPrint("INDEX_____${controller.myGroupSelection[index]}");
                                          return Obx(() => reusableGroupConnection(
                                                '${controller.groupList[0]![index].name}',
                                                index.toString(),
                                                controller.myGroupSelection[index],
                                                    () {
                                                  controller.toggleSelectedGroupList(index);
                                                  controller
                                                      .toggleGroupSelectionStatus(index);
                                                }),
                                          );
                                        },
                                        itemCount: controller.groupList.length,
                                      ),
                                    ],
                                  )):Container(),
                            ),
                            Obx(() => controller.connectionList!.length > 0
                                ? Container(
                              margin: EdgeInsets.only(top: 10.h, bottom: 15.h),
                              padding: EdgeInsets.all(6.sp),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                  color: Colors.white,
                                  border: Border.all(color: Color(0xFFF7F7F7))),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                      margin:
                                          EdgeInsets.only(top: 10.h, bottom: 15.h),
                                      child: Text(
                                        "Connections:",
                                        style: TextStyle(
                                            fontFamily: 'Alata',
                                            color: Colors.black,
                                            fontSize: 18.sp,
                                            fontWeight: FontWeight.bold),
                                      )),
                                  ListView.builder(
                                    shrinkWrap: true,
                                    // controller: _scrollController,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemBuilder: (context, index) {
                                      debugPrint("controller.connectionList.length==>${controller.connectionList!.length}");
                                      return Obx(
                                              () {
                                            /* if (index < controller.connectionList.length) {
                                                return reusableGroupConnection(
                                                    '${controller
                                                        .connectionList[0]![index]
                                                        .name}',
                                                    index.toString(),
                                                    controller
                                                        .myConnectionSelection[index],
                                                        () {
                                                      controller
                                                          .toggleSelectedConnectionList(
                                                          index);
                                                      controller
                                                          .toggleConnectionSelectionStatus(
                                                          index);
                                                    });
                                              }else{
                                                return Padding(
                                                  padding: const EdgeInsets.all(8.0),
                                                  child: Center(
                                                    child: SizedBox(
                                                      height: 24.h,
                                                      width: 24.w,
                                                      child: CircularProgressIndicator(color: Colors.black,),
                                                    ),
                                                  ),
                                                );
                                              }*/
                                            return reusableGroupConnection(
                                                '${controller
                                                    .connectionList![index]
                                                    .name}',
                                                index.toString(),
                                                //false,
                                                controller.myConnectionSelection[index],
                                                    () {
                                                  controller
                                                      .toggleSelectedConnectionList(
                                                      index);
                                                  controller
                                                      .toggleConnectionSelectionStatus(
                                                      index);
                                                });
                                          }
                                      );
                                    },
                                    itemCount: controller.connectionList!.length,
                                  ),
                                  controller.isMoreLoading.value?
                                  Container(
                                    width: double.maxFinite,
                                    color: Colors.white,
                                    margin: EdgeInsets.symmetric(vertical: 10.h),
                                    child: Center(
                                      child: SizedBox(
                                        height: 24.h,
                                        width: 24.w,
                                        child: CircularProgressIndicator(color: Colors.black,),
                                      ),
                                    ),
                                  ):Container()
                                ],
                              ),
                            ):Container())
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ));
  }

  Widget reusableGroupConnection(String name, String position, bool isSelected,
      void Function() func) {
    return GestureDetector(
      onTap: () => func(),
      child: Container(
        width: double.maxFinite,
        color: Colors.transparent,
        margin: EdgeInsets.symmetric(
          vertical: 18.h,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // alignment:Alignment.centerLeft,
              //color: Colors.red,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    height: 20.h,
                    width: 20.w,
                    margin: EdgeInsets.only(
                      right: 12.w,
                    ),
                    child: Center(
                      child: Icon(Icons.group_outlined),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 4.h),
                    //alignment:Alignment.centerLeft,
                    // color: Colors.amber,
                    child: Text(
                      "$name",
                      style: TextStyle(
                          color: AppColors.TITLE_TEXT_BLACK,
                          fontSize: 14.sp,
                          fontWeight: FontWeight.normal,
                          fontFamily: "Alata"),
                    ),
                  ),
                ],
              ),
            ),
            Container(
                margin: EdgeInsets.only(
                  right: 12.w,
                ),
                height: 22.h,
                width: 22.w,
                child: isSelected
                    ? SvgPicture.asset("assets/icons/seleted_grp.svg")
                    : Icon(
                        Icons.circle_outlined,
                        color: Colors.grey,
                      )),
          ],
        ),
      ),
    );
  }
}
