import 'package:MotivateU/controllers/on_boarding_controller.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';
import '../widgets/on_boarding_slider_widget.dart';

class OnBoardingScreen extends StatefulWidget {
  const OnBoardingScreen({super.key});

  @override
  State<OnBoardingScreen> createState() => _OnBoardingScreenState();
}

class _OnBoardingScreenState extends State<OnBoardingScreen> {
  final controller  = Get.find<OnBoardingController>();
  // final controller = Get.put(OnBoardingController());

  @override
  void dispose() {
    super.dispose();
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    final _pageContoller = PageController(initialPage: 0);

    return SafeArea(
        child: Scaffold(
            body: Obx(() => GestureDetector(
              child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("assets/icons/onboarding_bg.jpg",),fit: BoxFit.cover,
                    )
                ),
                child: Stack(
                  alignment: Alignment.topCenter,
      children: [
        // SvgPicture.asset(
        //   "assets/icons/on_boarding_bg.svg",
        //   fit: BoxFit.fill,
        // ),
        //Image.asset("assets/icons/onboarding_bg.png",fit: BoxFit.cover,),
        Positioned(
                top: 30.w,
                right: 20.w,
                child: GestureDetector(
                  // behavior: HitTestBehavior.translucent,
                  onTap: () {
                    try {
                      // Get.offNamed(AppRoutes.login);
                      // Get.offNamed(AppRoutes.login);
                      Get.offAllNamed(AppRoutes.login);
                    } catch (e) {
                      print('Error navigating to route: $e');
                    }
                    debugPrint("<<---SKIPPED--->>");
                  },
                  child: Row(
                    children: [
                      Text("Skip",style: TextStyle(fontSize: 16.sp,color: AppColors.FIELD_HINT_COLOR,fontFamily: 'Poppins')),
                      Icon(Icons.skip_next,color: AppColors.FIELD_HINT_COLOR,size: 24.w,)
                    ],
                  ),
                )),
        Positioned(
          top: 55.w,
          bottom: 35.w,
          left: 0,
          right: 0,
          child: Container(
            // color: Colors/.red,
            child: PageView(
                  onPageChanged: (value) {
                    //controller.index.value = value;
                    controller.changeIndex(value);
                  },
                  controller: _pageContoller,
                  children: [
                    PageViewSlider(
                      index: 1,
                      pageController: _pageContoller,
                      title: 'Best Study Materials',
                      subtitle:
                          'Teacher will submit questions dolor sit amet consecrate. Cras in mi viverra sagittis egestas volutpat. ',
                      imgUrl: 'slider_one.svg',
                      buttonName: 'NEXT',
                    ),
                    PageViewSlider(
                      index: 2,
                      pageController: _pageContoller,
                      title: 'Quality Education',
                      subtitle:
                          'Teacher will submit questions dolor sit amet consecrate. Cras in mi viverra sagittis egestas volutpat. ',
                      imgUrl: 'slider_two.svg',
                      buttonName: 'NEXT',
                    ),
                    PageViewSlider(
                      index: 3,
                      pageController: _pageContoller,
                      title: 'Group Sharing',
                      subtitle:
                          'Teacher will submit questions dolor sit amet consecrate. Cras in mi viverra sagittis egestas volutpat. ',
                      imgUrl: 'slider_three.svg',
                      buttonName: 'GET STARTED',
                    )
                  ],
            ),
          ),
        ),
        Positioned(
          bottom: 35.w,
          child: DotsIndicator(
                dotsCount: 3,
                position: controller.index.value,
                decorator: DotsDecorator(
                    color: Colors.grey,
                    activeColor: AppColors.SLIDER_DOTTED_COLOR,
                    activeSize: const Size(18.0, 8.0),
                    size: const Size(8.0, 8.0),
                    activeShape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(5.0))),
          ),
        )
      ],

                ),
              ),
            ))));
  }
}
