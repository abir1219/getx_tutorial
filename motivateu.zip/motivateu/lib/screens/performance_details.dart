import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../controllers/performance_controller.dart';
import '../res/app_colors.dart';

class PerformanceDetails extends StatefulWidget {
  final String subjectName;
  final String subjectId;

  const PerformanceDetails(
      {super.key, required this.subjectName, required this.subjectId});

  @override
  State<PerformanceDetails> createState() => _PerformanceDetailsState();
}

class _PerformanceDetailsState extends State<PerformanceDetails> {
  var controller = Get.isRegistered<PerformanceController>()
      ? Get.find<PerformanceController>()
      : Get.put(PerformanceController());


  List<bool> isOpen = [true,false];
  // List<bool> isVisible = [true,false];
  int selectedIndex = 1;


  @override
  void initState() {
    super.initState();
    controller.getDashboardDetailsData(widget.subjectId);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: AppColors.BOTTOM_SHEET_BACKGROUND,
        title: Text(
          '${widget.subjectName}',
          style: TextStyle(
            fontSize: 16.sp,
          ),
        ),
        centerTitle: true,
      ),
      body: Container(
        padding: EdgeInsets.only(bottom: 15.sp),
        child: Obx(() {
          return controller.isAnotherLoading.value
              ? Container(
                  child: Center(
                    child: SizedBox(
                      height: 20.h,
                      width: 20.w,
                      child: CircularProgressIndicator(
                        color: Colors.black,
                      ),
                    ),
                  ),
                )
              : NotificationListener<OverscrollIndicatorNotification>(
            onNotification: (OverscrollIndicatorNotification notification) {
              notification.disallowIndicator();
              return true;
            },
                child: SingleChildScrollView(
                  child: Column(
                    // shrinkWrap: true,
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            if(isOpen[0]){
                              isOpen[0] = false;
                              //isOpen[1] = true;
                            }else{
                              isOpen[0] = true;
                              //isOpen[1] = false;
                            }
                          });
                        },
                        child: Container(
                          color: Colors.transparent,
                          margin: EdgeInsets.symmetric(horizontal: 10.sp),
                          child: Column(
                            children: [
                              Container(
                                height: 40.h,
                                margin: EdgeInsets.only(top: 10.sp),
                                decoration: BoxDecoration(
                                  border: Border(
                                    left: BorderSide(
                                      color: AppColors.TITLE_TEXT_GREEN,
                                      width: 4.w
                                    )
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.3),
                                      spreadRadius: 1,
                                      blurRadius: 1.2,
                                      offset: Offset(1.5,1)
                                    )
                                  ],
                                  color: Colors.white
                                ),
                                padding: EdgeInsets.symmetric(horizontal: 10.sp),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Interactive Questions",style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,)),
                                    Container(
                                        height: 26.h,
                                        width: 26.w,
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(100.sp),
                                            color: AppColors.RED_BAR_COLOR
                                        ),
                                        child: Center(child: Icon(isOpen[0]?Icons.arrow_drop_up_sharp:Icons.arrow_drop_down_sharp,color: Colors.white,size: 26.sp,)))
                                    // Icon(isOpen[0]?Icons.arrow_drop_up_sharp:Icons.arrow_drop_down_sharp,color: Colors.black,size: 28.sp,)
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      isOpen[0]?Obx(() =>  Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.1),
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(8),
                              bottomRight: Radius.circular(8),
                            )
                        ),
                       // color: Colors.transparent,
                        margin: EdgeInsets.symmetric(horizontal: 10.w),
                        padding: EdgeInsets.symmetric(vertical: 10.h),
                        child: ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index){
                              // if(controller.dashboardDetailsModel.value.result![index].sId!.contains("MCQ")){
                              // debugPrint("type----->${controller.dashboardDetailsModel.value.result![index].sId!.contains("MCQ")}");
                              // return buildContainerForInteractive(index);
                              debugPrint("type $index--${controller.MCQList!.length}--->${controller.dashboardDetailsModel.value.result![index].sId!.contains("MCQ")}");
                              return controller.MCQList![index].sId!.contains("MCQ")?_buildChartContainer(controller.MCQList![index].total,
                                  controller.MCQList![index].visited,
                                  controller.MCQList![index].correct??0,controller.MCQList![index].sId):Container();
                              // }else
                              //   return _buildChartContainer(controller.dashboardDetailsModel.value.result![index].total,
                              //       controller.dashboardDetailsModel.value.result![index].visited,
                              //       controller.dashboardDetailsModel.value.result![index].correct,controller.dashboardDetailsModel.value.result![index].sId);
                            }
                            ,itemCount: controller.MCQList!.length),
                      ),
                      ):Container(),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            if(isOpen[1]){
                              isOpen[1] = false;
                              //isOpen[0] = true;
                            }else{
                              isOpen[1] = true;
                              //isOpen[0] = false;
                            }
                          });
                        },
                        child: Container(
                          color: Colors.transparent,
                          child: Column(
                            children: [
                              Container(
                                height: 40.h,
                                decoration: BoxDecoration(
                                    border: Border(
                                        left: BorderSide(
                                            color: AppColors.TITLE_TEXT_GREEN,
                                            width: 4.w
                                        )
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                          color: Colors.grey.withOpacity(0.3),
                                          spreadRadius: 1,
                                          blurRadius: 1.2,
                                          offset: Offset(1.5,1)
                                      )
                                    ],
                                    color: Colors.white
                                ),
                                padding: EdgeInsets.symmetric(horizontal: 10.h),
                                margin: EdgeInsets.only(top: 16.h,left: 12.w,right: 12.w),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text("Questions",style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,),),
                                    Container(
                                        height: 26.h,
                                        width: 26.w,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(100.sp),
                                          color: AppColors.RED_BAR_COLOR
                                        ),
                                        child: Center(child: Icon(isOpen[1]?Icons.arrow_drop_up_sharp:Icons.arrow_drop_down_sharp,color: Colors.white,size: 26.sp,)))
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      isOpen[1]?Obx(() =>  Container(
                        decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.1),
                            borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(8),
                              bottomRight: Radius.circular(8),
                            )
                        ),
                        padding: EdgeInsets.symmetric(vertical: 10.h),
                        margin: EdgeInsets.symmetric(horizontal: 10.w),
                        child: ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index){
                              // if(controller.dashboardDetailsModel.value.result![index].sId!.contains("MCQ")){
                              debugPrint("type ${controller.OthersList!.length}----->${controller.OthersList![index].sId!.contains("MCQ")}");
                              // return buildContainerForInteractive(index);

                              return !controller.OthersList![index].sId!.contains("MCQ")?_buildChartContainer(controller.OthersList![index].total,
                                  controller.OthersList![index].visited,
                                  controller.OthersList![index].correct??0,controller.OthersList![index].sId):Container();
                              // }else
                              //   return _buildChartContainer(controller.dashboardDetailsModel.value.result![index].total,
                              //       controller.dashboardDetailsModel.value.result![index].visited,
                              //       controller.dashboardDetailsModel.value.result![index].correct,controller.dashboardDetailsModel.value.result![index].sId);
                            }
                            ,itemCount: controller.OthersList!.length),
                      ),
                      ):Container(),
                    ],
                  ),
                ),
              );
        }),
      ),
    ));
  }

  Widget _buildChartContainer(int? total, int? visited, int? correct,String? type) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 12.h),
      /*decoration: BoxDecoration(
          // border: Border(
          //     top: BorderSide(
          //         color: AppColors.GREEN_BAR_COLOR,
          //         width: 6
          //     )
          // ),
        borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
                color: Colors.grey,
                offset: Offset(.5, 1),
                blurStyle: BlurStyle.outer,
                blurRadius: 2,
                spreadRadius: 2
            ),
          ],
      ),*/
      //height: 220,
      color: Colors.white,
      margin: EdgeInsets.symmetric(horizontal: 12.w,vertical: 10.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            alignment: Alignment.centerRight,
            margin: EdgeInsets.only(top: 10.sp),
            // color: Colors.red,
            child: Column(
              // crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if(type!.contains("MCQ"))
                  _buildRound(AppColors.GREEN_BAR_COLOR,"No Of Correct Question"),
                _buildRound(AppColors.RED_BAR_COLOR,"No Of Question Uploaded"),
                _buildRound(AppColors.YELLOW_BAR_COLOR,"No Of Question Viewed"),
              ],
            ),
          ),

          type.contains("MCQ")?_buildChart(correct,context,total,AppColors.GREEN_BAR_COLOR):Container(),
          _buildChart(visited,context,total,AppColors.YELLOW_BAR_COLOR),
          _buildChart(total,context,total,AppColors.RED_BAR_COLOR),

          Container(
            margin: EdgeInsets.only(top: 10.sp),
            child:  Align(
                alignment: Alignment.center,
                child: Text("$type",style: TextStyle(fontFamily: 'Poppins',fontSize: 12.sp,color: Colors.black,fontWeight: FontWeight.bold),)
            ),
          )
        ],
      ),
    );
  }

  Widget _buildRound(Color color,String title){
    return Container(
      margin: EdgeInsets.only(top: 2.h,bottom: 2.h),
      alignment: Alignment.centerRight,
      width: 200.w,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        // crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.only(left: 6.w,right: 10.w),
            height: 12.h,
            width: 12.w,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(100.sp),
                color: color
            ),
          ),
          SizedBox(
              width: 170.w,
              child: Text(title,style: TextStyle(fontSize: 12.sp,fontFamily: 'Poppins',color: Colors.black,fontWeight: FontWeight.w500),))
        ],
      ),
    );
  }

  Widget _buildChart(var width,BuildContext context,var total,Color color){
    var size = MediaQuery.of(context).size;

    debugPrint("size.width-->${size.width}");

    var percentage = (width*100)/total;
    // var width = (width*100)/total;
    debugPrint("width===>${width}");
    debugPrint("width===>${width=="0"}");
    debugPrint("percentage-->${(size.width * percentage)/100}");


    return SizedBox(
      child: Row(
        // crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.only(top: 16.h),
            height: 14.h,
            width: width==0?10.w:((size.width * ((width *100)/total))/100) * .8, //total,//size.width,
            color: color,
          ),
          Container(
              height: 14.h,
              margin: EdgeInsets.only(top: 16.h,left: 8.h),
              // color: Colors.red,
              alignment: Alignment.center,
              child: Text("$width",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 12.sp,color: Colors.black),))
        ],
      ),
    );
  }
}
