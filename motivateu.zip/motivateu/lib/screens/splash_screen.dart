import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

import '../main.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {


  // void _getInfo() async {
  //   // Get device id
  //   String? result = await PlatformDeviceId.getDeviceId;
  //
  //   // Update the UI
  //   setState(() {
  //     AppConstants.DEVICE_ID = result!;
  //   });
  // }


  // late IO.Socket _socket;

  @override
  void initState(){
    super.initState();
    // _getInfo();
    initSharedPref();
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    // debugPrint("ACCESS_TOKEN=>${SharedPreferencesUtils.containsKey(AppConstants.ACCESS_TOKEN)}");
    /*_socket = IO.io('http://192.168.1.184:5007', {
      // _socket = IO.io('https://api.motivateuedutech.com',{
      'transports': ['websocket'],
      // 'transport': ['websocket','polling'],
      'timeout': 5000, // set a timeout in milliseconds
    });*/
    _connectionSocket();
  }

  _connectionSocket(){
    print("SOCket->${socket.connected}");
    socket.onConnect((data) => print("Connection Established"));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("SOCket->${socket.json.connected}");
  }

  void initSharedPref() async{
    await SharedPreferencesUtils.init();
    //SharedPreferencesUtils.remove(AppConstants.ACCESS_TOKEN);
    debugPrint("AccessToken=> ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}");
    debugPrint("DEVICE_ID=> ${SharedPreferencesUtils.getString(AppConstants.DEVICE_ID)}");
    debugPrint("REFRESH_TOKEN=> ${SharedPreferencesUtils.getString(AppConstants.REFRESH_TOKEN)}");
    
    if(SharedPreferencesUtils.containsKey(AppConstants.PROFILE_ID)){
      socket.emit('connected-student',SharedPreferencesUtils.getString(AppConstants.PROFILE_ID));
    }
    
     Future.delayed(Duration(seconds: 3), () {
      // SharedPreferencesUtils.init();
      //  _socket.emit('disconnect');
      //  _socket.io..disconnect();
       //socket.io.disconnect();//..connect();
      SharedPreferencesUtils.containsKey(AppConstants.ACCESS_TOKEN) ?
      // Get.offNamed(AppRoutes.dashboard,arguments: [0])
      Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'0'})
      :Get.offNamed(AppRoutes.onBoarding);
    }
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
            height: double.maxFinite,
            width: double.maxFinite,
            decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/icons/onboarding_bg.jpg",),
                  fit: BoxFit.cover,
                )
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                /*SvgPicture.asset(
                  "assets/icons/splash.svg",
                  fit: BoxFit.fill,
                ),*/
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AspectRatio(
                      aspectRatio: 1.85.h, //8/4
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 25.h),
                        child: SvgPicture.asset(
                          "assets/icons/logo.svg",
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                    Gap(10.h),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 10.h),
                      child: Text(
                        "Democratizing Digital Learning",
                        textAlign: TextAlign.center,
                        style: GoogleFonts.poppins(
                            fontSize: 22.w, fontWeight: FontWeight.w500),
                      ),
                    )
                  ],
                )
                //AssetImage("asset/background/splash.svg"),
              ],
            )),
      ),
    );
  }
}
