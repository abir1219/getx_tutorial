import 'dart:async';

import 'package:MotivateU/controllers/hots_controller.dart';
import 'package:MotivateU/repository/hots_repository.dart';
import 'package:MotivateU/screens/qreels.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:get/get.dart';

import '../controllers/hots_topics_controller.dart';
import '../res/app_colors.dart';
import '../res/routes/app_routes.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';
import '../utils/utils.dart';

class ScenarioScreen extends StatefulWidget {
  const ScenarioScreen({super.key});

  @override
  State<ScenarioScreen> createState() => _ScenarioScreenState();
}

class _ScenarioScreenState extends State<ScenarioScreen> {

  var timeTrackController = Get.isRegistered<HotsController>()
      ? Get.find<HotsController>()
      : Get.put(HotsController());

  var controller = Get.isRegistered<HotsTopicsController>()
      ? Get.find<HotsTopicsController>()
      : Get.put(HotsTopicsController());

  bool isLoading = false;

  var text = "";
  var scenarioID = "";
  var title = "";

  Timer? timerTrack;
  int counterTracker = 0;
  bool haveTime = true;


    Future<void> sendTimeTrack([String? questionId = null]) async{
      debugPrint("--------Scenario Send Track---------");
      Map<String,dynamic> body = {
        "profile" : SharedPreferencesUtils.getString(AppConstants.PROFILE_ID),
        "question" : questionId,
        "time" : counterTracker
      };

      HotsRepository().sendTimeTrack(body).then((value) {
        if(value['errMsg'] == false){
          //Utils.showToastMessage(value['message']);
          SharedPreferencesUtils.saveInt(AppConstants.LEFT_TIME,value['leftTime']);
        }
      }).onError((error, stackTrace) {
        debugPrint("TIME_TRACK_ERROR->$error");
      });
    }

    void stopTimerTrack([String? questionID]) {
      debugPrint("--------Scenario Stop---------");
      if (timerTrack != null && timerTrack!.isActive) {
        timerTrack!.cancel();
        debugPrint("Scenario_counterTracker_STOP====>${counterTracker}");
        sendTimeTrack(questionID);
        counterTracker = 0;
      }
    }

    void startTimerTrack() {
      debugPrint("--------Scenario Start---------");
      // haveTime.value = true;
      // counterTracker.value = 0;
      timerTrack = Timer.periodic(Duration(seconds: 1), (timer) {
        // if(SharedPreferencesUtils.getInt(AppConstants.USED_TIME)! > counterTracker.value){
        if (haveTime) {
          if (SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! >= counterTracker) {
            debugPrint("Scenario_counterTracker_Timer====>${counterTracker}");
            counterTracker += 1000;
          } else {
            setState(() {
              haveTime = false;
            });
            timer.cancel(); // Stop the timer when haveTime.value becomes false
            debugPrint("<<<<<<<==Stop==>>>>>>>>>");
            stopTimerTrack();
          }
        } else {
          setState(() {
            haveTime = false;
          });
          timer.cancel(); // Stop the timer if haveTime.value is already false
        }
      });

    }


  @override
  void initState() {
    super.initState();
    /*controller.getTopicsList(Get.arguments[1]);

    setState(() {
      isLoading = true;
    });

   // Future.delayed(const Duration(milliseconds: 500), () {
      //debugPrint("INDEX=>${Get.arguments[0]}------- ${Get.find<HotsTopicsController>().hotsTopicModel.value.result![Get.arguments[0]].sId!}");
      text = controller
          .hotsTopicModel.value.result![Get.arguments[0]].passageValue!;
      scenarioID =
          controller.hotsTopicModel.value.result![Get.arguments[0]].sId!;
      title = controller.hotsTopicModel.value.result![Get.arguments[0]].title!;

      setState(() {
        isLoading = false;
      });*/
    //});
  }

  @override
  void dispose() {
    super.dispose();
    if (!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!) {
      debugPrint('<><><>Scenario dispose');
      stopTimerTrack();
    }
  }

  @override
  Widget build(BuildContext context) {
    /*if (!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)! &&
        SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! > 0) {
      // timeTrackController.startTimerTrack();
      startTimerTrack();
    }*/

    if (!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!){
      if(SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! > 0){
        // controller.startTimer();
        controller.startTimerTrack();
        controller.getTopicsList(Get.arguments[1]);

        setState(() {
          isLoading = true;
        });

        // Future.delayed(const Duration(milliseconds: 500), () {
        //debugPrint("INDEX=>${Get.arguments[0]}------- ${Get.find<HotsTopicsController>().hotsTopicModel.value.result![Get.arguments[0]].sId!}");
        text = controller
            .hotsTopicModel.value.result![Get.arguments[0]].passageValue!;
        scenarioID =
        controller.hotsTopicModel.value.result![Get.arguments[0]].sId!;
        title = controller.hotsTopicModel.value.result![Get.arguments[0]].title!;

        setState(() {
          isLoading = false;
        });
      }else {
        controller.haveTime.value = false;
        debugPrint("noooooooooooooo");
      }
    }else{
      //controller.startTimerTrack();
      controller.getTopicsList(Get.arguments[1]);

      setState(() {
        isLoading = true;
      });

      // Future.delayed(const Duration(milliseconds: 500), () {
      //debugPrint("INDEX=>${Get.arguments[0]}------- ${Get.find<HotsTopicsController>().hotsTopicModel.value.result![Get.arguments[0]].sId!}");
      text = controller
          .hotsTopicModel.value.result![Get.arguments[0]].passageValue!;
      scenarioID =
      controller.hotsTopicModel.value.result![Get.arguments[0]].sId!;
      title = controller.hotsTopicModel.value.result![Get.arguments[0]].title!;

      setState(() {
        isLoading = false;
      });
    }

    // var text = "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of de Finibus Bonorum et Malorum (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, Lorem ipsum dolor sit amet.., comes from a line in section 1.10.32.The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.";
    //var text = "<p>Ever since she burst into the scene by making it to the 1980 Moscow Olympics as a 16 – year old, P. T. Usha’s tall deeds have exemplified Indian sporting excellence. The spirit queen was so consistent for over a decade that she was truly the flag bearer who helped countrymen live the dream of a rare sporting excellence in the international arena.</p><p>&nbsp;</p><p>Usha’s greatest moment was also the most shattering in her life as she was pushed to the fourth place in the 400 meters hurdles final at the 1984 Los Angeles Olympics. The Romanian Christina Cojocaru won the bronze medal. Usha lost by an agonising l/100th of a second. But every Indian household acknowledge the sense of achievement, though it fell short of India’s first Olympic medal from the track. Several girls born during the 1980s were named after the golden girl. It served as an eloquent testimony to the love and affection many people had for Usha.</p>";

    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: AppColors.BOTTOM_SHEET_BACKGROUND,
        title: Text(
          title,
          style: TextStyle(
            fontSize: 16.sp,
          ),
        ),
        actions: [
          GestureDetector(
            onTap: () =>
                Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      QReels(type: 'scenario', scenarioId: scenarioID),
                )),
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 8.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text(
                    "Questions",
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),
                  ),
                  Icon(Icons.next_plan)
                ],
              ),
            ),
          )
        ],
        //centerTitle: true,
      ),
      body: WillPopScope(
        onWillPop: () async {
          // Get.offNamed(AppRoutes.dashboard, arguments: [1]);
          Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'1'});
          return true;
        },
        child: haveTime
            ? Obx(() => controller.isLoading.value
              ? Center(
          child: SizedBox(
              height: 24.h,
              width: 24.w,
              child: const CircularProgressIndicator(
                color: Colors.black,
              ),
          ),
        )
              :Container(
          color: AppColors.ACCOUNT_PAGE_BG_COLOR,
          height: double.maxFinite,
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(vertical: 8.h),
          child: isLoading
                ? Center(
              child: SizedBox(
                height: 24.h,
                width: 24.w,
                child: const CircularProgressIndicator(
                  color: Colors.black,
                ),
              ),
          )
                : NotificationListener<OverscrollIndicatorNotification>(
              onNotification:
                  (OverscrollIndicatorNotification notification) {
                notification.disallowIndicator();
                return true;
              },
              child: Scrollbar(
                child: SingleChildScrollView(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 10.w),
                    // padding: EdgeInsets.symmetric(vertical: 4.h),
                    child: TeXView(
                      child: TeXViewDocument(text,
                          style: const TeXViewStyle.fromCSS(
                            'font-size: 16px; font-weight: normal; color: black; font-family:Alata',
                          )),
                    ),
                  ),
                ),
              ),
          ),
        ),
            )
            : Container(
          child: Center(
              child: Text("No free minutes available for the day")),
        ),
      ),
    ));
  }
}
