import 'package:MotivateU/controllers/reels_controller.dart';
import 'package:MotivateU/helper/api_end_points.dart';
import 'package:MotivateU/models/data_model_mcq.dart';
import 'package:MotivateU/models/reels_model.dart';
import 'package:MotivateU/screens/scenario_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import '../main.dart';
import '../res/app_colors.dart';
import '../widgets/qreels_widget.dart';

class McqReels extends StatefulWidget {
  final int index;
  final String type;

  const McqReels({super.key, required this.index, required this.type});

  @override
  State<McqReels> createState() => _McqReelsState();
}

class _McqReelsState extends State<McqReels> {
  var controller = Get.find<ReelsController>();
  int correctAns = -1;
  int submittedAns = -1;
  bool isClicked = false;

  Map<String,dynamic> socketData = {};

  var result;

  @override
  void initState() {
    super.initState();
    //checkData(Get.find<ReelsController>().reelsData.value.result![widget.index]);
    //debugPrint("MCQ-->${socket.connected}");
    // if(socket.connected){
    //   socket.on('reel-action', (data) {
    //     debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
    //     setState(() {
    //       socketData = data['data'];
    //     });
    //   });
    // }

  }


  @override
  void dispose() {
    super.dispose();
    debugPrint("<<<<<MCQ_DISPOSE>>>>>");
  }

  @override
  Widget build(BuildContext context) {
    debugPrint("<<<<<MCQ_build>>>>>");

    result = Get.find<ReelsController>().reelsList![widget.index];
    if(socket.connected){
      debugPrint("<<<<<MCQ_DATA>>>>> ${result.sId}");
      //socket.emit('reel-action',result.sId);
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        /*setState(() {
              socketData = data['data'];
            });*/
        // Get.find<ReelsController>().socketData = data['data'];
        Get.find<ReelsController>().socketData.assignAll(data['data']);
        debugPrint("<<<<<socketData MCQ>>>>> ${socketData}");


      });
      //socket.on('reel-action', (data) => debugPrint("<<<<<DATA>>>>> $data"));
    }
    checkData(result);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          // gradient: result.questions![0].quest!.questionBackground == ""
          //     ? LinearGradient(
          //         begin: Alignment.topLeft,
          //         end: Alignment.bottomRight,
          //         colors: [Color.fromRGBO(200,200,200,75), Color.fromRGBO(137,115,153,100)])
          //     : null
          // color: result.questions![0].quest!.questionBackground == ""?Colors.white:null,
          color: result.questions![0].quest!.questionBackground == "" ||
              result.questions![0].quest!.questionBackground == null
              ? Colors.transparent
              : Colors.black,
        ),
        // colors: [Color.fromRGBO(200,200,200,75), Color.fromRGBO(137,115,153,100)]):null),
        child: Scaffold(
          backgroundColor:
              // result.questions![0].quest!.questionBackground ==""?
              // Colors.grey.withOpacity(0.85) :
              Colors.transparent,
          body: Stack(
            children: [
              Container(
                padding: EdgeInsets.only(left: 8.w, right: 8.w),
                decoration:BoxDecoration(
                    color: result.questions![0].quest!.questionBackground != "" ||
                        result.questions![0].quest!.questionBackground != null
                        ? Colors.black
                        : Colors.transparent,
                    image: result.questions![0].quest!.questionBackground != ""||
                        result.questions![0].quest!.questionBackground != null
                        ? DecorationImage(
                        image: NetworkImage(
                            "${ApiEndPoints.IMAGE_URL}${result.questions![0].quest!.questionBackground}"),
                        fit: BoxFit.cover,
                        opacity: 0.45)
                        : null),

                /*BoxDecoration(
                    color: result.questions![0].quest!.questionBackground != ""
                        ? Colors.black
                        : Colors.transparent,
                    image: result.questions![0].quest!.questionBackground != ""
                        ? DecorationImage(
                            image: NetworkImage(ApiEndPoints.IMAGE_URL +
                                "${result.questions![0].quest!.questionBackground}"),
                            fit: BoxFit.cover,
                            opacity: 0.45)
                        : null),*/
                // width: 310.w,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                        width: double.maxFinite,
                        //margin: EdgeInsets.only(right: 50),
                        padding: EdgeInsets.symmetric(
                            vertical: 10.h, horizontal: 15.w),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(35.w),
                            color: AppColors.BOTTOM_NAVIGATION_BAR_COLOR
                        ),
                        child: TeXView(
                            child: TeXViewDocument(
                                result.questions![0].quest!.questionValue!,
                                //'<math xmlns="http://www.w3.org/1998/Math/MathML"><mroot><mn>100</mn><mrow><mn>21</mn><mo>&#xA0;</mo></mrow></mroot></math>',
                                style: TeXViewStyle.fromCSS(
                                  'font-size: 16px; font-weight: bold; color: white;text-align:center;',
                                )))
                        // Text(
                        //   "${result.questions![0].quest!.questionValue}",
                        //   textAlign: TextAlign.center,
                        //   style:
                        //   TextStyle(fontSize: 20.sp, color: AppColors.TITLE_TEXT_WHITE,fontFamily: "Alata",height: 1.25),
                        // ),
                        ),
                    const SizedBox(height: 20),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return optionBuilder(
                          result: result,
                          option: result.questions![0].option![index],
                          correctIndex: result.questions![0].correctOption!,
                          currentIndex: index,
                          questionIndex: widget.index,
                          questionId: result.questions![0].sId!,
                          func: () {
                            saveDataToHive(result.questions![0], index, result);
                            // Utils.showToastMessage("Click");
                            debugPrint(
                                "QId->${result.questions![0].sId}\nCorrectIndex->${result.questions![0].correctOption}\nSelectedId->$index");
                            result.explanation != null
                                ? _showDialog(context, result.explanation!)
                                : null;
                          },
                        );
                      },
                      itemCount: result.questions![0].option!.length,
                    )
                  ],
                ),
              ),
              Positioned(
                left: 0,
                bottom: 0,
                child: footerKeyword(keyword: result.keywords),
              ),
              Positioned(
                  right: 0,
                  bottom: 0,
                  child: Obx(() => interactiveIcons(
                        reelsId: result.sId!,
                        context: context,
                        isBackground:
                            result.questions![0].quest!.questionBackground == ""
                                ? false
                                : true,
                        result: result,
                        socketData: Get.find<ReelsController>().socketData
                    ),
                  )),
              widget.type == "scenario"
                  ? Positioned(
                      top: 10,
                      right: 10,
                      child: GestureDetector(
                        onTap: () => showDialog(
                          context: context,
                          builder: (context) => ScenarioDialog(
                            scenario: result.scenario!,
                          ),
                        ),
                        child: Container(
                          height: 40.h,
                          width: 40.w,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: Colors.white),
                          child: Container(
                            height: 35.h,
                            width: 35.w,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Colors.white.withOpacity(0.6)),
                            child: Icon(
                              Icons.info,
                              size: 40.sp,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ))
                  : Container()
            ],
          ),
        ),
      ),
    );
  }

  Widget optionBuilder(
      {required Result result,
      required String questionId,
      required String option,
      required int questionIndex,
      required int correctIndex,
      required int currentIndex,
      required void Function() func}) {
    return GestureDetector(
      onTap: () => isClicked == false ? func() : null,
      //debugPrint("isClicked=>$isClicked");

      child: Container(
        // height: 55.h,
        // width: double.maxFinite
        margin: EdgeInsets.only(top: 35.w, left: 12.w, right: 50.w),
        decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.4),
                  offset: Offset.fromDirection(0.5, 0.5),
                  spreadRadius: 1,
                  blurRadius: 2)
            ],
            borderRadius: BorderRadius.circular(35.w),
            color: correctAns == currentIndex
                ? AppColors.MCQ_CORRECT_QUESTION_BG_COLOR
                : submittedAns == currentIndex
                    ? AppColors.MCQ_WRONG_QUESTION_BG_COLOR
                    : Colors.white),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              height: 40.h,
              width: 40.w,
              margin: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(200),
                color: AppColors.BOTTOM_SHEET_BACKGROUND,
              ),
              child: Center(
                child: Text(
                  "${currentIndex + 1}",
                  style: TextStyle(
                      fontFamily: "Poppins",
                      fontSize: 20.sp,
                      color: Colors.white),
                ),
              ),
            ),
            Expanded(
              child: AbsorbPointer(
                absorbing: true,
                child: Container(
                  margin: EdgeInsets.only(left: 12.w),
                  // padding: EdgeInsets.symmetric(vertical: 4.h),
                  child: TeXView(
                    child: TeXViewDocument(
                        // "sdfkjlksdjflksd jflksdjflkjds flksdjlkfjsdlkfjsdlkf jlksdjflksdjflksd jlfksdjlkf jsdlkf jdsljlksdjfl kdsfjlsdkjfl ksdjflk ds",
                        option,
                        style: TeXViewStyle.fromCSS(
                          'font-size: 16px; font-weight: bold; color: black',
                        )),
                  ),

                  /*Text(
                      option,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontFamily: "Alata",
                          fontSize: 16.sp,
                          color: Colors.black),
                    )*/
                ),
              ),
            )
          ],
        ),
      ),
    );

    /*GestureDetector(
      onTap: () => debugPrint("Clicked"),
      child: Container(
        height: 55.h,
        margin: EdgeInsets.only(top: 35.w, left: 12.w, right: 50.w),
        decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.4),
                  offset: Offset.fromDirection(0.5, 0.5),
                  spreadRadius: 1,
                  blurRadius: 2)
            ],
            borderRadius: BorderRadius.circular(35.w),
            color: correctAns == currentIndex
                ? AppColors.MCQ_CORRECT_QUESTION_BG_COLOR
                : submittedAns == currentIndex
                ? AppColors.MCQ_WRONG_QUESTION_BG_COLOR
                : Colors.white),
        child: Row(
          children: [
            Container(
              height: 40.h,
              width: 40.w,
              margin: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(200),
                color: AppColors.BOTTOM_SHEET_BACKGROUND,
              ),
              child: Center(
                child: Text(
                  "${currentIndex + 1}",
                  style: TextStyle(
                      fontFamily: "Poppins",
                      fontSize: 20.sp,
                      color: Colors.white),
                ),
              ),
            ),
            Expanded(
              child: Container(
                // height: 200.0, // Set an appropriate height
                width: 220.sp,
                color: Colors.red,// Set an appropriate width
                margin: EdgeInsets.only(left: 12.w),
                child: TeXView(
                  child: TeXViewContainer(
                    child: TeXViewDocument(
                      // "sdfkjlksdjflksd jflksdjflkjds flksdjlkfjsdlkfjsdlkf jlksdjflksdjflksd jlfksdjlkf jsdlkf jdsljlksdjfl kdsfjlsdkjfl ksdjflk ds",
                        //option,
                      "sadlkjlkjdflkjsdflk jlksdf jlksdjflks jdlfk jssdkflk okdsfl; ;lkdf;l ;lkl;fd gkl;kl;kl;f kgdlkfjdsfsdjfkjkflksdjfk jkdjsflk dsjflkjdsflkj kdsfjlk jsdjflkjdsf iorjotj o jjdsjfld ",
                        style: TeXViewStyle.fromCSS(
                          'font-size: 16px; font-weight: bold; color: black',
                        )),
                  )
                ),
              ),
            ),
          ],
        ),
      ),
    );*/
  }

  Future<void> checkData(Result result) async {
    var box = await Hive.openBox('motivate_u_mcq');
    // box.clear();
    // Retrieve the list from the Hive box
    List<dynamic> myList = box.values.toList().reversed.toList();
    if (myList.length > 0) {
      for (int i = 0; i < myList.length; i++) {
        if (myList[i].questionId == result.questions![0].sId!) {
          correctAns = myList[i].correctAnsIndex;
          submittedAns = myList[i].SelectedAnsIndex;
          isClicked = myList[i].isSelected;
          debugPrint("myList=>${myList[i].questionId}");
          break;
        }
      }
    }
  }

  void _showDialog(BuildContext context, String explanation) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
      barrierColor: Colors.black.withOpacity(0.5),
      transitionDuration: Duration(milliseconds: 300),
      pageBuilder: (BuildContext context, Animation<double> animation,
          Animation<double> secondaryAnimation) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: Container(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Text(explanation),
                Container(
                  margin: EdgeInsets.only(left: 12.w),
                  // padding: EdgeInsets.symmetric(vertical: 4.h),
                  child: TeXView(
                    child: TeXViewDocument(explanation,
                        style: TeXViewStyle.fromCSS(
                          'font-size: 16px; font-weight: bold; color: black',
                        )),
                  ),
                )
              ],
            ),
          ),
        );
      },
      transitionBuilder: (BuildContext context, Animation<double> animation,
          Animation<double> secondaryAnimation, Widget child) {
        const begin = Offset(0, 1); // Start position (bottom of the screen)
        const end = Offset(0, 0); // End position (center of the screen)
        const curve = Curves.easeInOut; // Animation curve

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        var offsetAnimation = animation.drive(tween);

        return SlideTransition(
          position: offsetAnimation,
          child: child,
        );
      },
    );
  }

  void saveDataToHive(Questions questions, int index, Result result) async {
    var box = await Hive.openBox('motivate_u_mcq');

    result.questions![0].correctOption! == index
        ? controller.correctAnswer.value = true
        : false;

    DataModelMcq model = DataModelMcq(
        questionId: result.questions![0].sId!,
        correctAnsIndex: result.questions![0].correctOption!,
        SelectedAnsIndex: index,
        isSelected: true);
    setState(() {
      box.add(model);
      checkData(result);
    });
  }
}
