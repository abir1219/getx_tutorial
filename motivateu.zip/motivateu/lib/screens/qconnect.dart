import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import '../controllers/connection_my_list_controller.dart';
import '../res/app_colors.dart';
import '../utils/utils.dart';
import '../widgets/q_connect_header_top.dart';
import '../widgets/qconnect_post.dart';
import '../widgets/qconnect_reusable_widgets.dart';

class QConnect extends StatefulWidget {
  const QConnect({super.key});

  @override
  State<QConnect> createState() => _QConnectState();
}

class _QConnectState extends State<QConnect> {

  var controller = Get.isRegistered<ConnectionMyListController>()?Get.find<ConnectionMyListController>():Get.put(ConnectionMyListController());

  @override
  void initState() {
    super.initState();
    controller.getConnectionMyList(1, "/group", "");
    // controller.fetchPost(1);
    clearHive();
  }


  @override
  void dispose() {
    super.dispose();
    debugPrint("=====DISPOSE");
  }

  Future<void> clearHive() async {
    var box = await Hive.openBox('motivate_u_mcq');
    box.clear();
  }

  DateTime? currentBackPressTime;
  List<bool> selectedGroups = [false, false, false];

  bool isMyGroupClicked = false;

  @override
  Widget build(BuildContext context) {

    return SafeArea(
      child: WillPopScope(
        onWillPop: () async {
          DateTime now = DateTime.now();
          if (currentBackPressTime == null ||
              now.difference(currentBackPressTime!) > Duration(seconds: 2)) {
            currentBackPressTime = now;
            Utils.showToastMessage("Press back again to exit");
            return false;
          }
          SystemNavigator.pop();
          return true;
        },
        child: RefreshIndicator(
          color: Colors.black,
          onRefresh: () async{
            setState(() {
              isMyGroupClicked = false;
              Get.isRegistered<ConnectionMyListController>()?Get.find<ConnectionMyListController>().postList.clear():
                  Get.put(ConnectionMyListController()).postList.clear();
            });
            controller.fetchPost(1);
          },
          child: Scaffold(
              body: Container(
            height: double.maxFinite,
            width: double.maxFinite,
            // margin: EdgeInsets.only(bottom: 15.h),
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage("assets/icons/login_bg.jpg"),
                    fit: BoxFit.cover)),
            child: Column(
              children: [
                QConnectHeaderTop(),
                Container(
                  // height: 235.h,
                  margin: EdgeInsets.only(top: 25.h, left: 15.w, right: 15.w),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.0),
                      color: AppColors.ON_BOARDING_BUTTON_COLOR
                          .withOpacity(0.08)), //Color(0xFFF8F8F8)),
                  child: Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isMyGroupClicked = !isMyGroupClicked;
                          });
                        },
                        child: Container(
                          height: 30.h,
                          decoration: BoxDecoration(
                              color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,
                              borderRadius: BorderRadius.circular(6.0)),
                          child: Row(
                            children: [
                              Expanded(
                                child: Container(
                                  child: Center(
                                    child: Text(
                                      "MY GROUP",
                                      style: TextStyle(
                                          fontFamily: "Poppins",
                                          fontSize: 12.sp,
                                          color: AppColors.TITLE_TEXT_WHITE),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                  height: 25.h,
                                  width: 25.h,
                                  margin: EdgeInsets.only(
                                      right: 4.w, top: 4.h, bottom: 4.h),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(4),
                                      color: Colors.white.withOpacity(0.3)),
                                  child: Icon(
                                      isMyGroupClicked
                                          ? Icons.arrow_drop_up_sharp
                                          : Icons.arrow_drop_down_sharp,
                                      color: Colors.white))
                            ],
                          ),
                        ),
                      ),
                      isMyGroupClicked
                          ? Obx(() => !controller.isLoading.value?ListView.builder(
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                            return Obx(() => reusableGroup(
                              context,
                                  controller.groupList[0]![index].name,
                                  controller.myGroupSelection[index], () {
                                /*setState(() {
                                  selectedGroups[0] = !selectedGroups[0];
                                });*/
                                controller.toggleSelectedGroupList(index);
                                controller.toggleGroupSelectionStatus(index);
          //controller.fetchPost(1); // deleted
                              }),
                            );
                        },itemCount: controller.groupList[0]!.length,):Container(),
                          )
                          : Container()
                    ],
                  ),
                ),
                QConnectPostList(),
              ],
            ),
          )),
        ),
      ),
    );
  }
}
