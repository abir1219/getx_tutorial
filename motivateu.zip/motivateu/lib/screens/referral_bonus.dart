import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../controllers/dashboard_controller.dart';
import '../controllers/get_profile_controller.dart';
import '../res/app_colors.dart';
import '../widgets/dashboard_widget.dart';
import '../widgets/member_details_header.dart';

class ReferralBonus extends StatelessWidget {
  const ReferralBonus({super.key});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    // debugPrint("ksjkjsdfkjf=>${Get.find<DashboardController>().pageIndex.value}");

    return SafeArea(
        child: Scaffold(
      body: Container(
        height: double.maxFinite,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/icons/login_bg.png"),
                fit: BoxFit.cover)),
        child: Column(
          children: [
           /* Container(
              height: size.height * .15,
              margin: EdgeInsets.only(left: 15.w),
              child: Center(
                child: GestureDetector(
                  onTap: () => Get.back(),
                  child: Container(
                    margin: EdgeInsets.only(top: 30.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 24.h,
                          width: 24.w,
                          child: Icon(
                            Icons.arrow_back_ios_new_outlined,
                            color: AppColors.BACK_ARROW_COLOR,
                          ),
                        ),
                        Gap(5.h),
                        Text("Back",
                            style: TextStyle(
                                fontSize: 20.sp,
                                color: AppColors.FIELD_HINT_COLOR,
                                fontFamily: 'Poppins'))
                      ],
                    ),
                  ),
                ),
              ),
            ),*/
            MemberDetailsHeader(phone: Get.find<GetProfileController>().getProfileModel.value.result![0].phone!),
            Container(
              height: size.height * .55, //double.maxFinite,//
              margin: EdgeInsets.only(top: 50.h, left: 12.w, right: 12.w),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(5.w),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        offset: Offset(0.5, 0.5),
                        blurRadius: 1,
                        spreadRadius: 1)
                  ]),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 60.h,
                    margin: EdgeInsets.only(top: 15.h),
                    color: Color(0xFFECF9FE),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 12.w),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Bonus Wallet",
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    color: AppColors.BOTTOM_SHEET_BACKGROUND,
                                    fontSize: 14.sp),
                              ),
                              Text(
                                "Total bonus earned till date: ₹650",
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    color: AppColors.BOTTOM_SHEET_BACKGROUND,
                                    fontSize: 11.sp),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(right: 12.w),
                          child: Text(
                            "₹400",
                            style: TextStyle(
                                fontFamily: "Poppins",
                                color: Color(0xFF1A002D),
                                fontSize: 16.sp),
                          ),
                        )
                      ],
                    ),
                  ),
                  Container(
                    margin:
                        EdgeInsets.only(top: 20.h, left: 12.w, bottom: 12.h),
                    child: Text(
                      "Transaction history",
                      style: TextStyle(
                          fontSize: 14.sp,
                          fontFamily: "Poppins",
                          color: Color(0xFF1A002D)),
                    ),
                  ),
                  Expanded(
                    child:
                        NotificationListener<OverscrollIndicatorNotification>(
                      onNotification:
                          (OverscrollIndicatorNotification overscroll) {
                        overscroll.disallowIndicator();
                        return true;
                      },
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return Container(
                            margin: EdgeInsets.symmetric(
                                horizontal: 12.w, vertical: 6.h),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text("debit on 12.07.2023",
                                    style: TextStyle(
                                        fontSize: 12.sp,
                                        fontFamily: "Poppins",
                                        color: Color(0xFF1A002D))),
                                Text("₹500",
                                    style: TextStyle(
                                        fontSize: 12.sp,
                                        fontFamily: "Poppins",
                                        color: Color(0xFF1A002D)))
                              ],
                            ),
                          );
                        },
                        itemCount: 100,
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
          /*bottomNavigationBar: BottomNavigationBar(
            currentIndex: Get.find<DashboardController>().pageIndex.value,
            backgroundColor: AppColors.BOTTOM_SHEET_BACKGROUND,
            items: bottomTabs,
            elevation: 0,
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            onTap: (value) {
              Get.find<DashboardController>().pageIndex.value = value;
            },
          ),*/
    ));
  }
}
