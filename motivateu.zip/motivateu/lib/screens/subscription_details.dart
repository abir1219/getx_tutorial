
import 'dart:io';

import 'package:MotivateU/controllers/get_profile_controller.dart';
import 'package:MotivateU/controllers/subscription_controller.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/screens/phone_pe_payment_gateway.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_file_downloader/flutter_file_downloader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';

import '../res/routes/app_routes.dart';
import '../widgets/member_details_header.dart';

class SubscriptionDetails extends StatefulWidget {
  const SubscriptionDetails({super.key});

  @override
  State<SubscriptionDetails> createState() => _SubscriptionDetailsState();
}

class _SubscriptionDetailsState extends State<SubscriptionDetails> {
  var controller = Get.find<SubscriptionController>();
  int selectedIndex = 1;
  int days = 0;
  String formattedEndDateTime = "";
  String formattedStartDateTime = "";


  @override
  void initState() {
    super.initState();
    controller.getSubscriptionList();
    controller.mySubscriptionList();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async{
        // Get.offNamed(AppRoutes.dashboard, arguments: [4]);
        Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'4'});
        return true;
      },
      child: SafeArea(
          child: RefreshIndicator(
            color: Colors.black,
            onRefresh: () async{
              controller.getSubscriptionList();
              controller.mySubscriptionList();
              setState(() {
                selectedIndex = 1;
              });
            },
            child: Scaffold(
              appBar: AppBar(
                elevation: 0,
                backgroundColor: AppColors.BOTTOM_SHEET_BACKGROUND,
                title: Text(
                  'Subscription Details',
                  style: TextStyle(
                    fontSize: 16.sp,
                  ),
                ),
                centerTitle: true,
              ),
        body: Container(
            height: double.maxFinite,
            decoration: BoxDecoration(
                color: Colors.white,
                image: DecorationImage(
                    image: AssetImage("assets/icons/login_bg.png"),
                    fit: BoxFit.cover)),
            child: ListView(
              physics: NeverScrollableScrollPhysics(),
              children: [
                Obx(() {
                  if(controller.isAnotherLoading.value== false && controller.mySubscriptionListModel.value.result!.length > 0){
                    /*setState(() {
                      isValue = true;
                    });*/
                    //controller.isValue.value = true;
                    debugPrint("PRICE==>${controller.mySubscriptionListModel.value.result![0].subscription!.price}");
                    debugPrint("name==>${controller.mySubscriptionListModel.value.result![0].subscription!.name}");

                    DateTime endDateTime = DateTime.parse(controller.mySubscriptionListModel.value.result![0].endDate!).toLocal();
                    DateTime startDateTime = DateTime.parse(controller.mySubscriptionListModel.value.result![0].startDate!).toLocal();

                    // formattedEndDateTime = DateFormat('d MMMM yyyy @ HH:mm\'Hrs\' z').format(endDateTime);
                    formattedEndDateTime = DateFormat('d MMMM yyyy').format(endDateTime);
                    formattedStartDateTime = DateFormat('d MMMM yyyy').format(startDateTime);

                    DateTime targetDateTime = DateTime.parse(controller.mySubscriptionListModel.value.result![0].endDate!).toLocal();
                    DateTime currentDateTime = DateTime.now();

                    Duration remainingDuration = targetDateTime.difference(currentDateTime);

                    days = remainingDuration.inDays;
                    // int hours = remainingDuration.inHours % 24;
                    // int minutes = remainingDuration.inMinutes % 60;
                    // int seconds = remainingDuration.inSeconds % 60;
                  }

                  if(Get.isRegistered<GetProfileController>()?Get.find<GetProfileController>().getProfileModel.value.result != null
                      :Get.put(GetProfileController()).getProfileModel.value.result != null){
                    MemberDetailsHeader(phone: Get.find<GetProfileController>().getProfileModel.value.result![0].phone!
                      //Get.find<GetProfileController>().getProfileModel.value.result![0].phone!
                    );
                  }


                  return  controller.isAnotherLoading.value?Container()
                      :controller.mySubscriptionListModel.value.result!.length>0?Container(
                    height: 160.h,
                    margin: EdgeInsets.only(left: 15.w, right: 15.w, top: 15.w),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5.w),
                        boxShadow: [
                          BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              offset: Offset(0.2, 0.2),
                              blurRadius: 0.3,
                              spreadRadius: 0.5)
                        ]),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height: 22.h,
                          width: 22.w,
                          margin: EdgeInsets.only(top: 15.h, left: 5.w),
                          child: Center(
                            child: SvgPicture.asset(
                              "assets/icons/subscription_icon.svg",
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(left: 5.w, top: 15.w),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                "Subscription",
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 14.sp,
                                    color: Color(0xFF1A002D)),
                              ),
                              Text(
                                "$days days remaining",
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 10.sp,
                                    color: AppColors.BOTTOM_SHEET_BACKGROUND),
                              ),
                              Gap(10.h),
                              Text(
                                // "Subscription expires on 11 August 2023 @ 23:59Hrs IST",
                                "Subscription expires on $formattedEndDateTime",
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 11.sp,
                                    color: AppColors.BOTTOM_SHEET_BACKGROUND),
                              ),
                              Text(
                                "Last Subscription date: $formattedStartDateTime",
                                style: TextStyle(
                                    fontFamily: "Poppins",
                                    fontSize: 11.sp,
                                    color: AppColors.BOTTOM_SHEET_BACKGROUND),
                              ),
                              Gap(12.h),
                              GestureDetector(
                                onTap: () => null,
                                child: Container(
                                  height: 22.h,
                                  width: 104.w,
                                  decoration: BoxDecoration(
                                    color: AppColors.TITLE_TEXT_GREEN,
                                    borderRadius: BorderRadius.circular(40.w),
                                  ),
                                  child: Center(
                                      child: Text(
                                        "SUBSCRIBE NOW",
                                        style: TextStyle(
                                            fontFamily: "Poppins",
                                            fontSize: 10.w,
                                            color: AppColors.TITLE_TEXT_WHITE),
                                      )),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  )
                  :Container();
                },),
                Container(
                  width: double.maxFinite,
                  color: Colors.white,
                  margin: EdgeInsets.symmetric(horizontal: 10.w,vertical: 15.h),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      buildTagButton(context,'Subscription Details',() {
                        controller.getSubscriptionList();
                      },1),
                      buildTagButton(context,'My Plans',() {
                        controller.mySubscriptionList();
                      },2),
                      buildTagButton(context,'Plan History',() {
                        controller.mySubscriptionHistoryList();
                      },3),
                    ],
                  ),
                ),
                if(selectedIndex == 1)
                  Obx(() => controller.isLoading.value?
                      Container(
                        margin: EdgeInsets.only(top: 10.h),
                        height: /*controller.isValue.value?325.h:*/450.h,
                        child: Center(
                          child: SizedBox(
                            height: 20.h,
                            width: 20.w,
                            child: CircularProgressIndicator(
                              color: Colors.black,
                            ),
                          ),
                        ),
                      )
                      :Container(
                        margin: EdgeInsets.only(left: 15.w,right: 15.w,/*top: 5.w*/),
                        height: /*controller.isValue.value?325.h:*/450.h,
                        child: NotificationListener<OverscrollIndicatorNotification>(
                          onNotification: (OverscrollIndicatorNotification notification) {
                            notification.disallowIndicator();
                            return true;
                          },
                          child: controller
                              .subscriptionModel.value.result!.length>0?
                          ListView.builder(
                                              shrinkWrap: true,
                                              itemBuilder: (context, index) => Column(
                          children: [
                            subscriptionDetails(
                                color: (index + 1) % 2 == 0
                                    ? Color(0xFFF0F0F0)
                                    : Color(0xFFD7F4FF),
                                price: controller
                                    .subscriptionModel.value.result![index].price!,
                                Title: controller
                                    .subscriptionModel.value.result![index].name!,
                                subtitle: controller.subscriptionModel.value
                                    .result![index].description!,function: () {
                              showDialog(
                                  context: context,
                                  builder: (context) => showAlertDialog(index));
                                    },),
                            index !=
                                    controller
                                        .subscriptionModel.value.result!.length
                                ? Divider(color: Color(0xFFF0F0F0))
                                : Container(),
                          ],
                                              ),
                                              itemCount: controller.subscriptionModel.value.result!.length,
                                            )
                              :Container(
                            child: Center(child: Text("No Subscription details found")),
                          ),
                        ),
                      ),),
                if(selectedIndex == 2)
                  Obx(() => controller.isAnotherLoading.value?Container(
                    height: /*controller.isValue.value?325.h:*/450.h,
                    margin: EdgeInsets.only(top: 10.h),
                    child: Center(
                      child: SizedBox(
                        height: 20.h,
                        width: 20.w,
                        child: CircularProgressIndicator(
                          color: Colors.black,
                        ),
                      ),
                    ),
                  )
                      :Container(
                      margin: EdgeInsets.only(left: 15.w,right: 15.w,/*top: 5.w*/),
                      height: /*controller.isValue.value?325.h:*/450.h,
                      child: controller.mySubscriptionListModel.value.result!.length > 0?NotificationListener<OverscrollIndicatorNotification>(
                        onNotification: (OverscrollIndicatorNotification notification) {
                          notification.disallowIndicator();
                          return true;
                        },
                        child: ListView.builder(
                          shrinkWrap: true,
                            physics: AlwaysScrollableScrollPhysics(),
                          itemBuilder: (context, index) => Column(
                            children: [
                              index==0
                                  ?myActivePlanDetails(index)
                              :myOtherActivePlanDetails(index,controller.mySubscriptionListModel.value.result![index].status!),
                              index !=
                                  controller
                                      .mySubscriptionListModel.value.result!.length
                                  ? Divider(color: Color(0xFFF0F0F0))
                                  : Container(),
                            ],
                          ),
                          itemCount: controller.mySubscriptionListModel.value.result!.length,
                        )
                        )
                          :Container(
                        child: Center(child: Text("No plan found",style: TextStyle(fontFamily: 'Alata',color: Colors.black,fontSize: 16.sp),)),
                      ),
                    ),
                  ),
                if(selectedIndex == 3)
                  Obx(() => controller.isLoading.value?Container(
                    height: /*controller.isValue.value?325.h:*/450.h,
                    margin: EdgeInsets.only(top: 10.h),
                    child: Center(
                      child: SizedBox(
                        height: 20.h,
                        width: 20.w,
                        child: CircularProgressIndicator(
                          color: Colors.black,
                        ),
                      ),
                    ),
                  )
                      :Container(
                    margin: EdgeInsets.only(left: 15.w,right: 15.w,/*top: 5.w*/),
                     height: /*controller.isValue.value?325.h:*/450.h,
                    //color: Colors.red,
                    child: controller.mySubscriptionListModel.value.result!.length > 0?
                    NotificationListener<OverscrollIndicatorNotification>(
                      onNotification: (OverscrollIndicatorNotification notification) {
                        notification.disallowIndicator();
                        return true;
                      },
                      child: ListView.builder(
                        shrinkWrap: true,
                        //physics: AlwaysScrollableScrollPhysics(),
                        itemBuilder: (context, index) => Column(
                          children: [
                            // index==0
                            if(controller.mySubscriptionListModel.value.result![index].status  == "active")
                                myActivePlanDetails(index),
                            // if(controller.mySubscriptionListModel.value.result![index].status  == "unexpired")
                              myOtherActivePlanDetails(index,controller.mySubscriptionListModel.value.result![index].status!),
                            index !=
                                controller
                                    .subscriptionModel.value.result!.length
                                ? Divider(color: Color(0xFFF0F0F0))
                                : Container(),
                          ],
                        ),
                        itemCount: controller.mySubscriptionListModel.value.result!.length,
                      ),
                    )
                        :Container(
                      child: Center(child: Text("No plan history found",style: TextStyle(fontFamily: 'Alata',color: Colors.black,fontSize: 16.sp),)),
                    ),
                  ),
                  ),
               /* Container(
                  width: double.maxFinite,
                  //margin: EdgeInsets.only(top: 10.h),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Payment via",
                        style: TextStyle(
                            fontFamily: "Poppins",
                            fontSize: 16.w,
                            color: Color(0xFF1A002D)),
                      ),
                      Gap(15.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Container(
                            height: 30.h,
                            width: 110.w, // Adjust the width as needed
                            margin: EdgeInsets.symmetric(horizontal: 4),
                            child: Image.asset(
                              "assets/icons/g_pay.jpg",
                              fit: BoxFit.contain,
                            ),
                          ),
                          Container(
                            height: 30.h,
                            width: 110.w, // Adjust the width as needed
                            margin: EdgeInsets.symmetric(horizontal: 4),
                            child: Image.asset("assets/icons/ph_pay.jpg",
                                fit: BoxFit.contain),
                          ),
                          Container(
                            height: 30.h,
                            width: 110.w, // Adjust the width as needed
                            margin: EdgeInsets.symmetric(horizontal: 4),
                            child: Image.asset("assets/icons/paytm.jpg",
                                fit: BoxFit.contain),
                          ),
                        ],
                      )
                    ],
                  ),
                )*/
              ],
            ),
        ),
      ),
          )),
    );
  }

  Widget subscriptionDetails(
      {required Color color,
      required int price,
      required String Title,
      required String subtitle,required void Function() function}) {
    return GestureDetector(
      onTap: () => function(),
      child: Container(
        margin: EdgeInsets.only(bottom: 10.w),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              blurRadius: 1,
              offset: Offset(.5, .5)
            )
          ]
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            priceBox(color: color, price: price),
            Container(
              margin: EdgeInsets.only(left: 12.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    Title,
                    style: TextStyle(
                        color: Color(0xFF1A002D),
                        fontFamily: "Poppins",
                        fontSize: 14.sp),
                  ),
                  Text(subtitle,
                      style: TextStyle(
                          color: AppColors.BOTTOM_SHEET_BACKGROUND,
                          fontFamily: "Poppins",
                          fontSize: 11.sp)),
                ],
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                height: 40.h,
                width: 40.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(100),
                    bottomLeft: Radius.circular(100),
                  ),
                  color: AppColors.BOTTOM_SHEET_BACKGROUND,
                ),
                child: Center(
                  child: Icon(Icons.arrow_forward,color: Colors.white,),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget priceBox({required int price, required Color color}) {
    return Container(
      height: 84.h,
      width: 84.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6.w),
        color: color,
      ),
      child: Center(
        child: Text(
          "₹$price",
          style: TextStyle(
              color: Color(0xFF2B2828), fontSize: 18.sp, fontFamily: "Poppins"),
        ),
      ),
    );
  }

  Widget buildTagButton(
      BuildContext context, String title, void Function() func,int position) {
    return GestureDetector(
      onTap: () {
        func();
        setState(() {
          selectedIndex = position;
        });
      },
      child: Container(
        height: 40.h,
        // width: MediaQuery.of(context).size.width * 0.3,
        margin: EdgeInsets.symmetric(horizontal: 4.w),
        padding: EdgeInsets.symmetric(horizontal: 15.w, vertical: 6.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(100.sp),
          color: selectedIndex == position?AppColors.BOTTOM_SHEET_BACKGROUND:AppColors.ACCOUNT_PAGE_BUTTON_BG_COLOR,
        ),
        child: Center(
          child: Text(title,
              style: TextStyle(
                  color: selectedIndex == position?AppColors.TITLE_TEXT_WHITE:AppColors.ON_BOARDING_BUTTON_COLOR, fontSize: 12.sp)),
        ),
      ),
    );
  }

  Widget myActivePlanDetails(int index) {
    return Card(
      color: Colors.white,
      elevation: 2,
      shadowColor: Colors.grey.withOpacity(0.2),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.sp),
        side: BorderSide(
          color: Colors.grey.withOpacity(0.4)
        )
      ),
      child: Container(
        margin: EdgeInsets.all(6),
        padding: EdgeInsets.only(left: 6.w,right: 6.w),
        width: double.maxFinite,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8.h),
                  child: Text("Expires on $formattedEndDateTime",style: TextStyle(fontSize: 12.sp,fontFamily: 'Poppins',fontWeight: FontWeight.normal,color:  AppColors.TITLE_TEXT_BLACK)),
                ),
                Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w,vertical: 6.h),
                decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(100.sp),
                color: AppColors.SLIDER_DOTTED_COLOR,
                ),
                child: Text("Plan ${controller.mySubscriptionListModel.value.result![0].subscription!.price}",style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.normal,color: Colors.white,fontFamily: 'Poppins')),
                ),
                /*Container(
                  margin: EdgeInsets.only(top: 16.h,bottom: 8.h),
                  child: Text("MRP ${controller.mySubscriptionListModel.value.result![0].subscription!.price}",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.w900,color: Colors.black)),
                ),*/
              ],
            ),
            Container(
                margin: EdgeInsets.only(top: 6.h),
                child: Text("EXPIRING IN $days DAYS",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.bold,color: Colors.black,fontFamily: 'Poppins'),)),
            /*Container(
              child: Divider(
                color: Colors.grey.withOpacity(0.3),
                height: 1.h,
              ),
            ),*/
            GestureDetector(
              onTap: () async{
                /*if(Platform.isAndroid){
                  if(await _requestPermission(Permission.storage)){
                    FileDownloader.downloadFile(
                        // url: "https://motivateyou-media.motivateuedutech.com/dev/invoice/INVOICE_UNEXPIRED_INV10000002_SUCCESS_1702205402266_15122023.pdf",
                        url: "https://s3.ap-south-1.amazonaws.com/motivateyou-invoice.motivateuedutech.com/dev/invoice/INVOICE_INV10000002_SUCCESS_1702277597805_15122023.pdf",
                        name: "Model_Notification",
                        downloadDestination: DownloadDestinations.appFiles,
                        notificationType: NotificationType.all,
                        onProgress: (fileName, progress) {
                          debugPrint("===Progress===$progress");
                        },
                        onDownloadCompleted: (path) {
                          //final File file = File(path);
                          //This will be the path of the downloaded file

                        });
                  }
                }else if(Platform.isIOS){
                  FileDownloader.downloadFile(
                      url: "https://motivateyou-media.motivateuedutech.com/dev/History/1696326582718_pexels-miguel-Ã¡-padriÃ±Ã¡n-255379-min.jpg",
                      name: "Model_Notification",
                      downloadDestination: DownloadDestinations.appFiles,
                      notificationType: NotificationType.all,
                      onProgress: (fileName, progress) {
                        debugPrint("===Progress===$progress");
                      },
                      onDownloadCompleted: (path) {
                        //final File file = File(path);
                        //This will be the path of the downloaded file

                      });
                }*/
                 controller.getSubscriptionInvoice(controller.mySubscriptionListModel.value.result![index].id);

                // Navigator.push(context, MaterialPageRoute(builder: (context) => InvoiceDownloadScreen(subscriptionID: '${controller.mySubscriptionListModel.value.result![index].id}'),));
              },
              child: Container(
                margin: EdgeInsets.only(right: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 12.h,bottom: 8.h),
                      child: Text("${controller.mySubscriptionListModel.value.result![0].subscription!.name} Subscription",style: TextStyle(fontSize: 12.sp,fontFamily: 'Poppins',fontWeight: FontWeight.normal,color: Colors.black)),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Invoice",style: TextStyle(fontSize: 10.sp,fontFamily: 'Poppins',fontWeight: FontWeight.normal,color: Colors.black)),
                        Container(
                          child: Center(
                            child: Icon(Icons.download),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget myOtherActivePlanDetails(int index,String status) {
    return Card(
      color: Colors.white,
      elevation: 2,
      shadowColor: Colors.grey.withOpacity(0.2),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.sp),
          side: BorderSide(
              color: Colors.grey.withOpacity(0.4)
          )
      ),
      child: Container(
        margin: EdgeInsets.all(6),
        padding: EdgeInsets.only(left: 6.w,right: 6.w),
        width: double.maxFinite,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 8.h),
                  child: Text("Expires on $formattedEndDateTime",style: TextStyle(fontSize: 12.sp,fontFamily: 'Poppins',fontWeight: FontWeight.normal,color:  AppColors.TITLE_TEXT_BLACK)),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12.w,vertical: 6.h),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100.sp),
                    color: AppColors.SLIDER_DOTTED_COLOR,
                  ),
                  child: Text("Plan ${controller.mySubscriptionListModel.value.result![0].subscription!.price}",style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.normal,color: Colors.white,fontFamily: 'Poppins')),
                ),
                /*Container(
                  margin: EdgeInsets.only(top: 16.h,bottom: 8.h),
                  child: Text("MRP ${controller.mySubscriptionListModel.value.result![0].subscription!.price}",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.w900,color: Colors.black)),
                ),*/
              ],
            ),
            Container(
                margin: EdgeInsets.only(top: 6.h),
                child: Text("ACTIVE ON ${formattedStartDateTime}",style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.bold,color: Colors.black,fontFamily: 'Poppins'),)),
            /*Container(
              child: Divider(
                color: Colors.grey.withOpacity(0.3),
                height: 1.h,
              ),
            ),*/
            GestureDetector(
              onTap: () {

              },
              child: Container(
                margin: EdgeInsets.only(right: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 12.h,bottom: 8.h),
                      child: Text("${controller.mySubscriptionListModel.value.result![0].subscription!.name} Subscription",style: TextStyle(fontSize: 12.sp,fontFamily: 'Poppins',fontWeight: FontWeight.normal,color: Colors.black)),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Invoice",style: TextStyle(fontSize: 10.sp,fontFamily: 'Poppins',fontWeight: FontWeight.normal,color: Colors.black)),
                        Container(
                          child: Center(
                            child: Icon(Icons.download),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
            /*Container(
              margin: EdgeInsets.only(top: 12.h,bottom: 8.h),
              child: Text("${controller.mySubscriptionListModel.value.result![0].subscription!.name} Subscription",style: TextStyle(fontSize: 12.sp,fontFamily: 'Poppins',fontWeight: FontWeight.normal,color: Colors.black)),
            ),*/
          ],
        ),
      ),
    );
  }

  Widget showAlertDialog(int index) {
    return AlertDialog(
      title: Text(
        "Are you sure you want to purchase this plan?",
        style: TextStyle(
            fontSize: 14.sp,
            color: Colors.grey,
            fontFamily: 'Poppins',
            fontWeight: FontWeight.normal),
      ),
      actions: <Widget>[
        TextButton(
          style: TextButton.styleFrom(
            textStyle: Theme.of(context).textTheme.labelLarge,
          ),
          child: Text('Cancel',
              style: TextStyle(
                fontSize: 14.sp,
                color: Colors.grey,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.normal,
              )),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          style: TextButton.styleFrom(
            textStyle: Theme.of(context).textTheme.labelLarge,
          ),
          child: Text('Purchase',
              style: TextStyle(
                  fontSize: 14.sp,
                  color: Colors.blue,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.normal)),
          onPressed: () {
            controller.subscribePlan(controller
                .subscriptionModel.value.result![index].id,controller.subscriptionModel.value.result![index].price,
                controller.subscriptionModel.value.result![index].totalPrice!,
                controller.subscriptionModel.value.result![index].calculatedSgst!,
                controller.subscriptionModel.value.result![index].calculatedCgst!,
                controller.subscriptionModel.value.result![index].hsnCodeDetails!.hsnCode!,
            );
            Navigator.of(context).pop();
            //Navigator.push(context, MaterialPageRoute(builder: (context) => PhonePePaymentGateway()));
             // Navigator.of(context).pop();
            // setState(() {});
          },
        ),
      ],
    );
  }

  Future<bool> _requestPermission(Permission permission) async {
    final deviceInfoPlugin = DeviceInfoPlugin();

    AndroidDeviceInfo build = await deviceInfoPlugin.androidInfo;
    debugPrint("build---->$build");

    if (build.version.sdkInt >= 30) {
      var re = await Permission.manageExternalStorage.request();
      if (re.isGranted) {
        return true;
      } else {
        return false;
      }
    } else {
      if (await permission.isGranted) {
        return true;
      } else {
        var result = await permission.request();
        if (result.isGranted) {
          return true;
        } else {
          return false;
        }
      }
    }
  }

}

//status