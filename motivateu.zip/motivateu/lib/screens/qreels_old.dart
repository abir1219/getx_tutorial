import 'dart:async';

import 'package:MotivateU/screens/reels_video.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/reels_controller_old.dart';
import '../widgets/qreels_widget.dart';
import 'mcq_reels_old.dart';

class QReelsOld extends StatefulWidget {
  const QReelsOld({Key? key}) : super(key: key);

  @override
  State<QReelsOld> createState() => _QReelsOldState();
}

class _QReelsOldState extends State<QReelsOld> {

  final PageController _pageController = PageController();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _startTimer() {
    // _timer = Timer.periodic(Duration(seconds: 10), (timer) {
    //   if (_currentPage < Get.find<ReelsController>().reels.length - 1) {
    //     _currentPage++;
    //   } else {
    //     _currentPage = 0;
    //   }
    //   _pageController.animateToPage(
    //     _currentPage,
    //     duration: Duration(milliseconds: 300),
    //     curve: Curves.easeInOut,
    //   );
    // });
  }


  @override
  Widget build(BuildContext context) {

    ReelsControllerOld controller= Get.put(ReelsControllerOld());
    controller.loadReels();

    return SafeArea(
        child: Scaffold(
          body: Stack(
            children: [
              Obx(() => PageView.builder(
                scrollDirection: Axis.vertical,
                controller: _pageController,
                onPageChanged: (index) {
                  setState(() {
                  });
                },
                itemCount: controller.reels.length,
                itemBuilder: (context, index) {
                  if(controller.reels[index].reelsType=="descriptive") {
                    debugPrint("TYPE=======>Descriptive");
                    return ReelsVideo(index: index);
                  }else if(controller.reels[index].reelsType=="short"){
                    debugPrint("TYPE=======>Others");
                    return CarouselSlider(
                      items: controller.reels[index].reelUrls!.map((url) {
                        return Builder(
                          builder: (BuildContext context) {
                            return Container(
                              width: double.infinity,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: NetworkImage(url),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            );
                          },
                        );
                      }).toList(),
                      options: CarouselOptions(
                        initialPage: 0,
                        viewportFraction: 1,
                        height: double.infinity, // Full-screen height
                        //initialPage: 0,
                        enableInfiniteScroll: true,
                      ),
                    );
                  }else if(controller.reels[index].reelsType=="mcq"){
                    return McqReelsOld(quizController: controller,index: index);
                  }
                  return null;
                },
              )),
              Positioned(
                left: 0,
                bottom: 0,
                child: footerTag(),
              ),
              // Positioned(
              //     right: 0,
              //     bottom: 0,
              //     child: interactiveIcons(reelsId: '',context: context)),
            ],
          ),
          /*bottomNavigationBar: BottomNavigationBar(
            backgroundColor: AppColors.BOTTOM_NAVIGATION_BAR_COLOR,
            showSelectedLabels: false,
            showUnselectedLabels: false,
            items: bottomTabs,
            onTap: (value) => Get.find<DashboardController>().pageIndex.value = value,
            currentIndex: Get.find<DashboardController>().pageIndex.value,
          ),*/
        ));
  }
}
