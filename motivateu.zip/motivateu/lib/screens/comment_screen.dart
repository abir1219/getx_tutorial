import 'package:MotivateU/models/reels_model.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../controllers/comment_controller.dart';
import '../res/app_colors.dart';
import '../widgets/comments_list_widget.dart';

class CommentScreen extends StatefulWidget {
  final String questionId;
  final Result result;
  const CommentScreen({super.key, required this.questionId, required this.result});

  @override
  State<CommentScreen> createState() => _CommentScreenState();
}

class _CommentScreenState extends State<CommentScreen> {
  var controller = Get.isRegistered<CommentController>()?Get.find<CommentController>():Get.put(CommentController());


  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
          builder: (BuildContext context, ScrollController scrollController) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            // shrinkWrap: true,
            // controller: scrollController,
            children: [
              Container(
                margin: EdgeInsets.only(bottom: 12,top: 10.h),
                height: 3.h,
                width: MediaQuery.of(context).size.width/6,
                color: Colors.black.withOpacity(0.5),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 10,top: 12.h),
                child: Center(child: Text("Comments",style: TextStyle(fontSize: 16.sp,color: Colors.grey,fontWeight: FontWeight.bold,fontFamily: "Alata"),)),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 6),
                height: .5,
                color: Colors.black.withOpacity(0.3),
              ),
              CommentsListWidget(scrollController: scrollController,questionId:widget.questionId, result: widget.result,), // scrollController: scrollController
              Divider(), // Add a divider for separation
              Container(
                padding: EdgeInsets.symmetric(vertical: 10),
                color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,//TITLE_TEXT_WHITE
                child: Row(
                  children: [
                    Expanded(
                      // fit: FlexFit.loose,
                      child: Container(
                        margin: EdgeInsets.symmetric(horizontal: 15),
                        padding: EdgeInsets.only(left: 10),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: TextField(
                          controller: controller.commentController.value,
                          maxLines: null,
                          decoration: InputDecoration(
                            hintText: "Write a comment...",
                            hintStyle: TextStyle(
                              color: AppColors.FIELD_BORDER_COLOR,
                              fontFamily: 'Poppins',
                              fontSize: 14,
                            ),
                            border: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            enabledBorder: InputBorder.none,
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        debugPrint("--------send-----------");
                        // Add logic to send the comment
                        if(controller.commentController.value.text.isNotEmpty){
                          controller.postComment(widget.questionId, controller.commentController.value.text.toString());
                        }else{
                          Utils.showToastMessage("Write a comment...");
                        }
                      },
                      child: Container(
                        height: 45,
                        margin: EdgeInsets.only(right: 8),
                        child: Center(
                          child: Icon(
                            Icons.send,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          );
          }
      ),
    );
  }
}
