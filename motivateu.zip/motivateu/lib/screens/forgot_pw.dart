import 'package:MotivateU/controllers/forgetPw_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../utils/utils.dart';
import '../widgets/custom_button.dart';
import '../widgets/reusable_sign_in_widgets.dart';

class ForgotPW extends StatelessWidget {
  const ForgotPW({super.key});

  @override
  Widget build(BuildContext context) {

    var controller = Get.find<ForgetPwController>();

    void validateForm() {
      if(controller.newPwController.value.text.toString().isEmpty){
        Utils.showToastMessage("Enter New Password");
      }else if(controller.retypePwController.value.text.toString().isEmpty){
        Utils.showToastMessage("Retype Password");
      }else if(controller.newPwController.value.text.toString() != controller.retypePwController.value.text.toString()){
        Utils.showToastMessage("Password Mismatch");
      }
      {
        controller.updatePw();
      }
    }

    return SafeArea(
        child: Scaffold(
      body: Container(
        height: double.maxFinite,
        decoration: BoxDecoration(
            // color: Colors.red,
            image: DecorationImage(
                image: AssetImage("assets/icons/login_bg.jpg"),
                fit: BoxFit.cover)),
        child: NotificationListener<OverscrollIndicatorNotification>(
          onNotification: (OverscrollIndicatorNotification notification) {
            notification.disallowIndicator();
            return true;
          },
          child: Center(
            child: SingleChildScrollView(
              child: Obx(() =>  Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    reusableTitleText("Welcome to MotivateU"),
                    reusableSubTitleText("Please change your password and continue our app"),
                    reusableFieldText("New Password"),
                    // reusableField(
                    //   context,
                    //   "Your new password",
                    //   controller.newPwController.value,
                    //   null,
                    //   null,
                    //   'password'
                    // ),
                    reusablePasswordField("Your new password", controller.newPwController.value,controller.isPasswordVisible.value,() {
                      controller.isPasswordVisible.value = !controller.isPasswordVisible.value;
                    },"password",),
                    reusableFieldText("Re-type Password"),
                    // reusableField(
                    //   context,
                    //   "Retype your password",
                    //   controller.retypePwController.value,
                    //   null,
                    //   null,
                    //     'password'
                    // ),
                    reusablePasswordField("Re-type Password", controller.retypePwController.value,controller.isCnfrmPasswordVisible.value,() {
                      controller.isCnfrmPasswordVisible.value = !controller.isCnfrmPasswordVisible.value;
                    },"password",),
                    Obx(() => Center(
                        child: CustomButton(
                          buttonName: "UPDATE PASSWORD",
                          callback: () => validateForm(),
                          loading: controller.isLoading.value,
                        ),
                      ),
                    )
                  ],
                ),
              ),
            )
          ),
        ),
      ),
    ));
  }
}
