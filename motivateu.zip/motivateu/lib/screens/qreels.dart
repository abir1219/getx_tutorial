import 'package:MotivateU/controllers/reels_controller.dart';
import 'package:MotivateU/main.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/screens/no_data_found.dart';
import 'package:MotivateU/screens/short_reels.dart';
import 'package:MotivateU/screens/table_match.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import 'descriptive_with_bg.dart';
import 'descriptive_without_bg.dart';
import 'free_time_over_alert_dialog.dart';
import 'mcq_reels.dart';

class QReels extends StatefulWidget {
  final String type;
  final String scenarioId;
  final String questionId;

  const QReels(
      {super.key,
      required this.type,
      this.scenarioId = "",
      this.questionId = ""});

  @override
  State<QReels> createState() => _QReelsState();
}

class _QReelsState extends State<QReels> {
  var controller = Get.isRegistered<ReelsController>()
      ? Get.find<ReelsController>()
      : Get.put(ReelsController());
  final PageController _pageController = PageController(initialPage: 0);
  DateTime? currentBackPressTime;
  int indexCount = 1;
  int indexDirection = 0;
  String? questionId = "";
  int pageNo = 1;

  @override
  void dispose() {
    super.dispose();
    debugPrint("QREELS_DISPOSE");
    if (!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!) {
      // controller.stopTimerTrack(questionId);
      controller.stopTimerTrack();
    }
    //if (widget.questionId != "") {
    controller.startTimer();
    controller.saveReelsForSeen();
    //}
    //_pageController.removeListener(_onPageChanged);
    _pageController.dispose();
    controller.index.value = -1;
  }

  void _onPageChanged() {
    // Handle page change, you can trigger actions here
    //print("Page changed to ${_pageController.page?.round()}");
  }

  @override
  void initState() {
    super.initState();

    // _pageController.addListener(_onPageChanged);
    /*if(ManageTimeTracker.haveTime)
      ManageTimeTracker.startTimer();
    else*/
    /*if (widget.questionId == "") {
      //Utils.showToastMessage("hiiii");
      controller.getReels(1, widget.scenarioId);
    } else {
      // Utils.showToastMessage("helllo=>${widget.questionId}");
      controller.questionId.value = widget.questionId;
      controller.reelsById(widget.questionId);
    }*/

    //_pageController.addListener(_scrollListener);
    //controller.isLoading.value== false ? _startTimer() : null;
    //_startTimer();
  }


  @override
  Widget build(BuildContext context) {

    /*if(controller.timerTrack != null && controller.timerTrack!.isActive){
      controller.stopTimerTrack();
    }*/
    debugPrint("SUBSCRIBE===>${SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)}");
    if (!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!){
      if(SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! > 0){
        controller.startTimer();
        controller.startTimerTrack();
        if (widget.questionId == "") {
          //Utils.showToastMessage("hiiii");
          controller.getReels(1, widget.scenarioId);
        } else {
          // Utils.showToastMessage("helllo=>${widget.questionId}");
          controller.questionId.value = widget.questionId;
          controller.reelsById(widget.questionId);
        }
      }else {
        controller.haveTime.value = false;
        debugPrint("noooooooooooooo");
      }
    }else{
      controller.startTimer();
      //controller.startTimerTrack();
      if (widget.questionId == "") {
        //Utils.showToastMessage("hiiii");
        controller.getReels(1, widget.scenarioId);
      } else {
        // Utils.showToastMessage("helllo=>${widget.questionId}");
        controller.questionId.value = widget.questionId;
        controller.reelsById(widget.questionId);
      }
    }

    return SafeArea(
        child: WillPopScope(
      onWillPop: () async {
        debugPrint("<<<<<<<<<widget.type>>>>>>>>>${widget.type}");
        if (widget.type == 'reels') {
          DateTime now = DateTime.now();
          if (currentBackPressTime == null ||
              now.difference(currentBackPressTime!) > Duration(seconds: 2)) {
            currentBackPressTime = now;
            Utils.showToastMessage("Press back again to exit");
            return false;
          }
          SystemNavigator.pop();
          return true;
        } else if (widget.type == 'scenario') {
          //Navigator.push(context, MaterialPageRoute(builder: (context) => QReels(type: 'scenario',),));
          //Get.back();
          // Get.offNamed(AppRoutes.dashboard, arguments: [1]);
          Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'1'});
        }else if (widget.type == 'post') {
          //Navigator.push(context, MaterialPageRoute(builder: (context) => QReels(type: 'scenario',),));
          //Get.back();
          // Get.offNamed(AppRoutes.dashboard, arguments: [1]);
          Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'3'});
        }
        return false;
      },
      child: Scaffold(
        body: Stack(
          children: [
            Obx(() {
              // questionId = controller.reelsData.value.result != null && controller.reelsData.value.result!.length > 0 ? controller.reelsData.value.result![0].sId! : null;
              controller.questionId.value =
                  // controller.reelsData.value.result != null &&
                  // controller.reelsList!= null &&
                          controller.reelsList!.length > 0
                      ? controller.reelsList![0].sId!
                      : "null";

              //debugPrint("_pageController.page?.round()====${_pageController.page?.round()}");

              if(controller.index.value == -1){
                if(controller.reelsList!.length > 0){
                  debugPrint("<===questionIdBEFORE===>${controller.questionId.value}");
                  socket.emit('reel-action',controller.questionId.value);
                }
              }
              //
              //

              debugPrint('...HAVE TIME... ${controller.haveTime.value}');

              return controller.haveTime.value
                  ? controller.isLoading.value
                      ? Center(
                          child: CircularProgressIndicator(
                            color: Colors.black,
                          ),
                        )
                      : NotificationListener<OverscrollIndicatorNotification>(
                          onNotification:
                              (OverscrollIndicatorNotification notification) {
                            notification.disallowIndicator();
                            debugPrint("LENGTH->${controller.reelsList!.length}");
                            return true;
                          },
                          // child: controller.reelsData.value.result!.length > 0 //changed
                          child: controller.reelsList!.length > 0
                              ? Column(
                                children: [
                                  Expanded(
                                    child: PageView.builder(
                                        scrollDirection: Axis.vertical,
                                        //controller: _pageController,
                                        onPageChanged: (index) {

                                          controller.index.value = index;
                                          // debugPrint("_pageController.page===>${_pageController.page}");
                                          // debugPrint("_pageController.page=>${_pageController.page?.toInt()}");
                                          // debugPrint("_pageController.position=>${_pageController.position}");

                                          // questionId = controller.reelsData.value.result![index].sId!;//changed
                                          questionId =
                                              controller.reelsList![index].sId!;
                                          socket.emit('reel-action',questionId);


                                          controller.startTimer();
                                          // controller.questionId.value = controller.reelsData.value.result![index].sId!; //changed
                                          controller.questionId.value =
                                              controller.reelsList![index].sId!;
                                          controller.saveReelsForSeen();

                                          debugPrint("<===questionId===>${questionId}");

                                          // debugPrint("_pageController.page=>${_pageController.page?.toInt()}");
                                          // debugPrint("__pageController.page!.round()=>${_pageController.page!.round()}");
                                          // debugPrint("_pageController.position=>${_pageController.position}");
                                          debugPrint("_pageController.index=>${index}");
                                          debugPrint("controller.reelsList!.length-1=>${controller.reelsList!.length-1}");
                                          debugPrint("controller.reelsList!.length-2=>${controller.reelsList!.length-2}");
                                          //debugPrint("controller.reelsData.value.pagination!.totalRecord=>${controller.reelsData.value.pagination!.totalRecord}");
                                          debugPrint("BEFORE->index(${index}) equals ${controller.reelsList!.length-2}");

                                          if(index == controller.reelsList!.length-2){
                                            debugPrint("AFTER->index(${index}) equals ${controller.reelsList!.length-2}");
                                            controller.getMoreReels(pageNo,widget.scenarioId);
                                          }


                                          // else{
                                          //   debugPrint("index(${index}) not equals ${controller.reelsList!.length-2}");
                                          // }

                                          /*if(controller.reelsData.value.pagination!.totalRecord !=
                                              controller.reelsList!.length){
                                            if (index == controller.reelsList!.length - 2
                                            // && controller.reelsData.value.pagination!.totalRecord != controller.reelsList!.length
                                            ) {
                                              setState(() {
                                                pageNo++;
                                              });
                                              debugPrint("----PAGE_NO_IF----$pageNo");
                                              controller.getMoreReels(pageNo,widget.scenarioId);
                                              // _loadMoreData(); // Assuming this method is defined somewhere.
                                            }
                                          }else{
                                            debugPrint("----PAGE_NO_ELSE----$pageNo");
                                          }*/


                                          // if (_pageController.page! == controller.reelsList!.length - 1) {
                                          //   _pageController.jumpToPage((_pageController.page!.toInt() + 1) % controller.reelsList!.length);
                                          // }

                                          // if (index == _pageController.page!.toInt() && index == _pageController.page!.round()) {
                                          //   // User reached the last page, go to the first page
                                          //   debugPrint("!!!!!!!!!!!!GOTO FIRST!!!!!!!!!!!");
                                          //   _pageController.jumpToPage(0);
                                          // }

                                        },
                                        // itemCount: controller.reelsData.value.result!.length, // changed
                                        itemCount: controller.reelsList!.length,
                                        itemBuilder: (context, index) {
                                          debugPrint(
                                              "REELS_TYPE=>---${controller.reelsList!.length}---");
                                          debugPrint(
                                              "REELS_TYPE=>---${controller.reelsList!.length}---" +
                                                  controller.reelsList![index].type
                                                      .toString());
                                          // if (controller.reelsData.value.result![index].type == "Descriptive") { //changed
                                          if (controller.reelsList![index].type ==
                                              "Descriptive") {
                                            // if (controller.reelsData.value.result![index].questions![0].quest!.questionBackground != "") {
                                            if (controller
                                                    .reelsList![index]
                                                    .questions![0]
                                                    .quest!
                                                    .questionBackground !=
                                                "") {
                                              return DescriptiveWithBg(index: index);
                                            } else {
                                              return DescriptiveWithoutBg(
                                                  index: index);
                                            }
                                            // } else if (controller.reelsData.value.result![index].type =="MCQ2" ||controller.reelsData.value.result![index].type == "MCQ4" || controller.reelsData.value.result![index].type == "TrueFalse" ||controller.reelsData.value.result![index].type == "FillInTheBlanks") { // changed
                                          } else if (controller
                                                      .reelsList![index].type ==
                                                  "MCQ2" ||
                                              controller.reelsList![index].type ==
                                                  "MCQ4" ||
                                              controller.reelsList![index].type ==
                                                  "TrueFalse" ||
                                              controller.reelsList![index].type ==
                                                  "FillInTheBlanks") {
                                            return McqReels(
                                                index: index, type: widget.type);
                                            // } else if (controller.reelsData.value.result![index].type == "Short") { //Changed
                                          } else if (controller
                                                  .reelsList![index].type ==
                                              "Short") {
                                            return ShortReels(index: index);
                                            // } else if (controller.reelsData.value.result![index].type == "TableMatch") {
                                          } else if (controller
                                                  .reelsList![index].type ==
                                              "TableMatch") {
                                            return TableMatch(index: index);
                                          }
                                          return null;
                                        },
                                      ),
                                  ),
                                  controller.isMoreLoading.value
                                      ? Container(
                                    width: double.maxFinite,
                                    color: Colors.white,
                                    margin: EdgeInsets.symmetric(vertical: 10.h),
                                    child: Center(
                                      child: SizedBox(
                                        height: 24.h,
                                        width: 24.w,
                                        child: CircularProgressIndicator(
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                  )
                                      : Container()
                                ],
                              )
                              : NoDataFound(
                                  type: widget.type,
                                  scenarioId: widget.scenarioId),
                        )
                  : Center(
                    child: FreeTimeOverAlertDialog()
                  );
            }),
          ],
        ),
      ),
    ));
  }
}
