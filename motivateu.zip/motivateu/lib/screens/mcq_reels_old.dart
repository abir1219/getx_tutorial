import 'package:MotivateU/controllers/reels_controller_old.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../helper/api_end_points.dart';

class McqReelsOld extends StatefulWidget {
  final quizController;
  final index;

  const McqReelsOld({Key? key, required this.quizController, required this.index})
      : super(key: key);

  @override
  State<McqReelsOld> createState() => _McqReelsOldState();
}

class _McqReelsOldState extends State<McqReelsOld> {
  // bool isClicked = false;

  @override
  Widget build(BuildContext context) {
    final question = widget.quizController.reels[widget.index];
    debugPrint("question-->${question.reelsQuestion}");
    // debugPrint("question-->${question.reelUrls[0]}");
    // debugPrint("question-->${question.reelUrls.length}");

    return Scaffold(
      backgroundColor: question.reelUrls.length < 1
          ? AppColors.BOTTOM_SHEET_BACKGROUND.withOpacity(0.85)
          : Colors.transparent,
      body: Container(
        padding: EdgeInsets.only(left: 8.w, right: 8.w),
        decoration: BoxDecoration(
            image: question.reelUrls.length > 0
                ? DecorationImage(
                    image: NetworkImage(ApiEndPoints.IMAGE_URL+"${question.reelUrls[0]}"),
                    fit: BoxFit.cover,
                  )
                : null),
        // width: 310.w,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.only(right: 50),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.5)
              ),
              child: Text(
                question.reelsQuestion,
                // textAlign: TextAlign.center,
                style:
                    TextStyle(fontSize: 20.sp, color: AppColors.TITLE_TEXT_WHITE),
              ),
            ),
            const SizedBox(height: 20),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                return optionBuilder(
                    option: question.reelOptions[index],
                    correctIndex: question.correctAnswer,
                    currentIndex: index,
                    questionIndex: widget.index);
              },
              itemCount: question.reelOptions.length,
            )
          ],
        ),
      ),
    );
  }

  Widget optionBuilder(
      {required String option,
      required int questionIndex,
      required int correctIndex,
      required int currentIndex}) {
    return Obx(
      () {
        return GestureDetector(
          onTap: () {
            if (!Get.find<ReelsControllerOld>().isSelect.value) {
              debugPrint("${Get.find<ReelsControllerOld>().isSelect.value}");
              Get.find<ReelsControllerOld>().setCorrectAnswer(
                  Get.find<ReelsControllerOld>()
                      .reels[widget.index]
                      .correctAnswer!);
              // Get.find<ReelsController>().checkAnswer(currentQuestionIndex: widget.index, selectedOptionIndex: currentIndex); // Replace with actual index
              Get.find<ReelsControllerOld>().setSelectedAnswer(currentIndex);
              Get.find<ReelsControllerOld>().isSelect.value = true;
            } else {
              debugPrint("${Get.find<ReelsControllerOld>().isSelect.value}");
              null;
            }
          },
          child: Container(
            height: 55.h,
            width: 20.w,
            margin: EdgeInsets.only(top: 35.w, left: 12.w, right: 50.w),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(35.w),
                color: Get.find<ReelsControllerOld>().correctAnswerIndex.value ==
                        currentIndex
                    ? AppColors.MCQ_CORRECT_QUESTION_BG_COLOR
                    : Get.find<ReelsControllerOld>().selectedAnswerIndex.value ==
                            currentIndex
                        ? AppColors.MCQ_WRONG_QUESTION_BG_COLOR
                        : Colors.white),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: 40.h,
                  width: 40.w,
                  margin: EdgeInsets.all(4.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(200),
                    color: AppColors.BOTTOM_SHEET_BACKGROUND,
                  ),
                  child: Center(
                    child: Text(
                      "${currentIndex + 1}",
                      style: TextStyle(
                          fontFamily: "Poppins",
                          fontSize: 20.sp,
                          color: Colors.white),
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                      margin: EdgeInsets.only(left: 12.w),
                      child: Text(
                        option,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            fontFamily: "Poppins",
                            fontSize: 16.sp,
                            color: Colors.black),
                      )),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
