import 'package:MotivateU/controllers/reels_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';

import '../controllers/hots_controller.dart';
import '../res/app_colors.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';
import '../utils/utils.dart';
import '../widgets/hots_subject_widget.dart';

class HotsPattern extends StatefulWidget {
  const HotsPattern({super.key});

  @override
  State<HotsPattern> createState() => _HotsPatternState();
}

class _HotsPatternState extends State<HotsPattern> {
  var controller = Get.isRegistered<HotsController>()
      ? Get.find<HotsController>()
      : Get.put(HotsController());


  //var timeTrackController = Get.isRegistered<ReelsController>()?Get.find<ReelsController>():Get.put(ReelsController());

  @override
  void initState() {
    super.initState();
    clearHive();
    // controller.getHotsList();
  }


  @override
  void dispose() {
    super.dispose();
    debugPrint("Hots Pattern dispose");
    // controller.dispose();
    if(!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!){
      controller.stopTimerTrack();
    }

  }

  Future<void> clearHive() async {
    var box = await Hive.openBox('motivate_u_mcq');
    box.clear();
  }

  DateTime? currentBackPressTime;

  @override
  Widget build(BuildContext context) {

    /*if(timeTrackController.timerTrack != null && timeTrackController.timerTrack!.isActive){
      timeTrackController.stopTimerTrack();
    }*/

    // if (!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)! &&
    //     SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! > 0) {
    //   controller.startTimerTrack();
    // } else {
    //   //debugPrint("noooooooooooooo");
    // }

    if (!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!){
      if(SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! > 0){
        // controller.startTimer();
        controller.startTimerTrack();
        controller.getHotsList();
      }else {
        controller.haveTime.value = false;
        debugPrint("noooooooooooooo");
      }
    }else{
      //controller.startTimerTrack();
      controller.getHotsList();
    }

    return SafeArea(
      child: WillPopScope(
        onWillPop: () async {
          DateTime now = DateTime.now();
          if (currentBackPressTime == null ||
              now.difference(currentBackPressTime!) > Duration(seconds: 2)) {
            currentBackPressTime = now;
            Utils.showToastMessage("Press back again to exit");
            return false;
          }
          SystemNavigator.pop();
          return true;
        },
        child: Scaffold(
          appBar: AppBar(
            elevation: 0,
            backgroundColor: AppColors.BOTTOM_SHEET_BACKGROUND,
            title: Text(
              'Higher Order Thinking Skills (HOTS)',
              style: TextStyle(
                fontSize: 16.sp,
              ),
            ),
            centerTitle: true,
          ),
          body: Obx(() =>
          controller.haveTime.value?
          controller.isLoading.value?
              Container(
                width: double.maxFinite,
                height: double.maxFinite,
                child: Center(
                  child: SizedBox(
                    height: 24.h,
                    width: 24.w,
                    child: CircularProgressIndicator(color: Colors.black,),
                  ),
                ),
              )
              :controller.hotsModel.value.result!.length>0?Container(
              color: AppColors.TITLE_TEXT_WHITE,
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.only(top: 12.h),
              child: NotificationListener<OverscrollIndicatorNotification>(
                onNotification: (OverscrollIndicatorNotification notification) {
                  notification.disallowIndicator();
                  return true;
                },
                child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                    ),
                    itemBuilder: (context, index) => HotsSubjectWidget(
                          subjectName: controller.hotsModel.value.result![index].subject!,
                          subjectCount: controller.hotsModel.value.result![index].passageCount!, subjectId: controller.hotsModel.value.result![index].subjectId!,
                        ),
                    itemCount: controller.hotsModel.value.result!.length),
              ),
            ):
              Container(
                width: double.maxFinite,
                height: double.maxFinite,
                child: Center(
                  child: Text("No Hots Found",style: TextStyle(fontSize: 14.sp,color: Colors.black,fontFamily: 'Alata'),)
                ),
              )
              :Container(
            child: Center(child: Text("No free minutes available for the day")),
          )
          ),
        ),
      ),
    );
  }
}
