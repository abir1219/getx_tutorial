import 'package:flutter/material.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:get/get.dart';
import 'package:video_player/video_player.dart';

import '../controllers/reels_controller_old.dart';

class ReelsVideo extends StatefulWidget {
  final index;
  const ReelsVideo({super.key,required this.index});

  @override
  State<ReelsVideo> createState() => _ReelsVideoState();
}

class _ReelsVideoState extends State<ReelsVideo> {
  late VideoPlayerController? _videoPlayerController;

  @override
  void initState() {
    super.initState();
    _videoPlayerController = null;
    _initialization();
  }

  void _initialization() async {
    debugPrint("=======Index====== : ${widget.index}");

    final fileInfo =
    await checkCacheFor(Get.find<ReelsControllerOld>().reels[widget.index].reelUrls![0]);
    if (fileInfo == null) {
      _videoPlayerController = VideoPlayerController.networkUrl(
          Uri.parse(Get.find<ReelsControllerOld>().reels[widget.index].reelUrls![0]));

      await _videoPlayerController!.initialize().then((value) {
        cachedForUrl(Get.find<ReelsControllerOld>().reels[widget.index].reelUrls![0]);
        _videoPlayerController!.play();
        _videoPlayerController!.setLooping(true);
        _videoPlayerController!.setVolume(1);
        setState(() {});
      });
    } else {
      final file = fileInfo.file;
      debugPrint("File Info: ${fileInfo.file.basename}");
      _videoPlayerController = VideoPlayerController.file(file);
      await _videoPlayerController!.initialize().then((value) {
        _videoPlayerController!.play();
        _videoPlayerController!.setLooping(true);
        _videoPlayerController!.setVolume(1);
        setState(() {});
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
    _videoPlayerController!.dispose();
    // _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return (_videoPlayerController != null &&
        _videoPlayerController!.value.isInitialized)
        ? VideoPlayer(_videoPlayerController!)
    /*Swiper(
      itemCount: widget.videos.length,
      scrollDirection: Axis.vertical,
      onIndexChanged: (index) => _controller.index.value = index,
        itemBuilder: (context, index) => VideoPlayer(_videoPlayerController!),
    )*/
        : const Center(
      child: CircularProgressIndicator(
        color: Colors.white,
        backgroundColor: Colors.black,
      ),
    );
  }


  Future<FileInfo?> checkCacheFor(String? url) async {
    final FileInfo? value = await DefaultCacheManager().getFileFromCache(url!);
    return value;
  }

//:cached Url Data
  void cachedForUrl(String? url) async {
    await DefaultCacheManager().getSingleFile(url!).then((value) {
      print('downloaded successfully done for $url');
    });
  }
}
