import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get_rx/src/rx_typedefs/rx_typedefs.dart';

import '../widgets/custom_button.dart';


class AlertMessageScreen extends StatelessWidget {
  final Callback callback;
  const AlertMessageScreen({super.key, required this.callback});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          height: double.maxFinite,
          width: double.maxFinite,
          color: Colors.white,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 80.h,
                width: 80.w,
                child: Icon(Icons.error_outline,size: 100.sp,color: Colors.grey,),
              ),
              Gap(20.h),
              Text("Something went wrong",style: TextStyle(fontSize: 20.sp,color: Colors.grey,fontFamily: 'Alata'),),
              CustomButton(buttonName:'Refresh', callback: () {
                callback();
              },)
            ],
          ),
        ),
      ),
    );
  }
}


