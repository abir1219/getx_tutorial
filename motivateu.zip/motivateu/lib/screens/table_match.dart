import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:get/get.dart';

import '../controllers/reels_controller.dart';
import '../helper/api_end_points.dart';
import '../main.dart';
import '../res/app_colors.dart';
import '../widgets/qreels_widget.dart';

class TableMatch extends StatefulWidget {
  final int index;

  const TableMatch({super.key, required this.index});

  @override
  State<TableMatch> createState() => _TableMatchState();
}

class _TableMatchState extends State<TableMatch> {
  int currentIndex = 0;
  dynamic socketData;

  var result;

  @override
    void initState() {
    super.initState();
    /*if(socket.connected){
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        socketData = data['data'];
      });
    }*/

  }

  @override
  void dispose() {
    super.dispose();
    debugPrint("<<<<<Table_DISPOSE>>>>>");
  }

  @override
  Widget build(BuildContext context) {

    result =
    Get.find<ReelsController>().reelsList![widget.index];
    if(socket.connected){
      debugPrint("<<<<<Table_DATA>>>>> ${result.sId}");
      //socket.emit('reel-action',result.sId);
      //socket.on('reel-action', (data) => debugPrint("<<<<<DATA>>>>> $data"));
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        /*setState(() {
              socketData = data['data'];
            });*/
        // Get.find<ReelsController>().socketData = data['data'];
        Get.find<ReelsController>().socketData.assignAll(data['data']);
        debugPrint("<<<<<socketData Table>>>>> ${socketData}");


      });
    }

    debugPrint("<<<<<Table_build>>>>>");

    return Scaffold(
      //backgroundColor:
          // result.questions![0].quest!.questionBackground == "" || result.questions![0].quest!.questionBackground == null
          //     ? AppColors.BOTTOM_SHEET_BACKGROUND.withOpacity(0.85) :
         //Colors.transparent,
      body: Container(
        decoration: BoxDecoration(
          /*gradient: result.questions![0].quest!.questionBackground =="" || result.questions![0].quest!.questionBackground ==null?LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.purple, Colors.orange]):null),*/
          // colors: [Color.fromRGBO(200,200,200,75), Color.fromRGBO(137,115,153,100)]):null),
          /*color: result.questions![0].quest!.questionBackground == ""
            ? Colors.white
            : null,*/
            color: result.questions![0].quest!.questionBackground == "" ||
                result.questions![0].quest!.questionBackground == null
                ? Colors.transparent
                : Colors.black,//Colors.black.withOpacity(0.3),
            image: result.questions![0].quest!.questionBackground == ""?DecorationImage(
              image: //NetworkImage("https://wallpapers.com/images/featured/hd-a5u9zq0a0ymy2dug.jpg",),
              NetworkImage('${ApiEndPoints.IMAGE_URL}${result.questions![0].quest!.questionBackground}'),
              fit: BoxFit.cover,
            ):null
        ),
        child: Container(
          width: double.maxFinite,
          height: double.maxFinite,
          color: Colors.black.withOpacity(0.3),
          padding: EdgeInsets.only(left: 12.w,right: 12.w, top: 10.h,bottom: 10.h),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  CarouselSlider(
                    items: [
                      Container(
                        width: double.maxFinite,
                        //margin: EdgeInsets.symmetric(horizontal: 2.w),
                        margin: EdgeInsets.only(left: 2.w,right: 55.w),
                        child: SingleChildScrollView(
                          scrollDirection: Axis.vertical,
                          child: DataTable(
                            border: TableBorder.all(
                                color: //result.questions![0].quest!.questionBackground == "" ||
                                        //result.questions![0].quest!.questionBackground == null ?
                                Colors.white,
                                    // : Colors.black,
                                width: 0.8),
                            // columnSpacing: 0,
                            columns: [
                              DataColumn(
                                label: Expanded(
                                    child: Text(
                                  'Question',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: //result.questions![0].quest!.questionBackground == ""
                                          // ||result.questions![0].quest!.questionBackground == null?
                                      Colors.white,
                                      // :Colors.black,
                                      // Colors.black : Colors.white,
                                      fontFamily: "Alata",
                                      fontSize: 16.sp),
                                )),
                              ),
                              DataColumn(
                                  label: Expanded(
                                      child: Text('Option',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: //result.questions![0].quest!.questionBackground =="" ||
                                                      //result.questions![0].quest!.questionBackground ==null ?
                                              Colors.white,//:Colors.black,
                                              // Colors.black: Colors.white,
                                              fontFamily: "Alata",
                                              fontSize: 16.sp)))),
                            ],
                            rows: List<DataRow>.generate(
                              Get.find<ReelsController>().reelsList![widget.index]
                                  .questions!
                                  .length,
                              (i) {
                                //final rowData = tableData[index];
                                return DataRow(
                                  cells: [
                                    DataCell(TeXView(
                                      child: TeXViewDocument(
                                          Get.find<ReelsController>()
                                              .reelsList![widget.index]
                                              .questions![i]
                                              .option![0],
                                          style: /*result.questions![0].quest!
                                                          .questionBackground ==
                                                      "" ||
                                                  result.questions![0].quest!
                                                          .questionBackground ==
                                                      null
                                              ? TeXViewStyle.fromCSS(
                                                  'font-size: 14px; font-weight: bold; color: black;text-align:center;font-family:"Alata"',
                                                ) :*/
                                          TeXViewStyle.fromCSS(
                                                  'font-size: 14px; font-weight: bold; color: white;text-align:center;font-family:"Alata"',
                                                )),
                                    )),
                                    //Text("${Get.find<ReelsController>().reelsData.value.result![index].questions![i].quest!.questionValue}",style: TextStyle(color: Colors.white,fontFamily: "Alata",fontSize: 14.sp)))),
                                    DataCell(
                                      TeXView(
                                        child: TeXViewDocument(
                                            Get.find<ReelsController>()
                                                .reelsList![widget.index]
                                                .questions![i]
                                                .option![0],
                                            style: /*result.questions![0].quest!
                                                            .questionBackground ==
                                                        "" ||
                                                    result.questions![0].quest!
                                                            .questionBackground ==
                                                        null
                                                ? TeXViewStyle.fromCSS(
                                                    'font-size: 14px; font-weight: bold; color: black;text-align:center;font-family:"Alata"',
                                                  ):*/
                                            TeXViewStyle.fromCSS(
                                                    'font-size: 14px; font-weight: bold; color: white;text-align:center;font-family:"Alata"',
                                                  )),
                                      ),
                                      //Text("${Get.find<ReelsController>().reelsData.value.result![index].questions![i].option![0]}",style: TextStyle(color: Colors.white,fontFamily: "Alata",fontSize: 14.sp))
                                    ),
                                    // DataCell(Text(rowData['city'].toString())),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: double.maxFinite,
                        margin: EdgeInsets.only(left: 2.w,right: 55.w),
                        child: SingleChildScrollView(
                          scrollDirection: Axis.vertical,
                          child: DataTable(
                            border: TableBorder.all(
                              color: /*result.questions![0].quest!
                                              .questionBackground ==
                                          "" ||
                                      result.questions![0].quest!
                                              .questionBackground ==
                                          null
                                  ? Colors.black : */
                              Colors.white,
                              width: 0.8,
                              style: BorderStyle.solid,
                            ),
                            columns: [
                              DataColumn(
                                  label: Expanded(
                                      child: Text('Question',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: /*result.questions![0].quest!
                                                              .questionBackground ==
                                                          "" ||
                                                      result
                                                              .questions![0]
                                                              .quest!
                                                              .questionBackground ==
                                                          null
                                                  ? Colors.black: */
                                              Colors.white,
                                              fontFamily: "Alata",
                                              fontSize: 16.sp)))),
                              DataColumn(
                                  label: Expanded(
                                      child: Text('Correct',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              color: /*result.questions![0].quest!
                                                              .questionBackground ==
                                                          "" ||
                                                      result
                                                              .questions![0]
                                                              .quest!
                                                              .questionBackground ==
                                                          null
                                                  ? Colors.black : */
                                              Colors.white,
                                              fontFamily: "Alata",
                                              fontSize: 16.sp)))),
                            ],
                            rows: List<DataRow>.generate(
                              Get.find<ReelsController>()
                                  .reelsList![widget.index]
                                  .questions!
                                  .length,
                              (i) {
                                //final rowData = tableData[index];
                                return DataRow(
                                  cells: [
                                    DataCell(TeXView(
                                      child: TeXViewDocument(
                                          Get.find<ReelsController>()
                                              .reelsList![widget.index]
                                              .questions![i]
                                              .quest!
                                              .questionValue!,
                                          style: /*result.questions![0].quest!
                                                          .questionBackground ==
                                                      "" ||
                                                  result.questions![0].quest!
                                                          .questionBackground ==
                                                      null
                                              ? TeXViewStyle.fromCSS(
                                                  'font-size: 14px; font-weight: bold; color: black;text-align: center;font-family:"Alata"',
                                                ) : */
                                          TeXViewStyle.fromCSS(
                                                  'font-size: 14px; font-weight: bold; color: white;text-align: center;font-family:"Alata"',
                                                )),
                                    )),
                                    DataCell(TeXView(
                                      child: TeXViewDocument(
                                          Get.find<ReelsController>()
                                              .reelsList![widget.index]
                                              .questions![i]
                                              .answer![0]
                                              .answerValue!,
                                          style: /*result.questions![0].quest!
                                                          .questionBackground ==
                                                      "" ||
                                                  result.questions![0].quest!
                                                          .questionBackground ==
                                                      null
                                              ? TeXViewStyle.fromCSS(
                                                  'font-size: 14px; font-weight: bold; color: black;text-align:center;font-family:"Alata"',
                                                ) :*/
                                          TeXViewStyle.fromCSS(
                                                  'font-size: 14px; font-weight: bold; color: white;text-align:center;font-family:"Alata"',
                                                )),
                                    )),
                                    // DataCell(Text(rowData['city'].toString())),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
                      )
                    ],
                    options: CarouselOptions(
                      height: MediaQuery.of(context).size.height * .6,
                      enableInfiniteScroll: false,
                      reverse: false,
                      autoPlay: true,
                      autoPlayInterval: Duration(seconds: 10),
                      autoPlayAnimationDuration: Duration(milliseconds: 800),
                      autoPlayCurve: Curves.fastOutSlowIn,
                      onPageChanged: (index, reason) {
                        setState(() {
                          currentIndex = index;
                        });
                      },
                      initialPage: currentIndex,
                      viewportFraction: 1,
                      //height: double.infinity, // Full-screen height
                    ),
                  ),
                ],
              ),
              /*Positioned(
                left: 0,
                bottom: 0,
                child: footerKeyword(keyword: result.keywords),
              ),*/
              Positioned(
                bottom: 60.h,
                child: DotsIndicator(
                  dotsCount: 2,
                  position: currentIndex,
                  decorator: DotsDecorator(
                      color: result.questions![0].quest!.questionBackground ==
                                  "" ||
                              result.questions![0].quest!.questionBackground ==
                                  null
                          ? AppColors.BOTTOM_NAVIGATION_BAR_COLOR
                          : Colors.white,
                      activeColor: AppColors.SLIDER_DOTTED_COLOR,
                      activeSize: const Size(28.0, 8.0),
                      size: const Size(10.0, 10.0),
                      activeShape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0))),
                ),
              ),
              Positioned(
                left: 0,
                bottom: 0,
                child: footerKeyword(keyword: result.keywords),
              ),
              Positioned(
                  right: 0,
                  bottom: 0,
                  child: Obx(() => interactiveIcons(
                        reelsId: result.sId!,
                        context: context,
                        isBackground:
                        result.questions![0].quest!.questionBackground == ""
                            ? false
                            : true, result: result,socketData: Get.find<ReelsController>().socketData),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}
