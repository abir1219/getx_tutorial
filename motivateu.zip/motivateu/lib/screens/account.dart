import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';

import '../utils/utils.dart';
import '../widgets/account_page_widget.dart';

class Account extends StatefulWidget {
  const Account({super.key});

  @override
  State<Account> createState() => _AccountState();
}

class _AccountState extends State<Account> {

  @override
  void initState() {
    super.initState();
    clearHive();
  }

  Future<void> clearHive() async{
    var box = await Hive.openBox('motivate_u_mcq');
    box.clear();
  }

  DateTime? currentBackPressTime;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: WillPopScope(
        onWillPop: () async {
          DateTime now = DateTime.now();
          if (currentBackPressTime == null ||
              now.difference(currentBackPressTime!) > Duration(seconds: 2)) {
            currentBackPressTime = now;
            Utils.showToastMessage("Press back again to exit");
            return false;
          }
          SystemNavigator.pop();
          return true;
        },
        child: Scaffold(
          body: Container(
            height: double.maxFinite,
            decoration: BoxDecoration(
                image: DecorationImage(
              image: AssetImage("assets/icons/login_bg.png"),
                  fit: BoxFit.cover
            )),
            child: AccountPageWidget(),
          ),
        ),
      ),
    );
  }
}
