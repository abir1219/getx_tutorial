import 'package:MotivateU/controllers/connection_list_controller.dart';
import 'package:MotivateU/models/connection_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';

class ConnectionListScreen extends StatefulWidget {
  const ConnectionListScreen({super.key});

  @override
  State<ConnectionListScreen> createState() => _ConnectionListScreenState();
}

class _ConnectionListScreenState extends State<ConnectionListScreen> {
  var controller = Get.find<ConnectionListController>();
  int pageNo = 1;

  ScrollController _scrollController = ScrollController();

  /*@override
  void initState() {
    super.initState();
    controller.getConnection(1);
    _scrollController.addListener(_scrollListener);
  }*/

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    // Utils.showToastMessage("hii");
    debugPrint("_scrollController.position====>${controller.myListModel.value.pagination!.totalRecord} and ${controller.connectionList!.length}");
    if (_scrollController.offset >=
            _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      // Reach the end of the list, load more data
      if (controller.myListModel.value.pagination!.totalRecord !=
          controller.connectionList!.length) {
        setState(() {
          pageNo++;
        });
        controller.getMoreConnections(pageNo);
        //_loadMoreData();
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    controller.getConnection(1);
    _scrollController.addListener(_scrollListener);

    return Scaffold(
        body: RefreshIndicator(
      color: Colors.black,
      onRefresh: () async {
        setState(() {
          pageNo = 1;
        });
        controller.getConnection(1);
      },
      child: Obx(() => controller.isLoading.value
          ? Container(
              width: double.maxFinite,
              color: Colors.white,
              margin: EdgeInsets.symmetric(vertical: 10.h),
              child: Center(
                child: SizedBox(
                  height: 24.h,
                  width: 24.w,
                  child: CircularProgressIndicator(
                    color: Colors.black,
                  ),
                ),
              ),
            )
          : Obx(() =>  controller.connectionList!.length > 0
                ? Container(
                    margin: EdgeInsets.only(top: 10.h, bottom: 15.h),
                    padding: EdgeInsets.all(6.sp),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Color(0xFFF7F7F7))),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        /*Container(
                            margin: EdgeInsets.only(top: 10.h, bottom: 15.h),
                            child: Text(
                              "Connections:",
                              style: TextStyle(
                                  fontFamily: 'Alata',
                                  color: Colors.black,
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.bold),
                            )),*/
                        Expanded(
                          child: Column(
                            children: [
                              //Text("${controller.connectionList!.length}"),
                              Container(
                                  alignment: Alignment.centerLeft,
                                  margin: EdgeInsets.only(top: 10.h, bottom: 15.h),
                                  child: Text(
                                    "Connections:",
                                    style: TextStyle(
                                        fontFamily: 'Alata',
                                        color: Colors.black,
                                        fontSize: 18.sp,
                                        fontWeight: FontWeight.bold),
                                  )),
                              Scrollbar(
                                child: NotificationListener<
                                    OverscrollIndicatorNotification>(
                                  onNotification:
                                      (OverscrollIndicatorNotification notification) {
                                    notification.disallowIndicator();
                                    return true;
                                  },
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    controller: _scrollController,
                                    itemBuilder: (context, index) {
                                      //debugPrint("controller.connectionList.length==>${controller.connectionList![index].name} and ${controller.connectionList![index].name}");
                                      return Column(
                                        children: [
                                          Obx(() =>
                                      //(!controller.connectionList![index].isConnection! && controller.connectionList![index].requestStatus == "none")?
                                        reusableGroupConnection(
                                            controller.connectionList![index],
                                            index,
                                            controller.connectionList![index]
                                                .isConnection!)
                                          //:Container()
                                          ),
                                          index + 1 !=
                                                  controller.connectionList!.length
                                              ? Divider(
                                                  color: Colors.grey.withOpacity(0.5),
                                                  height: 1.h,
                                                )
                                              : Container()
                                        ],
                                      );
                                    },
                                    itemCount: controller.connectionList!.length,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        controller.isMoreLoading.value
                            ? Container(
                                width: double.maxFinite,
                                color: Colors.white,
                                margin: EdgeInsets.symmetric(vertical: 10.h),
                                child: Center(
                                  child: SizedBox(
                                    height: 24.h,
                                    width: 24.w,
                                    child: CircularProgressIndicator(
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              )
                            : Container()
                      ],
                    ),
                  )
                : Container(
                    child: Center(
            child: Text("No records found"),
                    ),
                  ),
          ),),
    ));
  }

  Widget reusableGroupConnection(
      Result connection, int index, bool isConnected) {
    // debugPrint("connection.isConnection! && connection.requestStatus==none=======>${!connection.isConnection! && connection.requestStatus=="none"}");
    // debugPrint("connection.isConnection! && connection.requestStatus==request=======>${!connection.isConnection! && connection.requestStatus=="request"}");
    // debugPrint("connection.isConnection! && connection.requestStatus==send=======>${!connection.isConnection! && connection.requestStatus=="send"}");
    return Container(
      width: double.maxFinite,
      color: Colors.transparent,
      margin: EdgeInsets.symmetric(vertical: 12.h, horizontal: 10.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            // alignment:Alignment.centerLeft,
            //color: Colors.red,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                connection.avatar == ""
                    ? CircleAvatar(
                        backgroundImage:
                            AssetImage("assets/icons/avatar_img.jpg"),
                        radius: 20.w,
                      )
                    : Container(
                        height: 20.h,
                        width: 20.w,
                        margin: EdgeInsets.only(
                          right: 12.w,
                        ),
                        child: Center(
                          child: Icon(Icons.person),
                        ),
                      ),
                Container(
                  margin: EdgeInsets.only(bottom: 4.h, left: 12.w),
                  //alignment:Alignment.centerLeft,
                  // color: Colors.amber,
                  child: Text(
                    "${connection.name}",
                    style: TextStyle(
                        color: AppColors.TITLE_TEXT_BLACK,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.normal,
                        fontFamily: "Alata"),
                  ),
                ),
              ],
            ),
          ),
          if (!connection.isConnection! && connection.requestStatus == "none")
            GestureDetector(
              onTap: () => controller.sendConnectionRequest(connection.id,() => controller.getConnection(1)),
              child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  margin: EdgeInsets.only(right: 10.w),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      border: Border.all(color: AppColors.DEEP_BLUE_COLOR)),
                  child: Center(
                    child: Text(
                      "Connect",
                      style: TextStyle(
                          fontSize: 14.sp,
                          color: AppColors.DEEP_BLUE_COLOR,
                          fontFamily: 'Alata'),
                    ),
                  )),
            ),
          /*if (!connection.isConnection! &&
              connection.requestStatus == "request")
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: () => controller.actionAgainstConnectionRequest(
                      connection.requestId, 'decline',() => null),
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 4.w),
                    height: 34.h,
                    width: 34.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100.sp),
                      // color: Colors.red
                    ),
                    child: SvgPicture.asset(
                      "assets/icons/crossmark.svg",
                    ),
                  ),
                ),
                Gap(10.w),
                GestureDetector(
                  onTap: () => controller.actionAgainstConnectionRequest(
                      connection.requestId, 'accept',() => null),
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 4.w),
                    height: 34.h,
                    width: 34.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100.sp),
                      //color: Colors.blueAccent
                    ),
                    child: SvgPicture.asset(
                      "assets/icons/tickmark.svg",
                    ),
                  ),
                )
              ],
            ),*/
          /*if (!connection.isConnection! && connection.requestStatus == "send")
            GestureDetector(
              onTap: () => controller.actionAgainstConnectionRequest(
                  connection.cancelId, 'cancel',() => null),
              child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  margin: EdgeInsets.only(right: 10.w),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      border: Border.all(color: AppColors.DEEP_BLUE_COLOR)),
                  child: Center(
                    child: Text(
                      "Cancel Request",
                      style: TextStyle(
                          fontSize: 14.sp,
                          color: AppColors.DEEP_BLUE_COLOR,
                          fontFamily: 'Alata'),
                    ),
                  )),
            )*/
        ],
      ),
    );
  }
}
