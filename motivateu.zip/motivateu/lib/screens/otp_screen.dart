import 'package:MotivateU/res/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../widgets/custom_button.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({super.key});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  String currentText = "";
  final formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/icons/login_bg.jpg"),
            fit: BoxFit.cover
          )
        ),
        child: Stack(
          children: [
            /*SizedBox(
              height: double.maxFinite,
              width: double.maxFinite,
              child: SvgPicture.asset(
                "assets/icons/splash.svg",
                fit: BoxFit.fill,
              ),
            ),*/
            Container(
              margin: EdgeInsets.symmetric(horizontal: 12.w),
              child: Column(
                // mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Flexible(
                    flex: 1,
                    child: GestureDetector(
                      onTap: () => Get.back(),
                      child: Container(
                        margin: EdgeInsets.only(top: 30.w),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 24.h,
                              width: 24.w,
                              child: Icon(
                                Icons.arrow_back_ios_new_outlined,
                                color: AppColors.BACK_ARROW_COLOR,
                              ),
                            ),
                            Gap(5.h),
                            Text("Back",
                                style: TextStyle(
                                    fontSize: 20.sp,
                                    color: AppColors.FIELD_HINT_COLOR,
                                    fontFamily: 'Poppins'))
                          ],
                        ),
                      ),
                    ),
                  ),
                  Flexible(
                    flex: 6,
                    child: Container(
                      alignment: Alignment.center,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Container(
                          //   height: 200,
                          //   color: Colors.red,
                          // ),
                          Container(
                            height: 80.h,
                            // color: Colors.red,
                            alignment: Alignment.center,
                            child: Text("00:24",style: TextStyle(fontSize: 32.sp,color: AppColors.OTP_TIMER_COLOR),),
                          ),
                          Form(
                            key: formKey,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                vertical: 8.0,
                                horizontal: 30,
                              ),
                              child: PinCodeTextField(
                                appContext: context,
                                pastedTextStyle: TextStyle(
                                    color: AppColors.OTP_PIN_VIEW_COLOR,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15.sp),
                                length: 6,
                                /*obscureText: true,
                              obscuringCharacter: '*',
                              obscuringWidget: const FlutterLogo(
                                size: 24,
                              ),*/
                                // blinkWhenObscuring: true,
                                animationType: AnimationType.fade,
                                validator: (v) {
                                  /*if (v!.length < 3) {
                                  return "I'm from validator";
                                } else {
                                  return null;
                                }*/
                                },
                                pinTheme: PinTheme(
                                    shape: PinCodeFieldShape.box,
                                    borderRadius: BorderRadius.circular(5),
                                    fieldHeight: 50.h,
                                    fieldWidth: 40.w,
                                    activeFillColor: Colors.transparent,
                                    inactiveFillColor: Colors.transparent,
                                    selectedFillColor: Colors.transparent,
                                    activeColor: AppColors.OTP_PIN_VIEW_COLOR,
                                    inactiveColor: AppColors.OTP_PIN_VIEW_COLOR,
                                    selectedColor: AppColors.OTP_PIN_VIEW_COLOR,
                                    activeBorderWidth: .8,
                                    selectedBorderWidth: .8,
                                    inactiveBorderWidth: .8),
                                cursorColor: AppColors.OTP_PIN_VIEW_COLOR,
                                animationDuration:
                                    const Duration(milliseconds: 300),
                                enableActiveFill: true,
                                // errorAnimationController: errorController,
                                // controller: textEditingController,
                                keyboardType: TextInputType.number,
                                // boxShadows: const [
                                //   BoxShadow(
                                //     offset: Offset(0, 1),
                                //     color: Colors.black12,
                                //     blurRadius: 10,
                                //   )
                                // ],
                                onCompleted: (v) {
                                  debugPrint("Completed");
                                },
                                // onTap: () {
                                //   print("Pressed");
                                // },
                                onChanged: (value) {
                                  debugPrint(value);
                                  setState(() {
                                    currentText = value;
                                    debugPrint("------VALUE------ $currentText");
                                  });
                                },
                                beforeTextPaste: (text) {
                                  debugPrint("Allowing to paste $text");
                                  //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                                  //but you can show anything you want here, like your pop up saying wrong paste format or etc
                                  return true;
                                },
                              ),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                  margin: EdgeInsets.only(
                                      top: 10.w, left: 25.w, right: 2.w),
                                  child: Text("Time Out.",
                                      style: TextStyle(
                                          fontSize: 16.sp,
                                          color: AppColors.FIELD_HINT_COLOR,
                                          fontFamily: 'Poppins'))),
                              Container(
                                  margin: EdgeInsets.only(
                                      top: 10.w, right: 25.w, left: 2.w),
                                  child: Text("Resend OTP",
                                      style: TextStyle(
                                          fontSize: 16.sp,
                                          color: AppColors.ON_BOARDING_BUTTON_COLOR,
                                          fontFamily: 'Poppins')))
                            ],
                          ),
                          Center(
                            child: CustomButton(
                                buttonName: "VERIFY",
                                callback: () {
                                  debugPrint("------Clicked------");
                                }),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ));
  }
}
