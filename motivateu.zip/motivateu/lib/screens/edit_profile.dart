import 'package:flutter/material.dart';

import '../widgets/edit_profile_widget.dart';

class EditProfile extends StatelessWidget {
  const EditProfile({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          body: Container(
              height: double.maxFinite,
              decoration: BoxDecoration(
                // color: Colors.red,
                  image: DecorationImage(
                      image: AssetImage("assets/icons/login_bg.jpg"),
                      fit: BoxFit.cover
                  )
              ),
              child: EditProfileWidget()
          ),
        ));
  }
}
