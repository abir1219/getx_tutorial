import 'package:MotivateU/controllers/reels_controller.dart';
import 'package:MotivateU/main.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../helper/api_end_points.dart';
import '../models/reels_model.dart';
import '../res/app_colors.dart';
import '../widgets/qreels_widget.dart';

class DescriptiveWithoutBg extends StatefulWidget {
  final int index;

  const DescriptiveWithoutBg({super.key, required this.index});

  @override
  State<DescriptiveWithoutBg> createState() => _DescriptiveWithoutBgState();
}

class _DescriptiveWithoutBgState extends State<DescriptiveWithoutBg> {
  int currentIndex = 0;
  dynamic socketData;
  var result;
  @override
  void initState() {
    super.initState();
    /*if(socket.connected){
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        socketData = data['data'];
      });
    }*/

  }


  @override
  void dispose() {
    super.dispose();
    debugPrint("<<<<<DescWithoutBg_DISPOSE>>>>>");
  }

  @override
  Widget build(BuildContext context) {

    result = Get.find<ReelsController>().reelsList![widget.index];
    if(socket.connected){
      debugPrint("<<<<<DescWithoutBg_DATA>>>>> ${result.sId}");
      //socket.emit('reel-action',result.sId);
      //socket.on('reel-action', (data) => debugPrint("<<<<<DATA>>>>> $data"));
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        /* setState(() {
              socketData = data['data'];
            });*/
        // Get.find<ReelsController>().socketData = data['data'];
        Get.find<ReelsController>().socketData.assignAll(data['data']);
        debugPrint("<<<<<socketData Descriptive without bg>>>>> ${socketData}");


      });
    }

    debugPrint("<<<<<DescWithoutBg_build>>>>>");
    debugPrint("Total -> ${result.questions![0].answer!.length + 1}");



    return Scaffold(
      body: Container(
        height: double.maxFinite,
        width: double.maxFinite,
        // color: Colors.red,
        decoration: BoxDecoration(
            /*gradient: result.questions![0].quest!.questionBackground == ""
                ? LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.purple, Colors.orange])
                : null,*/
            //color: result.questions![0].quest!.questionBackground == ""?Colors.white:null,
            /*color: result.questions![0].quest!.questionBackground == "" ||
                result.questions![0].quest!.questionBackground == null
                ? Colors.transparent
                : Colors.black,*/

            color: Colors.black.withOpacity(0.3),
            image: result.questions![0].quest!.questionBackground != ""
                ? DecorationImage(
                image: NetworkImage(
                    ApiEndPoints.IMAGE_URL+result.questions![0].quest!.questionBackground!),
                fit: BoxFit.cover)
                : null),
        child: Stack(
          children: [
            Stack(
              alignment: Alignment.bottomCenter,
              children: [
                CarouselSlider.builder(
                  itemBuilder: (context, index, realIndex) {
                    debugPrint("INDEX==>$index");
                    if (index == 0) {
                      // Display question in the first slide
                      return QuestionSlide(result.questions![0]);
                    } else {
                      // Display answers in subsequent slides
                      final answerIndex = index - 1;
                      return AnswerSlide(result.questions![0].answer![answerIndex+1],result);
                    }
                  },
                  options: CarouselOptions(
                    onPageChanged: (index, reason) {
                      setState(() {
                        currentIndex = index;
                      });
                    },
                    initialPage: currentIndex,
                    viewportFraction: 1,
                    height: double.infinity, // Full-screen height
                    enableInfiniteScroll: false,
                    reverse: false,
                    autoPlay: true,
                    autoPlayInterval: Duration(seconds: 10),
                    autoPlayAnimationDuration: Duration(milliseconds: 800),
                    autoPlayCurve: Curves.fastOutSlowIn,
                  ),itemCount: result.questions![0].answer!.length,
                ),
                Positioned(
                  top: 20.h,
                  child: DotsIndicator(dotsCount: result.questions![0].answer!.length,
                    position: currentIndex,
                    decorator: DotsDecorator(
                        color: /*result.questions![0].quest!.questionBackground=="" ?Colors.black:*/Colors.white,
                        activeColor: AppColors.SLIDER_DOTTED_COLOR,
                        activeSize: const Size(28.0, 8.0),
                        size: const Size(10.0, 10.0),
                        activeShape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5.0))),
                  ),
                )
              ],
            ),
            Positioned(
              left: 0,
              bottom: 0,
              child: footerKeyword(keyword: result.keywords),
            ),
            Positioned(right: 0, bottom: 0, child: Obx(() => interactiveIcons(reelsId: result.sId!,context: context,isBackground:result.questions![0].quest!.questionBackground == ""?false:true,  result: result,socketData: Get.find<ReelsController>().socketData))),
          ],
        ),
      ),
    );
  }
}

class QuestionSlide extends StatelessWidget {
  // final Map<String, dynamic> question;
  final Questions question;

  QuestionSlide(this.question);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: question.answer![0].answerBackground != ""
              ? Colors.black
              : Colors.transparent,
        image: question.answer![0].answerBackground !=""?DecorationImage(
          image: NetworkImage(ApiEndPoints.IMAGE_URL+question.answer![0].answerBackground!),
          fit: BoxFit.cover,
          opacity: 0.45
        ):null
      ),
      child: Container(
        margin: EdgeInsets.only(right: 50),
        padding: EdgeInsets.only(left: 12.w,top: 20.h,bottom: 20.h),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            /*Text(
                question.quest!.questionValue!,
              style: TextStyle(fontSize: 22.0,fontWeight: FontWeight.bold,color: question.quest!.questionBackground==""?Colors.black:Colors.white,fontFamily: "Alata"),
            ),*/
            TeXView(
              child: TeXViewDocument(question.quest!.questionValue!,
                  style: question.quest!.questionBackground==""?TeXViewStyle.fromCSS(
                    'font-size: 22px; font-weight: bold; color: white;',
                  ):TeXViewStyle.fromCSS(
                    'font-size: 22px; font-weight: bold; color: white;',
                  )),
            ),
            Gap(10.h),
            TeXView(
              child: TeXViewDocument(question.answer![0].answerValue!,
                  style: question.quest!.questionBackground==""?TeXViewStyle.fromCSS(
                    'font-size: 20px; font-weight: bold; color: white;',
                  ):TeXViewStyle.fromCSS(
                    'font-size: 20px; font-weight: bold; color: white;',
                  )),
            ),
            /*Text(
              question.answer![0].answerValue!,
              maxLines: 12,
              style: TextStyle(fontSize: 20.0,color: question.quest!.questionBackground==""?Colors.black:Colors.white,height:1.3,fontFamily: "Alata"),
            ),*/
          ],
        ),
      ),
    );
  }
}

class AnswerSlide extends StatelessWidget {
  // final Map<String, dynamic> answer;
  final Answer answer;
  final Result result;

  AnswerSlide(this.answer, this.result);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.maxFinite,
      width: double.maxFinite,
      decoration: BoxDecoration(
          color: answer.answerBackground != ""
              ? Colors.black
              : Colors.transparent,
          image: answer.answerBackground!=""?DecorationImage(
              image: NetworkImage(ApiEndPoints.IMAGE_URL+answer.answerBackground!),
              fit: BoxFit.cover,
              opacity: 0.45
          ):null
      ),
      child: Container(
        margin: EdgeInsets.only(right: 50),
        padding: EdgeInsets.only(left: 12.w,top: 20.h,bottom: 20.h),
        child: Center(
          child:TeXView(
            child: TeXViewDocument(answer.answerValue!,
                style: result.questions![0].quest!.questionBackground==""?TeXViewStyle.fromCSS(
                  'font-size: 20px; font-weight: bold; color: white;',
                ):TeXViewStyle.fromCSS(
                  'font-size: 20px; font-weight: bold; color: white;',
                )),
          ),

          /*Text(
            "${answer.answerValue}",
            maxLines: 12,
            style: TextStyle(fontSize: 20.0,color: result.questions![0].quest!.questionBackground==""?Colors.black:Colors.white,fontFamily: "Alata"),
          ),*/
        ),
      ),
    );
  }
}
