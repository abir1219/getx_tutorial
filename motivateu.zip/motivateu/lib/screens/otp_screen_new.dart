import 'dart:async';

import 'package:MotivateU/controllers/login_controller.dart';
import 'package:MotivateU/controllers/otp_controller.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../widgets/custom_button.dart';

class OtpScreenNew extends StatefulWidget {
  const OtpScreenNew({
    super.key,
  });

  @override
  State<OtpScreenNew> createState() => _OtpScreenNewState();
}

class _OtpScreenNewState extends State<OtpScreenNew> {
  final controller = Get.find<OtpController>();

  //controller.phController.value.text = Get.arguments[0];
  late Timer _timer;
  int _secondsRemaining = 10;

  void startTimer() {
    const oneSecond = const Duration(seconds: 1);
    _timer = Timer.periodic(
      oneSecond,
      (Timer timer) {
        if (_secondsRemaining == 0) {
          timer.cancel();
          // Handle the timeout, e.g., resend OTP or show a message.
        } else {
          setState(() {
            _secondsRemaining--;
          });
        }
      },
    );
  }

  @override
  void initState() {
    super.initState();
    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Container(
        //margin: EdgeInsets.symmetric(horizontal: 12.w),
        padding: EdgeInsets.symmetric(horizontal: 12.w),
        height: double.maxFinite,
        decoration: BoxDecoration(
            // color: Colors.red,
            image: DecorationImage(
                image: AssetImage("assets/icons/login_bg.jpg"),
                fit: BoxFit.cover)),
        // color: Colors.green,
        child: ListView(
          shrinkWrap: true,
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Gap(25.w),
            GestureDetector(
              onTap: () => Get.back(),
              child: Container(
                margin: EdgeInsets.only(top: 30.w),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 24.h,
                      width: 24.w,
                      child: Icon(
                        Icons.arrow_back_ios_new_outlined,
                        color: AppColors.BACK_ARROW_COLOR,
                      ),
                    ),
                    Gap(5.h),
                    Text("Back",
                        style: TextStyle(
                            fontSize: 20.sp,
                            color: AppColors.FIELD_HINT_COLOR,
                            fontFamily: 'Poppins'))
                  ],
                ),
              ),
            ),
            Gap(55.w),
            Obx(() => controller.isLoad.value?
              Container(
                height: double.maxFinite,
                width: double.maxFinite,
                child: Center(
                  child: SizedBox(
                    height: 24.h,
                    width: 24.w,
                    child: CircularProgressIndicator(color: Colors.black,),
                  ),
                ),
              )
                  :Column(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width / 1.2,
                    margin: EdgeInsets.symmetric(horizontal: 12.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("OTP has been sent to",
                            style: TextStyle(
                                fontSize: 20.sp,
                                color: AppColors.TITLE_TEXT_BLACK,
                                fontWeight: FontWeight.bold,
                                fontFamily: "Poppins")),
                        Obx(() => Text(
                              // "+91-${Get.arguments[0]}\nOtp:${controller.sendOtpData.value.otp}",
                              "+91-${controller.phController.value.text.trim().toString()}\nOtp:${Get.arguments != null ? Get.arguments[1] == 'login' ? Get.find<LoginController>().sendOtpData.value.otp : controller.sendOtpData.value.otp : controller.sendOtpData.value.otp}",
                              style: TextStyle(
                                  fontSize: 24.sp,
                                  color: AppColors.ON_BOARDING_BUTTON_COLOR,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "Poppins")),
                        ),
                      ],
                    ),
                  ),
                  Gap(35.w),
                  Container(
                    // color: Colors.red,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Container(
                        //   height: 200,
                        //   color: Colors.red,
                        // ),
                        Container(
                          height: 80.h,
                          // color: Colors.red,
                          alignment: Alignment.center,
                          child: Text(
                            //"00:24",
                            _secondsRemaining == 0
                                ? '00:00'
                                : _secondsRemaining.toString().length == 1 ? '00:0${_secondsRemaining}' : '00:${_secondsRemaining}',
                            style: TextStyle(
                                fontSize: 32.sp, color: AppColors.OTP_TIMER_COLOR),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: 8.0,
                            horizontal: 30,
                          ),
                          child: PinCodeTextField(
                            appContext: context,
                            pastedTextStyle: TextStyle(
                                color: AppColors.OTP_PIN_VIEW_COLOR,
                                fontWeight: FontWeight.bold,
                                fontSize: 15.sp),
                            length: 6,
                            animationType: AnimationType.fade,
                            pinTheme: PinTheme(
                                shape: PinCodeFieldShape.box,
                                borderRadius: BorderRadius.circular(5),
                                fieldHeight: 50.h,
                                fieldWidth: 40.w,
                                activeFillColor: Colors.transparent,
                                inactiveFillColor: Colors.transparent,
                                selectedFillColor: Colors.transparent,
                                activeColor: AppColors.OTP_PIN_VIEW_COLOR,
                                inactiveColor: AppColors.OTP_PIN_VIEW_COLOR,
                                selectedColor: AppColors.OTP_PIN_VIEW_COLOR,
                                activeBorderWidth: .8,
                                selectedBorderWidth: .8,
                                inactiveBorderWidth: .8),
                            cursorColor: AppColors.OTP_PIN_VIEW_COLOR,
                            animationDuration: const Duration(milliseconds: 300),
                            enableActiveFill: true,
                            keyboardType: TextInputType.number,
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                            onCompleted: (value) {
                              debugPrint("Completed");
                            },
                            onChanged: (value) {
                              debugPrint(value);
                              controller.otpController.value = value;
                            },
                            beforeTextPaste: (text) {
                              debugPrint("Allowing to paste $text");
                              return true;
                            },
                          ),
                        ),
                        _secondsRemaining == 0
                            ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                                margin: EdgeInsets.only(
                                    top: 10.w, left: 25.w, right: 2.w),
                                child: Text("Time Out.",
                                    style: TextStyle(
                                        fontSize: 16.sp,
                                        color: AppColors.FIELD_HINT_COLOR,
                                        fontFamily: 'Poppins'))),
                            GestureDetector(
                              onTap: () {
                                setState(() {
                                  _secondsRemaining = 60;
                                });
                                controller.sendOtp();
                                startTimer();
                              },
                              child: Container(
                                  margin: EdgeInsets.only(
                                      top: 10.w, right: 25.w, left: 2.w),
                                  child: Text("Resend OTP",
                                      style: TextStyle(
                                          fontSize: 16.sp,
                                          color:
                                          AppColors.ON_BOARDING_BUTTON_COLOR,
                                          fontFamily: 'Poppins'))),
                            )
                          ],
                        )
                            : Container(),
                        Obx(
                          () => Center(
                            child: CustomButton(
                              buttonName: "VERIFY",
                              callback: () {
                                debugPrint(
                                    "------Clicked------${controller.otpController.value}");
                                if (controller.otpController.value.length == 6) {
                                  controller.verifyOtp(Get.arguments[1]);
                                } else {
                                  Utils.showToastMessage("Enter a valid otp");
                                }
                                // Get.toNamed(AppRoutes.dashboard);
                              },
                              loading: controller.isLoading.value,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ));
  }
}
