import 'package:MotivateU/models/reels_model.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_tex/flutter_tex.dart';
import 'package:get/get.dart';

import '../controllers/reels_controller.dart';
import '../helper/api_end_points.dart';
import '../main.dart';
import '../res/app_colors.dart';
import '../widgets/qreels_widget.dart';

class DescriptiveWithBg extends StatefulWidget {
  final int index;

  const DescriptiveWithBg({super.key, required this.index});

  @override
  State<DescriptiveWithBg> createState() => _DescriptiveWithBgState();
}

class _DescriptiveWithBgState extends State<DescriptiveWithBg> {
  int currentIndex = 0;
  dynamic socketData;
  var result;

  @override
  void initState() {
    super.initState();
    /*if(socket.connected){
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        socketData = data['data'];
      });
    }*/

  }


  @override
  void dispose() {
    super.dispose();
    debugPrint("<<<<<DescriptiveWithBg_DISPOSE>>>>>");
  }

  @override
  Widget build(BuildContext context) {
    result =
    Get.find<ReelsController>().reelsList![widget.index];
    if(socket.connected){
      debugPrint("<<<<<DescriptiveWithBg_DATA>>>>> ${result.sId}");
      //socket.emit('reel-action',result.sId);
      socket.on('reel-action', (data) {
        debugPrint("<<<<<DATA>>>>> ${data['data']['like']}");
        /*setState(() {
              socketData = data['data'];
            });*/
        // Get.find<ReelsController>().socketData = data['data'];
        Get.find<ReelsController>().socketData.assignAll(data['data']);
        debugPrint("<<<<<socketData Descriptive with bg>>>>> ${socketData}");
      });
      //socket.on('reel-action', (data) => debugPrint("<<<<<DATA>>>>> $data"));
    }

    debugPrint("<<<<<DescriptiveWithBg_build>>>>>");

    debugPrint("Total -> ${result.questions![0].answer!.length + 1}");



    return Container(
      height: double.maxFinite,
      width: double.maxFinite,
      /*decoration: BoxDecoration(
          image: DecorationImage(
              image: NetworkImage(result.questions![0].quest!.questionBackground!),
              fit: BoxFit.cover
          )
      ),*/
      decoration: BoxDecoration(
          /*gradient: result.questions![0].quest!.questionBackground == ""
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Colors.purple, Colors.orange])
              : null,*/
          // color: result.questions![0].quest!.questionBackground == ""?Colors.white:null,
          image: result.questions![0].quest!.questionBackground != ""
              ? DecorationImage(
                  image: NetworkImage(
                      ApiEndPoints.IMAGE_URL+result.questions![0].quest!.questionBackground!),
                  fit: BoxFit.cover)
              : null),
      // colors: [Color.fromRGBO(200,200,200,75), Color.fromRGBO(137,115,153,100)]):null),
      child: Stack(
        children: [
          Stack(
            alignment: Alignment.topCenter,
            children: [
              CarouselSlider.builder(
                itemBuilder: (context, index, realIndex) {
                  debugPrint("INDEX==>$index");
                  if (index == 0) {
                    // Display question in the first slide
                    return QuestionSlide(result.questions![0]);
                  } else {
                    // Display answers in subsequent slides
                    final answerIndex = index - 1;
                    return AnswerSlide(
                        result.questions![0].answer![answerIndex],result);
                  }
                },
                options: CarouselOptions(
                  onPageChanged: (index, reason) {
                    setState(() {
                      currentIndex = index;
                    });
                  },
                  initialPage: 0,
                  viewportFraction: 1,
                  height: double.infinity,
                  // Full-screen height
                  enableInfiniteScroll: false,
                  reverse: false,
                  autoPlay: true,
                  autoPlayInterval: Duration(seconds: 10),
                  autoPlayAnimationDuration: Duration(milliseconds: 800),
                  autoPlayCurve: Curves.fastOutSlowIn,
                ),
                itemCount: result.questions![0].answer!.length + 1,
              ),
              Positioned(
                top: 20.h,
                child: DotsIndicator(
                  dotsCount: result.questions![0].answer!.length + 1,
                  position: currentIndex,
                  decorator: DotsDecorator(
                      color: result.questions![0].quest!.questionBackground=="" ?Colors.black:Colors.white,
                      activeColor: AppColors.SLIDER_DOTTED_COLOR,
                      activeSize: const Size(28.0, 8.0),
                      size: const Size(10.0, 10.0),
                      activeShape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0))),
                ),
              )
            ],
          ),
          Positioned(
            left: 0,
            bottom: 0,
            child: footerKeyword(keyword: result.keywords),
          ),
      Positioned(
          right: 0,
          bottom: 0,
          child: Obx(() => interactiveIcons(reelsId: result.sId!,context: context,isBackground:result.questions![0].quest!.questionBackground == ""?false:true, result: result, socketData: Get.find<ReelsController>().socketData))),

        ],
      ),
    );
  }
}

class QuestionSlide extends StatelessWidget {
  // final Map<String, dynamic> question;
  final Questions question;

  QuestionSlide(this.question);

  @override
  Widget build(BuildContext context) {
    var ques = question.quest!.questionValue!;
    String dynamicText =
        '<p>The Question is:</p><p><math xmlns="http://www.w3.org/1998/Math/MathML"><mfrac><mn>1</mn><mn>2</mn></mfrac><mo>&nbsp;</mo><mo>+</mo><mo>&nbsp;</mo><mroot><mn>100</mn><mn>2</mn></mroot><mo>&nbsp;</mo><mo>+</mo><mo>∞</mo><mo>⇔</mo></math><math class="wrs_chemistry" xmlns="http://www.w3.org/1998/Math/MathML"><mo>∆</mo><mo>&nbsp;</mo><mi>and</mi><mo>&nbsp;</mo><mo>∂</mo><mo>⩾</mo><menclose notation="updiagonalstrike"><mn>100</mn></menclose></math></p>';

    return Container(
      decoration: BoxDecoration(
          color: question.quest!.questionBackground != ""
              ? Colors.black
              : Colors.transparent,
          image: question.quest!.questionBackground != ""
              ? DecorationImage(
                  image: NetworkImage(ApiEndPoints.IMAGE_URL+question.quest!.questionBackground!),
                  fit: BoxFit.cover,
                  opacity: 0.45)
              : null),
      child: Container(
        margin: EdgeInsets.only(right: 50),
        padding: EdgeInsets.only(left: 12.w, top: 20.h, bottom: 20.h),
        child: Center(
            //${question.quest!.questionValue!}$
            child: TeXView(
          child: TeXViewDocument(question.quest!.questionValue!,
              style: question.quest!.questionBackground==""?TeXViewStyle.fromCSS(
                'font-size: 22px; font-weight: bold; color: black;',
              ):TeXViewStyle.fromCSS(
                'font-size: 22px; font-weight: bold; color: white;',
              )),
        )),
      ),
    );
  }
}

class AnswerSlide extends StatelessWidget {
  // final Map<String, dynamic> answer;
  final Answer answer;
  final Result result;

  AnswerSlide(this.answer, this.result);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.maxFinite,
      width: double.maxFinite,
      alignment: Alignment.center,
      decoration: BoxDecoration(
          color: answer.answerBackground != "" ?Colors.black:Colors.transparent,
          image: answer.answerBackground != "" ?DecorationImage(
              image: NetworkImage(ApiEndPoints.IMAGE_URL+answer.answerBackground!),
              fit: BoxFit.cover,
              opacity: 0.45):null),
      child: Container(
        margin: EdgeInsets.only(right: 50),
        // color: Colors.red,
        padding: EdgeInsets.only(left: 12.w, top: 20.h, bottom: 20.h),
        child: Center(
            child: TeXView(
          child: TeXViewDocument(answer.answerValue!,
              style: result.questions![0].quest!.questionBackground==""?TeXViewStyle.fromCSS(
                'font-size: 20px; font-weight: bold; color: black;line-height:1.3',
              ):TeXViewStyle.fromCSS(
                'font-size: 20px; font-weight: bold; color: white;line-height:1.3',
              )),
        )

            // Text(
            //   "${answer.answerValue}",
            //   style: TextStyle(fontSize: 20.0,color: Colors.white,height:1.3,fontFamily: "Alata"),
            // ),
            ),
      ),
    );
  }
}
