import 'package:MotivateU/controllers/otp_controller.dart';
import 'package:MotivateU/widgets/custom_button.dart';
import 'package:MotivateU/widgets/reusable_sign_in_widgets.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../utils/utils.dart';

class MobileScreen extends StatefulWidget {
  const MobileScreen({super.key});

  @override
  State<MobileScreen> createState() => _MobileScreenState();
}

class _MobileScreenState extends State<MobileScreen> {
  final controller = Get.find<OtpController>();
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();




  void validateForm() {
    if(controller.phController.value.text.toString().isEmpty){
      Utils.showToastMessage("Enter Mobile No");
    }else if(controller.phController.value.text.toString().length != 10){
      Utils.showToastMessage("Enter a valid Mobile Number");
    }else{
      controller.sendOtp();
    }
  }

  @override
  void dispose() {
    super.dispose();
    // controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: Container(
        height: double.maxFinite,
        decoration: BoxDecoration(
            // color: Colors.red,
            image: DecorationImage(
                image: AssetImage("assets/icons/login_bg.jpg"),
                fit: BoxFit.cover)),
        child: Center(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                // shrinkWrap: true,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  reusableTitleText("Welcome to MotivateU"),
                  reusableSubTitleText("Please login to continue our app"),
                  reusableFieldText("Mobile"),
                  reusableField(
                    context,
                    "Your mobile no.",
                    controller.phController.value,
                    null,
                    null,
                    "ph",
                  ),
                  Obx(() => Center(
                      child: CustomButton(
                        buttonName: "SEND OTP",
                        callback: () => validateForm(),
                        loading: controller.isLoading.value,
                        //loading: controller.isLoading.value,
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    ));
  }
}
