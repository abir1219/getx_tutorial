import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

class FreeTimeOverAlertDialog extends StatefulWidget {
  const FreeTimeOverAlertDialog({super.key});

  @override
  State<FreeTimeOverAlertDialog> createState() =>
      _FreeTimeOverAlertDialogState();
}

class _FreeTimeOverAlertDialogState extends State<FreeTimeOverAlertDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
                margin: EdgeInsets.only(top: 40.h, bottom: 10.h),
                child: SvgPicture.asset(
                  "assets/icons/hourglass.svg", width: 70.w, height: 70.h,)),
            Container(
              margin: EdgeInsets.only(top: 10.h, bottom: 10.h),
              child: Text("Your Free Minutes Are Over For The Day",
                style: TextStyle(fontSize: 12.sp,
                    fontFamily: 'Alata',
                    fontWeight: FontWeight.bold,
                    color: AppColors.BOTTOM_NAVIGATION_BAR_COLOR),),
            ),
            Container(
              margin: EdgeInsets.only(bottom: 10.h),
              child: Text("Subscribe to continue",
                style: TextStyle(fontSize: 12.sp,
                    fontFamily: 'Alata',
                    fontWeight: FontWeight.normal,
                    color: AppColors.BOTTOM_NAVIGATION_BAR_COLOR),),
            ),
            GestureDetector(
              onTap: () => Get.offNamed(AppRoutes.SubscribeDetails),
              child: Container(
                margin: EdgeInsets.only(
                    top: 10.h, bottom: 10.h, left: 25.w, right: 25.w),
                alignment: Alignment.center,
                //width: 260.w,
                height: 45,
                //padding: EdgeInsets.symmetric(horizontal: 55.w, vertical: 20.w),
                decoration: BoxDecoration(
                    color: AppColors.ON_BOARDING_BUTTON_COLOR,
                    borderRadius: BorderRadius.circular(40.0.w),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 1,
                          blurRadius: 2,
                          offset: const Offset(1, 2))
                    ]),
                child: Text("Subscribe Now!", style: TextStyle(fontSize: 14.sp,
                    color: Colors.white,
                    fontFamily: 'Alata'),),
              ),
            ),
            GestureDetector(
              onTap: () {
                Utils.showToastMessage("Cancel");
                Get.toNamed(AppRoutes.dashboard, arguments: [3]);
              },
              child: Container(
                margin: EdgeInsets.only(top: 10.h, bottom: 40.h),
                child: Text("Cancel",
                  style: TextStyle(fontSize: 14.sp,
                    fontFamily: 'Alata',
                    fontWeight: FontWeight.normal,
                    color: AppColors.ON_BOARDING_BUTTON_COLOR,),),
              ),
            ),
          ],
        )
    );
  }
}
