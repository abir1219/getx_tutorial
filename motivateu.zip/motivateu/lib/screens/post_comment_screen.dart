import 'package:MotivateU/controllers/comment_controller.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/screens/post_comment_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:like_button/like_button.dart';

import '../controllers/connection_my_list_controller.dart';
import '../res/app_colors.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';
import '../widgets/qconnect_reusable_widgets.dart';

class PostCommentScreen extends StatefulWidget {
  const PostCommentScreen({super.key});

  @override
  State<PostCommentScreen> createState() => _State();
}

class _State extends State<PostCommentScreen> {

  var controller = Get.isRegistered<ConnectionMyListController>()?Get.find<ConnectionMyListController>():Get.put(ConnectionMyListController());

  var commentController = Get.isRegistered<CommentController>()?Get.find<CommentController>():Get.put(CommentController());


  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.maxFinite,
      width: double.maxFinite,
      color: Colors.white,
      child: WillPopScope(
        onWillPop: () async{
          // Get.offNamed(AppRoutes.dashboard,arguments: [3]);
          Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'3'});
          return true;
        },
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            elevation: 0.5,
            actions: [
              controller.postList[Get.arguments[0]].createdBy!.sId == SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)?
              PopupMenuButton<String>(
                onSelected: (String result) {
                  print('Selected: $result');
                },
                offset: Offset(0, 45.h),
                icon: SvgPicture.asset('assets/icons/menu_vertical.svg'),//Icon(Icons.menu),
                itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                  PopupMenuItem<String>(
                    value: 'Delete',
                    child: Text('Delete'),
                    onTap: () => controller.deletePost(controller.postList[Get.arguments[0]].id!,() =>
                        //Get.offNamed(AppRoutes.dashboard,arguments: [3])
                    Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'3'})
                    ),//Utils.showToastMessage('Delete'),
                  ),
                ],
              ):Container(),
            ],
            leading: IconButton(
              onPressed: () =>
                  // Get.offNamed(AppRoutes.dashboard,arguments: [3])
              Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'3'})
              , icon: Icon(Icons.arrow_back_sharp,color: Colors.black,),
            ),
          ),
          body: Column(
            children: [
            Container(
            width: double.maxFinite,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6.0),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 0.5,
                    blurRadius: 0.5,
                    offset: Offset(0.5,0.5),
                  )
                ]
            ),
            margin: EdgeInsets.only(left: 12.w, right: 12.w, top: 4.h,bottom: 2.h),
            padding: EdgeInsets.only(left: 6.w,right: 6.w, top: 10.h,bottom: 10.h),
            child: Column(
              children: [
                postViewHeader(
                    image: 'avatar_img',
                    name: controller.postList[Get.arguments[0]].createdBy!.name!,
                    //'Anand Ranjan',
                    postedOn: controller.postList[Get.arguments[0]].createdAt!),
                Gap(15.h),
                //controller.postList![Get.arguments[0]].postType == "post"?
                reusableSubTitleText(
                    title: controller.postList[Get.arguments[0]].postContent!,
                    fontSize: 14,
                    marginLeft: 0),
                /*:Align(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                        margin: EdgeInsets.only(left: 12.w),
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Text("Topic: "+controller.postList![Get.arguments[0]].question!.type!,textAlign: TextAlign.left,
                                              style: TextStyle(
                                                  fontSize: 14.sp,
                                                  fontWeight: FontWeight.bold,
                                                  color: AppColors.BOTTOM_SHEET_BACKGROUND,
                                                  fontFamily: "Poppins"),),
                                            Text("Click here to view",textAlign: TextAlign.left,
                                              style: TextStyle(
                                                  fontSize: 14.sp,
                                                  color: AppColors.BOTTOM_SHEET_BACKGROUND,
                                                  fontFamily: "Poppins"),),
                                            Text(
                                              'http://motivateu.co.in/${controller.postList![Get.arguments[0]].question!.id!}',
                                              style: TextStyle(
                                                color: Colors.blue,
                                                fontSize: 14.sp,// Set color to blue for a typical link color
                                                decoration: TextDecoration.underline,
                                              ),)
                                          ],
                                        ),
                                      ),
                                    ),*/
                likeCommentCount(likeCount: "${controller.postList[Get.arguments[0]].likesCount}", commentCount: "${controller.postList[Get.arguments[0]].commentsCount}"),
                Container(
                    margin: EdgeInsets.only(top: 15.h),
                    child: Divider(color: AppColors.FIELD_HINT_COLOR.withOpacity(0.8),height: 1,)),//Color(0xFFEEEEEE)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 15.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            height: 24.h,
                            width: 40.w,
                            child: LikeButton(
                              onTap:(isLiked) async{
                                return controller.isLikedLoading.value ? null
                                    :onLikeButtonTapped(isLiked,Get.arguments[0]);
                              },
                              // async{
                              //   controller.likePost(controller.postList[0]![index].id!);
                              // },
                              likeBuilder: (isLiked) => Obx(() => controller.postList[Get.arguments[0]].isLiked!?Icon(Icons.thumb_up,color: AppColors.DEEP_BLUE_COLOR,):Icon(Icons.thumb_up_alt_outlined,)),
                            ),
                          ),
                          Container(
                              margin: EdgeInsets.only(top: 6.h),
                              child: Text("Like",style: TextStyle(fontSize: 11.sp,color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,fontFamily: "Poppins"),)),
                        ],
                      ),
                    ),

                    Obx(() {
                      bool isPostDisliked = controller.postList[Get.arguments[0]].isDisliked ?? false;

                      debugPrint("isPostDisliked=======>${isPostDisliked}");

                      return postInteraction(
                          isPostDisliked ? "disliked" : "dislike",
                          "dislike",
                              () => controller.dislikePost(controller.postList[0].id!, Get.arguments[0]),isPostDisliked
                      );
                    }),
                    //postInteraction("dislike","dislike",() => controller.likePost(controller.postList[0]![index].id!)),
                    // postInteraction("comment","comment",() => Get.offNamed(AppRoutes.postComment)),
                    Container(
                        height: 40.h,
                        // color: Colors.red,
                        child: Center(child: Text("Report Abuse",style: TextStyle(fontFamily: "Poppins",color: Color(0xFF898989),fontSize: 12.sp,fontWeight: FontWeight.w500))))
                  ],
                )
              ],
            ),
          ),
          Expanded(
                  child: Container(
                    color: Colors.white,
                    child: NotificationListener<OverscrollIndicatorNotification>(
                      onNotification: (OverscrollIndicatorNotification notification) {
                        notification.disallowIndicator();
                        return true;
                      },
                      child:PostCommentListScreen(postId: controller.postList[Get.arguments[0]].id!)
                    ),
              )),
              Container(
                // height: 85.h,
                padding: EdgeInsets.only(top: 10.h,bottom: 10.h),
                width: double.maxFinite,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2.w),
                    color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR),
                child: Center(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Expanded(
                          child: Container(
                            // height: 65,
                            margin: EdgeInsets.symmetric(horizontal: 15.w),
                            padding: EdgeInsets.only(left: 10.w),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(30.w)),
                            child: TextField(
                              controller:
                              commentController.commentController.value,
                              onChanged: (value) {
                                // value.length>0?commentController.commentType.value="inner":commentController.commentType.value="main";
                              },
                              maxLines: null,
                              decoration: InputDecoration(
                                hintText: "Type comment...",
                                hintStyle: TextStyle(
                                    color: AppColors.FIELD_HINT_COLOR,
                                    // fontFamily: 'Poppins',
                                    fontFamily: 'Alata',
                                    fontSize: 14.sp),
                                border: InputBorder.none,
                                focusColor: Colors.transparent,
                                focusedBorder: InputBorder.none,
                                enabledBorder: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                        GestureDetector(
    // Get.arguments[0]].id!,Get.isRegistered<CommentController>()?Get.find<CommentController>().commentController.value:Get.put(CommentController().commentController.value)
                          onTap: () => commentController.postComment(controller.postList[Get.arguments[0]].id!,commentController.commentController.value.text.toString()),
                          child: Container(
                            height: 45.h,
                            margin: EdgeInsets.only(right: 5.w),
                            child: Center(
                                child: Icon(Icons.send,
                                    color: Colors.white, size: 32.w)),
                          ),
                        )
                      ],
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget likeCommentCount(
      {required String likeCount, required String commentCount}) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(top: 20.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          reusableSubTitleText(
              title: "${likeCount} likes", fontSize: 12, marginLeft: 0),
          reusableSubTitleText(
              title: "${commentCount} comments", fontSize: 12, marginLeft: 0),
        ],
      ),
    );
  }

  Future<bool> onLikeButtonTapped(bool isLiked,int index) async{
    controller.likePost(controller.postList.value[index].id!,index,isLiked);
    return !isLiked;
  }
}
