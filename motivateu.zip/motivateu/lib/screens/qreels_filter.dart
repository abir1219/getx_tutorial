import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

import '../controllers/reels_filter_controller.dart';
import '../utils/utils.dart';
import '../widgets/filter_widget.dart';

class QReelsFilter extends StatelessWidget {
  const QReelsFilter({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      body: RefreshIndicator(
        onRefresh: () async{
          Utils.showToastMessage("Refresh");
          await _refreshData();
          /*setState(() {
          selectedCount = -1;
          Get.find<ReelsFilterController>().getAllSubjects();

          Get.find<ReelsFilterController>().chapterId.value = "";
          Get.find<ReelsFilterController>().topicId.value = "";
          Get.find<ReelsFilterController>().subjectId.value = "";

          Get.find<ReelsFilterController>().keywordController.value.text = "";
          Get.find<ReelsFilterController>().topicController.value.text = "";
          Get.find<ReelsFilterController>().chapterController.value.text = "";
        });*/
        },
        child: Container(
          height: double.maxFinite,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("assets/icons/login_bg.png"),
                  fit: BoxFit.cover
              )),
          child: FilterWidget(),
        ),
      ),
    ));
  }

  Future<void> _refreshData() async {
    try {
      // Reset selectedCount and fetch new data
      Get.find<ReelsFilterController>().selectedIndex.value = -1;
      await Get.find<ReelsFilterController>().getAllSubjects();
      Get.find<ReelsFilterController>().chapterId.value = "";
      Get.find<ReelsFilterController>().topicId.value = "";
      Get.find<ReelsFilterController>().subjectId.value = "";
      Get.find<ReelsFilterController>().keywordController.value.text = "";
      Get.find<ReelsFilterController>().topicController.value.text = "";
      Get.find<ReelsFilterController>().chapterController.value.text = "";
    } catch (e) {
      // Handle any errors that occur during data refresh
      debugPrint("Error during data refresh: $e");
    }
  }
}

