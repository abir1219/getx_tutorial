import 'package:MotivateU/helper/api_end_points.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../controllers/connection_list_controller.dart';
import '../models/sent_pending_model.dart';

class SentPendingScreen extends StatefulWidget {
  final String type;
  const SentPendingScreen({super.key, required this.type});

  @override
  State<SentPendingScreen> createState() => _SentPendingScreenState();
}

class _SentPendingScreenState extends State<SentPendingScreen> {

  var controller = Get.find<ConnectionListController>();
  int pageNo = 1;
  ScrollController _scrollController = ScrollController();

  /*@override
  void initState() {
    super.initState();
    controller.getRequestList(pageNo: 1,type: widget.type);
    _scrollController.addListener(_scrollListener);
  }*/

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    // Utils.showToastMessage("hii");
    debugPrint("_scrollController.position====>${controller.myListModel.value.pagination!.totalRecord} and ${controller.sentPendingList!.length}");
    if (_scrollController.offset >=
        _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      // Reach the end of the list, load more data
      if (controller.myListModel.value.pagination!.totalRecord !=
          controller.sentPendingList!.length) {
        setState(() {
          pageNo++;
        });
        controller.getMoreRequestList(pageNo: pageNo,type: widget.type);
        //_loadMoreData();
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    controller.getRequestList(pageNo: 1,type: widget.type);
    _scrollController.addListener(_scrollListener);

    return Scaffold(
        body: RefreshIndicator(
          color: Colors.black,
          onRefresh: () async {
            setState(() {
              pageNo = 1;
            });
            controller.getConnection(1);
          },
          child: Obx(() => controller.isLoading.value
              ? Container(
            width: double.maxFinite,
            color: Colors.white,
            margin: EdgeInsets.symmetric(vertical: 10.h),
            child: Center(
              child: SizedBox(
                height: 24.h,
                width: 24.w,
                child: CircularProgressIndicator(
                  color: Colors.black,
                ),
              ),
            ),
          )
              : Obx(() => controller.sentPendingList!.length > 0
                ? Container(
                            margin: EdgeInsets.only(top: 10.h, bottom: 15.h),
                            padding: EdgeInsets.all(6.sp),
                            decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Color(0xFFF7F7F7))),
                            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Column(
                      children: [
                        Container(
                            alignment: Alignment.centerLeft,
                            margin: EdgeInsets.only(top: 10.h, bottom: 15.h),
                            child: Text(
                              "Connections:",
                              style: TextStyle(
                                  fontFamily: 'Alata',
                                  color: Colors.black,
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.bold),
                            )),
                        Scrollbar(
                          child: NotificationListener<
                              OverscrollIndicatorNotification>(
                            onNotification:
                                (OverscrollIndicatorNotification notification) {
                              notification.disallowIndicator();
                              return true;
                            },
                            child: ListView.builder(
                              shrinkWrap: true,
                              controller: _scrollController,
                              itemBuilder: (context, index) {
                                //debugPrint("controller.connectionList.length==>${controller.connectionList![index].name} and ${controller.connectionList![index].name}");
                                return Column(
                                  children: [
                                    Obx(() {
                                      return reusableGroupConnection(
                                          controller.sentPendingList![index],
                                          index
                                      );
                                    }),
                                    index + 1 !=
                                        controller.sentPendingList!.length
                                        ? Divider(
                                      color: Colors.grey.withOpacity(0.5),
                                      height: 1.h,
                                    )
                                        : Container()
                                  ],
                                );
                              },
                              itemCount: controller.sentPendingList!.length,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  controller.isMoreLoading.value
                      ? Container(
                    width: double.maxFinite,
                    color: Colors.white,
                    margin: EdgeInsets.symmetric(vertical: 10.h),
                    child: Center(
                      child: SizedBox(
                        height: 24.h,
                        width: 24.w,
                        child: CircularProgressIndicator(
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ): Container()
                ],
                            ),
                          )
                : Container(
                        child: Center(
                          child: Text("No records found"),
                        ),
                          ),
              )),
        ));
  }

  Widget reusableGroupConnection(
      Results connection, int index) {
    // debugPrint("connection.isConnection! && connection.requestStatus==none=======>${!connection.isConnection! && connection.requestStatus=="none"}");
    // debugPrint("connection.isConnection! && connection.requestStatus==request=======>${!connection.isConnection! && connection.requestStatus=="request"}");
    // debugPrint("connection.isConnection! && connection.requestStatus==send=======>${!connection.isConnection! && connection.requestStatus=="send"}");
    String avatar = widget.type == "self"?connection.receiverProfile!.avatar!:connection.senderProfile!.avatar!;
    String name = widget.type == "self"?connection.receiverProfile!.name!:connection.senderProfile!.name!;

    return Container(
      width: double.maxFinite,
      color: Colors.transparent,
      margin: EdgeInsets.symmetric(vertical: 12.h, horizontal: 10.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            // alignment:Alignment.centerLeft,
            //color: Colors.red,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [

                avatar != ""
                    ? CircleAvatar(
                  // backgroundImage: NetworkImage("${ApiEndPoints.IMAGE_URL}${result.profile![position].avatar}"),
                  // radius: 50.sp,
                  backgroundColor: Colors.transparent, // Add this to make the background transparent
                  child: ClipOval(
                    child: Image.network(
                      "${ApiEndPoints.IMAGE_URL}${avatar}",
                      fit: BoxFit.cover, // You can adjust the fit as per your requirements
                      width: 50.sp, // Adjust the width and height as needed
                      height: 50.sp,
                    ))): Container(
                  height: 20.h,
                  width: 20.w,
                  margin: EdgeInsets.only(
                    right: 12.w,
                  ),
                  child: Center(
                    child: Icon(Icons.person),
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(bottom: 4.h, left: 12.w),
                  //alignment:Alignment.centerLeft,
                  // color: Colors.amber,
                  child: Text(
                    "${name}",
                    style: TextStyle(
                        color: AppColors.TITLE_TEXT_BLACK,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.normal,
                        fontFamily: "Alata"),
                  ),
                ),
              ],
            ),
          ),

            GestureDetector(
              onTap: () => controller.actionAgainstConnectionRequest(
                  connection.sId, 'cancel',() => controller.getRequestList(pageNo: 1,type: "self")),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GestureDetector(
                    onTap: () => controller.actionAgainstConnectionRequest(
                        connection.sId, 'decline',() => null),
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      height: 34.h,
                      width: 34.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100.sp),
                        // color: Colors.red
                      ),
                      child: SvgPicture.asset(
                        "assets/icons/crossmark.svg",
                      ),
                    ),
                  ),
                  Gap(10.w),
                  GestureDetector(
                    onTap: () => controller.actionAgainstConnectionRequest(
                        connection.sId, 'accept',() => null),
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      height: 34.h,
                      width: 34.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100.sp),
                        //color: Colors.blueAccent
                      ),
                      child: SvgPicture.asset(
                        "assets/icons/tickmark.svg",
                      ),
                    ),
                  )
                ],
              )


              /*Container(
                  padding: EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                  margin: EdgeInsets.only(right: 10.w),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      border: Border.all(color: AppColors.DEEP_BLUE_COLOR)),
                  child: Center(
                    child: Text(
                      "Cancel Request",
                      style: TextStyle(
                          fontSize: 14.sp,
                          color: AppColors.DEEP_BLUE_COLOR,
                          fontFamily: 'Alata'),
                    ),
                  )),*/
            )
        ],
      ),
    );
  }
}
