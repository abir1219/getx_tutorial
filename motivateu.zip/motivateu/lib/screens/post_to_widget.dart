import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';

class PostToWidget extends StatefulWidget {
  const PostToWidget({super.key});

  @override
  State<PostToWidget> createState() => _PostToWidgetState();
}

class _PostToWidgetState extends State<PostToWidget> {

  // var controller = Get.find<PostToController>();

  @override
  void initState() {
    super.initState();
    createGroupList();
  }

  List<String> groupList=['Group 1','Group 2','Group 3'];
  List<String> connectionList=['Connection 1','Connection 2','Connection 3','Connection 4','Connection 5','Connection 6','Connection 7'];

  RxList<bool> myGroupSelection = <bool>[].obs;
  RxList<bool> myConnectionSelection = <bool>[].obs;

  void createGroupList(){
    for(int i=0;i<groupList.length;i++){
      myGroupSelection[i] = false;
    }
    for(int j=0;j<connectionList.length;j++){
      myConnectionSelection[j] = false;
    }
    setState(() {

    });
  }



  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 10.h,bottom: 15.h),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          color: Colors.white,
          border: Border.all(
              color: Color(0xFFF7F7F7)
          )
      ),
      width: double.maxFinite,
      child: Container(
        alignment: Alignment.centerLeft,
        margin:EdgeInsets.only(top: 10,left: 6.w,right: 6.w),
        child: Column(
          children: [
            Text("Group",style: TextStyle(fontFamily: 'Alata',color: Colors.black,fontSize: 18.sp,fontWeight: FontWeight.bold),),
            Expanded(
              child: ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) => reusableGroup('gr1',index.toString(),false,() {
                  }),itemCount: 2,),
            )
          ],
        ),
      ),
    );
  }

  Widget reusableGroup(String groupName,String position,bool isSelected,void Function() func) {
    return GestureDetector(
      onTap: () => func(),
      child: Container(
        width: double.maxFinite,
        color: Colors.transparent,
        margin: EdgeInsets.symmetric(vertical: 4.h),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              child: Row(
                children: [
                  Container(
                    height: 20.h,
                    width: 20.w,
                    margin: EdgeInsets.only(
                      right: 12.w,
                    ),
                    child: Center(
                      child: Icon(Icons.group),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(bottom: 4.h),
                    child: Text(
                      "$groupName",
                      style: TextStyle(
                          color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Alata"
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
                margin: EdgeInsets.only(
                  right: 12.w,
                ),
                height: 22.h,
                width: 22.w,
                child: isSelected?SvgPicture.asset("assets/icons/seleted_grp.svg"):Icon(Icons.circle_outlined,color: Colors.grey,)
            ),
          ],
        ),
      ),
    );
  }
}
