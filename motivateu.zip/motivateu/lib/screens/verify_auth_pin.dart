import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../controllers/get_profile_controller.dart';
import '../main.dart';
import '../models/get_profile_model.dart';
import '../res/app_colors.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class VerifyAuthPin extends StatefulWidget {
  final int? position;
  final Result? result;
  final String? type;
  const VerifyAuthPin({super.key, this.position, this.result, this.type});

  @override
  State<VerifyAuthPin> createState() => _VerifyAuthPinState();
}

class _VerifyAuthPinState extends State<VerifyAuthPin> {
  late GetProfileController controller;

  // late IO.Socket _socket;

  @override
  void initState() {
    super.initState();
    controller = Get.isRegistered<GetProfileController>()?Get.find<GetProfileController>():Get.put(GetProfileController());
  }

  @override
  void dispose() {
    super.dispose();
    debugPrint("!!!!!!!!!VERIFY_DISPOSE!!!!!!!!!!");
    // _socket.io..disconnect();//..connect()
    // _socket.dispose();
  }

  /*@override
  void dispose() {
    super.dispose();
    controller.dispose();
  }*/


  @override
  Widget build(BuildContext context) {
    return Obx(() => !controller.isShowChangePinScreen.value?AlertDialog(
        title: Text('Enter your authentication pin',style: TextStyle(fontSize: 14.sp,fontFamily: "Alata",color: Colors.blue,fontWeight: FontWeight.bold),),
        alignment: Alignment.center,
        content: Container(
          height: 90.h,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                vertical: 8.0,
                horizontal: 30,
              ),
              child: Obx(() => controller.isVerifyLoading.value?
                  SizedBox(
                    height: 24.h,
                    width: 24.w,
                    child: CircularProgressIndicator(color: Colors.black,),
                  )
                  :PinCodeTextField(
                  appContext: context,
                  pastedTextStyle: TextStyle(
                      color: AppColors.OTP_PIN_VIEW_COLOR,
                      fontWeight: FontWeight.bold,
                      fontSize: 15.sp),
                  length: 4,
                  animationType: AnimationType.fade,
                  pinTheme: PinTheme(
                      shape: PinCodeFieldShape.box,
                      borderRadius: BorderRadius.circular(5),
                      fieldHeight: 50.h,
                      fieldWidth: 40.w,
                      activeFillColor: Colors.transparent,
                      inactiveFillColor: Colors.transparent,
                      selectedFillColor: Colors.transparent,
                      activeColor: AppColors.OTP_PIN_VIEW_COLOR,
                      inactiveColor: AppColors.OTP_PIN_VIEW_COLOR,
                      selectedColor: AppColors.OTP_PIN_VIEW_COLOR,
                      activeBorderWidth: .8,
                      selectedBorderWidth: .8,
                      inactiveBorderWidth: .8),
                  cursorColor: AppColors.OTP_PIN_VIEW_COLOR,
                  animationDuration: const Duration(milliseconds: 300),
                  enableActiveFill: true,
                  keyboardType: TextInputType.number,
                  onCompleted: (value) {
                    debugPrint("Completed");
                    /*if(widget.type! == "switch"){
                      if(socket.connected)
                        socket.io.disconnect();

                      _connectionSocket();
                    }*/
                    controller.verifyAuthPin(value,widget.position,widget.result,widget.type!);
                  },
                  onChanged: (value) {
                    debugPrint(value);

                  },
                  beforeTextPaste: (text) {
                    debugPrint("Allowing to paste $text");
                    return true;
                  },
                ),
              ),
            ),
          ),
        ),
      ):
      AlertDialog(
        title: Text('Enter your new authentication pin',style: TextStyle(fontSize: 14.sp,fontFamily: "Alata",color: Colors.blue,fontWeight: FontWeight.bold),),
        alignment: Alignment.center,
        content: Container(
          height: 90.h,
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(
                vertical: 8.0,
                horizontal: 30,
              ),
              child: Obx(() => controller.isVerifyLoading.value?
              SizedBox(
                height: 24.h,
                width: 24.w,
                child: CircularProgressIndicator(color: Colors.black,),
              )
                  :PinCodeTextField(
                appContext: context,
                pastedTextStyle: TextStyle(
                    color: AppColors.OTP_PIN_VIEW_COLOR,
                    fontWeight: FontWeight.bold,
                    fontSize: 15.sp),
                length: 4,
                animationType: AnimationType.fade,
                pinTheme: PinTheme(
                    shape: PinCodeFieldShape.box,
                    borderRadius: BorderRadius.circular(5),
                    fieldHeight: 50.h,
                    fieldWidth: 40.w,
                    activeFillColor: Colors.transparent,
                    inactiveFillColor: Colors.transparent,
                    selectedFillColor: Colors.transparent,
                    activeColor: AppColors.OTP_PIN_VIEW_COLOR,
                    inactiveColor: AppColors.OTP_PIN_VIEW_COLOR,
                    selectedColor: AppColors.OTP_PIN_VIEW_COLOR,
                    activeBorderWidth: .8,
                    selectedBorderWidth: .8,
                    inactiveBorderWidth: .8),
                cursorColor: AppColors.OTP_PIN_VIEW_COLOR,
                animationDuration: const Duration(milliseconds: 300),
                enableActiveFill: true,
                keyboardType: TextInputType.number,
                onCompleted: (value) {
                  debugPrint("Completed");
                  controller.changePin(value);
                },
                onChanged: (value) {
                  debugPrint(value);

                },
                beforeTextPaste: (text) {
                  debugPrint("Allowing to paste $text");
                  return true;
                },
              ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /*_connectionSocket(){
    print("SOCket->${socket.connected}");
    socket.io.connect();
    socket.onConnect((data) => print("Connection Established Profile"));
    socket.emit('connected-student',SharedPreferencesUtils.getString(AppConstants.PROFILE_ID));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("SOCket->${socket.json.connected}");
    //_socket.io..disconnect()..connect();
    print("SOCket->${socket.json.connected}");
    print("Socket Connected: ${socket.connected}");
  }*/
}
