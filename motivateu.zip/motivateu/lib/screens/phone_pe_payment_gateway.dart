import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:gap/gap.dart';
import 'package:phonepe_payment_sdk/phonepe_payment_sdk.dart';

class PhonePePaymentGateway extends StatefulWidget {
  const PhonePePaymentGateway({super.key});

  @override
  State<PhonePePaymentGateway> createState() => _PhonePePaymentGatewayState();
}

class _PhonePePaymentGatewayState extends State<PhonePePaymentGateway> {

  String environmentValue = "UAT_SIM";
      String appId = "";
  String merchantId = "PGTESTPAYUAT";
  bool enableLogging = true;

  String checksum = "";
  String saltKey = "099eb0cd-02cf-4e2a-8aca-3e6c6aff0399";
  String saltIndex = "1";
  String callbackUrl = "https://www.google.com/";

  String body = "";
  String apiEndPoint = "/pg/v1/pay";
  Object? result;

  getCheckSum(){
    final requestData = {
      "merchantId": merchantId,
        "merchantTransactionId": "eeee",
      "merchantUserId": "MUID123",
      "amount": 10000,
      "callbackUrl": callbackUrl,//"https://webhook.site/callback-url",
      "mobileNumber": "9999999999",
      "paymentInstrument": {
        "type": "PAY_PAGE"
      }
    };

    String base64Body = base64.encode(utf8.encode(json.encode(requestData)));
   checksum = '${sha256.convert(utf8.encode(base64Body+apiEndPoint+saltKey)).toString()}###$saltIndex';
   //  checksum = "${sha256(base64Body + apiEndPoint + saltKey)}###$saltIndex";
    debugPrint("checksum==>$checksum");

    return base64Body;
  }

  @override
  void initState() {
    super.initState();
    phonePeInit();
    body = getCheckSum().toString();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      body: Column(
        children: [
          ElevatedButton(onPressed: () {
            startPgTransaction();
          },
          child: Text("Pay Now"),),
          Gap(20),
          Text("Result : $result")
        ],
      ),
    ));
  }

  void phonePeInit() {
    PhonePePaymentSdk.init(environmentValue, appId, merchantId, enableLogging)
        .then((val) => {
      setState(() {
        result = 'PhonePe SDK Initialized - $val';
      })
    })
        .catchError((error) {
      handleError(error);
      return <dynamic>{};
    });
  }

  void startPgTransaction() async{
    try {
      var response = PhonePePaymentSdk.startPGTransaction(
          body, callbackUrl, checksum, {}, apiEndPoint, "");
      response
          .then((val) => {
        setState(() {
          if(val != null){
            String status = val['status'].toString();
            String error = val['error'].toString();

            if(status == 'SUCCESS'){

            }else{
              result = "Flow complete - status : $status and error : $error ";
            }
          }else{
            result = "Flow incomplete";
          }
          //result = val;
        })
      })
          .catchError((error) {
        handleError(error);
        return <dynamic>{};
      });
    } catch (error) {
      handleError(error);
    }
  }

  void handleError(error) {
    setState(() {
      result = {'error':error};
    });
  }
}
