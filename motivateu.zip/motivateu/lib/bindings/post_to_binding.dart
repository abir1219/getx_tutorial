import 'package:get/get.dart';

import '../controllers/on_boarding_controller.dart';
import '../controllers/post_to_controller.dart';

class PostToBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PostToController>(() =>PostToController(),
        fenix: true);
  }
}
