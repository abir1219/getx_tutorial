import 'package:get/get.dart';

import '../controllers/performance_controller.dart';

class DashboardBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut<PerformanceController>(() => PerformanceController());
  }

}