import 'package:MotivateU/controllers/chat_controller.dart';
import 'package:get/get.dart';

import '../controllers/reels_filter_controller.dart';


class ReelsFilterBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut<ReelsFilterController>(() => ReelsFilterController(),fenix: true);
  }

}