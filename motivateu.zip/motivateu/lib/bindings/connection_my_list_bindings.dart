import 'package:get/get.dart';

import '../controllers/connection_my_list_controller.dart';

class ConnectionMyListBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut<ConnectionMyListController>(() => ConnectionMyListController());
  }

}