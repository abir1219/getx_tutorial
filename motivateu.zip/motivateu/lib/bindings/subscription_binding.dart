import 'package:MotivateU/controllers/subscription_controller.dart';
import 'package:get/get.dart';

import '../controllers/sign_up_controller.dart';


class SubscriptionBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut<SubscriptionController>(() => SubscriptionController(),fenix: true);
  }

}