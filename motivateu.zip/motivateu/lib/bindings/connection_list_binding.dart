import 'package:get/get.dart';

import '../controllers/connection_list_controller.dart';

class ConnectionListBinding extends Bindings{
  
  @override
  void dependencies() {
    Get.lazyPut<ConnectionListController>(() => ConnectionListController());
  }
  
}