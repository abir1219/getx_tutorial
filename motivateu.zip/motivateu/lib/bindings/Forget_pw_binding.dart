import 'package:MotivateU/controllers/forgetPw_controller.dart';
import 'package:get/get.dart';

class ForgetPwBinding extends Bindings{

  @override
  void dependencies() {
    Get.lazyPut<ForgetPwController>(() => ForgetPwController());
  }

}