import 'package:get/get.dart';

import '../controllers/hots_topics_controller.dart';

class HotsTopicBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut<HotsTopicsController>(() => HotsTopicsController());
  }
}