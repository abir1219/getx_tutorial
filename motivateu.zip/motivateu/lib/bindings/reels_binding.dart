import 'package:MotivateU/controllers/reels_controller_old.dart';
import 'package:get/get.dart';

import '../controllers/reels_controller.dart';

class ReelsBinding extends Bindings{
  @override
  void dependencies() {
    // Get.lazyPut<ReelsControllerOld>(() => ReelsControllerOld(),fenix: true);
    Get.lazyPut<ReelsController>(() => ReelsController(),fenix: true);
  }
}