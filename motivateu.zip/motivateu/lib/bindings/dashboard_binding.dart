import 'package:MotivateU/controllers/dashboard_controller.dart';
import 'package:get/get.dart';

import '../controllers/on_boarding_controller.dart';

class DashboardBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut<DashboardController>(() => DashboardController(),fenix: true);
  }

}