import 'package:MotivateU/controllers/add_profile_controller.dart';
import 'package:get/get.dart';

class AddProfileBinding extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut<AddProfileController>(() => AddProfileController());
  }

}