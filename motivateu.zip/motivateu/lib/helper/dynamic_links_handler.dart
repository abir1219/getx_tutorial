import 'dart:developer';

import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';

class DynamicLinksWidgetHandler extends StatefulWidget {
  const DynamicLinksWidgetHandler({
    super.key,
    required this.child,
  });

  final Widget child;

  @override
  State<DynamicLinksWidgetHandler> createState() =>
      _DynamicLinksWidgetHandlerState();
}

class _DynamicLinksWidgetHandlerState extends State<DynamicLinksWidgetHandler> {
  @override
  void initState() {
    super.initState();
    _initDynamicLinks();
  }
// _initDynamicLinks - this is from where the dynamic link will be launched

  Future<void> _initDynamicLinks() async {
    final data = await FirebaseDynamicLinks.instance.getInitialLink();
    final Uri? deepLink = data?.link;
    _handleDynamicLink(deepLink);

    FirebaseDynamicLinks.instance.onLink.listen((dynamicLink) {
      final uri = dynamicLink.link;
      _handleDynamicLink(uri);
    }).onError((e) {
      print('onLinkError');
      print(e.message);
    });
  }
// _handleDynamicLink - this is where you handle the link and parse it

  void _handleDynamicLink(Uri? deepLink) async {
    log('_handleDynamicLink:$deepLink');
    final code = deepLink?.queryParameters['invitedby'];
    if (code == null) return;
    // save code to backend
    log(code);
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}