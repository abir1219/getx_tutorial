import 'package:MotivateU/widgets/qconnect_reusable_widgets.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';
import '../res/routes/app_routes.dart';

Widget chatMembers(
    {required String image,
    required String name,
    required String lastMsg,
    required String lastMsgTime,
      required String roomID,
      required String participantName,
    required void Function() func}) {
  return GestureDetector(
    onTap: () => Get.offNamed(AppRoutes.OneToOneChat, arguments: [roomID,participantName]),
    child: Container(
      height: 60.h,
      color: Colors.transparent,
      margin: EdgeInsets.symmetric(vertical: 10.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundImage: AssetImage("assets/icons/$image.png"),
                radius: 15,
              ),
              Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    reusableTitleText(name),
                    reusableSubTitleText(title: lastMsg, fontSize: 13),
                  ],
                ),
              )
            ],
          ),
          Container(
            child: Text(
              lastMsgTime,
              style: TextStyle(
                  fontSize: 10.sp,
                  color: AppColors.TITLE_TEXT_BLACK.withOpacity(0.38),
                  fontFamily: "Poppins"),
            ),
          )
        ],
      ),
    ),
  );
}
