import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';

import '../res/app_colors.dart';

Widget reusableTitleText(String title) {
  return Container(
    margin: EdgeInsets.only(left: 12.w),
    child: Text(
      title,
      style: TextStyle(
          fontSize: 16.sp,
          color: AppColors.BOTTOM_SHEET_BACKGROUND,
          fontFamily: "Poppins"),
    ),
  );
}

Widget reusableSubTitleText(
    {required String title, int fontSize = 14, int marginLeft = 12}) {
  return Align(
    alignment: Alignment.centerLeft,
    child: Container(
      margin: EdgeInsets.only(left: marginLeft.w),
      //color: Colors.red,
      child: Text(
        title,
        textAlign: TextAlign.left,
        style: TextStyle(
            fontSize: fontSize.sp,
            color: AppColors.BOTTOM_SHEET_BACKGROUND,
            fontFamily: "Poppins"),
      ),
    ),
  );
}

Widget reusableIcon(IconData icon, void Function() func) {
  return GestureDetector(
    onTap: func,
    child: Container(
      height: 28.h,
      width: 28.w,
      // color: Colors.red,
      margin: EdgeInsets.only(left: 6.w, right: 6.w),
      child: Center(
        child: Icon(
          icon,
          color: Color(0xFFB8C2C6),
        ),
      ),
    ),
  );
}

Widget reusableGroup(
    BuildContext context, String title, bool isSelected, VoidCallback func) {
  debugPrint("isSelected====>$isSelected");
  return Container(
    padding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
    margin: EdgeInsets.only(left: 4.w, right: 4.w, bottom: 4, top: 4),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(8),
      color: AppColors.SLIDER_DOTTED_COLOR.withOpacity(0.3),
    ),
    child: InkWell(
      onTap: func,
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Container(
          height: 22.h,
          width: 22.w,
          child: isSelected
              ? SvgPicture.asset("assets/icons/tick.svg")
              : Icon(Icons.circle_outlined, color: Colors.grey),
        ),
        title: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 20.h,
              width: 20.w,
              margin: EdgeInsets.only(right: 12.w),
              child: Center(
                child: Icon(
                  Icons.group,
                  color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,
                ),
              ),
            ),
            Container(
              height: 20.h,
              alignment: Alignment.center,
              child: Text(
                "$title ",
                style: TextStyle(
                  color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,
                  fontSize: 14.sp,
                  fontWeight: FontWeight.bold,
                  fontFamily: "Alata",
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

Widget postViewHeader(
    {required String image, required String name, required String postedOn}) {
  // String originalDateString = '2023-10-28T08:08:11.147Z';
  debugPrint("postedOn=>>>>>>$postedOn");
  DateTime originalDate = DateTime.parse(postedOn);

  String formattedDate = DateFormat("d MMM ''yy").format(originalDate);
  debugPrint("formattedDate=>>>>>>$formattedDate");
  return Container(
    height: 35.h,
    // margin: EdgeInsets.only(left: 6.w,right: 6.w),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          height: 32.h,
          width: 32.w,
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                "assets/icons/$image.png",
              ),
              fit: BoxFit.contain,
            ),
            borderRadius: BorderRadius.circular(100.w),
          ),
        ),
        Container(
          width: 300.w,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              reusableSubTitleText(title: name, fontSize: 12),
              reusableSubTitleText(
                  title: "posted on ${formattedDate} ", fontSize: 12),
            ],
          ),
        ),
      ],
    ),
  );
}

Widget likeCommentCount(
    {required String likeCount, required String commentCount}) {
  // debugPrint("!!!!!!!likeCount!!!!!!$likeCount");
  // debugPrint("!!!!!!!commentCount!!!!!!$commentCount");
  return Container(
    width: double.maxFinite,
    margin: EdgeInsets.only(top: 20.h),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        reusableSubTitleText(
            title:
                "${likeCount} ${int.parse(likeCount) > 1 ? "likes" : "like"}",
            fontSize: 12,
            marginLeft: 0),
        reusableSubTitleText(
            title: "${commentCount} ${int.parse(commentCount) > 1 ? "comments" : "comment"}", fontSize: 12, marginLeft: 0),
      ],
    ),
  );
}

Widget postInteraction(String icon, String title, void Function() func,
    [bool isDisliked = false]) {
  return GestureDetector(
    onTap: () => func(),
    child: Container(
      margin: EdgeInsets.only(top: 15.h),
      // color: Colors.grey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            // color: Colors.red,
            height: 24.h,
            width: 24.w,
            child: SvgPicture.asset("assets/icons/$icon.svg",
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(
                    !isDisliked ? Colors.black : AppColors.DEEP_BLUE_COLOR,
                    BlendMode.srcIn)),
          ),
          Container(
              margin: EdgeInsets.only(top: 6.h),
              child: Text(
                title,
                style: TextStyle(
                    fontSize: 11.sp,
                    color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,
                    fontFamily: "Poppins"),
              ))
        ],
      ),
    ),
  );
}
