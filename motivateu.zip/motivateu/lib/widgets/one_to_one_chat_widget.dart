import 'package:MotivateU/controllers/chat_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';
import 'chat_screen_widget.dart';

class OneToOneChatWidget extends StatelessWidget {
  final String roomId;
  const OneToOneChatWidget({super.key, required this.roomId});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 725.h,
      child: Column(
        children: [
          ChatScreenWidget(roomId: roomId,),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              // height: 85.h,
              padding: EdgeInsets.only(top: 10.h,bottom: 10.h),
              width: double.maxFinite,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2.w),
                  color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR),
              child: Center(
                  child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Container(
                      // height: 65,
                      margin: EdgeInsets.symmetric(horizontal: 15.w),
                      padding: EdgeInsets.only(left: 10.w),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30.w)),
                      child: TextField(
                        maxLines: null,
                        controller: Get.find<ChatController>().messageController.value,
                        decoration: InputDecoration(
                          hintText: "Type message...",
                          hintStyle: TextStyle(
                              color: AppColors.FIELD_HINT_COLOR,
                              fontFamily: 'Poppins',
                              fontSize: 14.sp),
                          border: InputBorder.none,
                          focusColor: Colors.transparent,
                          focusedBorder: InputBorder.none,
                          enabledBorder: InputBorder.none,
                        ),
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Get.find<ChatController>().sendChat(roomId),//debugPrint("--------send-----------"),
                    child: Container(
                      height: 45.h,
                      margin: EdgeInsets.only(right: 5.w),
                      child: Center(
                          child: Icon(Icons.send,
                              color: Colors.white, size: 32.w)),
                    ),
                  )
                ],
              )),
            ),
          )
        ],
      ),
    );
  }
}
