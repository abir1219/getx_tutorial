import 'dart:io';

import 'package:MotivateU/controllers/sign_up_controller.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/screens/terms_condition.dart';
import 'package:MotivateU/widgets/reusable_sign_up_widget.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../res/app_colors.dart';
import '../utils/utils.dart';

class SignUpWidget extends StatefulWidget {
  const SignUpWidget({super.key});

  @override
  State<SignUpWidget> createState() => _SignUpWidgetState();
}

class _SignUpWidgetState extends State<SignUpWidget> {
  var controller = Get.find<SignUpController>();
  File? images;

  final _scrollController = ScrollController();

  Future pickImageGallery() async {
    Utils.showToastMessage("Gallery");
    try {
      final image = await ImagePicker().pickImage(source: ImageSource.gallery);

      if (image == null) return;
      final imageTemp = File(image.path);
      setState(() {
        images = imageTemp;
        debugPrint("Image Gallery=>$images");
      });

      //setState(() => this.image = imageTemp);
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }

  Future pickImageCamera() async {
    Utils.showToastMessage("Camera");
    try {
      final image = await ImagePicker().pickImage(source: ImageSource.camera);

      if (image == null) return;

      final imageTemp = File(image.path);
      setState(() {
        images = imageTemp;
        debugPrint("Image Camera=>$images");
      });
      // setState(() => this.image = imageTemp);
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }

  void checkValidation() {
    RegExp regex = RegExp(r'^[0-9]+$');
    final RegExp emailRegex = RegExp(r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$');
    // debugPrint("regex-->$regex");
    debugPrint(
        "regex-->${regex.hasMatch(controller.authPinController.value.text)}");

    if (controller.nameController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter name");
    } else if (controller.passwordController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter password");
    } else if (controller.cnfrmPasswordController.value.text
        .toString()
        .isEmpty) {
      Utils.showToastMessage("Enter confirm password");
    } else if (controller.authPinController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter Authentication Pin");
    } else if (controller.authPinController.value.text.length != 4) {
      Utils.showToastMessage("Authentication Pin must be of 4 numbers");
    } else if (!regex.hasMatch(controller.authPinController.value.text)) {
      Utils.showToastMessage("Authentication Pin can only take numbers");
    } else if (controller.addressController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter your address");
    } else if (controller.otherCityController.value.text.toString().isEmpty &&
        controller.cityController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter your city");
    }else if (controller.stateController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter your state");
    }else if (controller.pinController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter your pin code");
    }
    //else if(controller.emailController.value.text.toString().isEmpty){}
    else if (controller.classController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter class");
    } else if (controller.otherSchoolController.value.text.toString().isEmpty &&
        controller.schoolController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter school");
    } else if (controller.mediumController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter medium");
    } else if (controller.boardController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter board");
    } else if (controller.passwordController.value.text.toString() !=
        controller.cnfrmPasswordController.value.text.toString()) {
      debugPrint("Password->${controller.passwordController.value.text}");
      debugPrint("CPassword->${controller.cnfrmPasswordController.value.text}");
      Utils.showToastMessage("Password mismatch");
    } else if (controller.emailController.value.text.isNotEmpty &&
        !emailRegex.hasMatch(controller.emailController.value.text)) {
      Utils.showToastMessage("Invalid email address");
    }else if (!controller.isSelectTnC.value) {
      Utils.showToastMessage("Accept Terms & Conditions");
    } else {
      debugPrint("validity signUp");
      controller.signUp(ph: Get.arguments[0]);
    }
  }

  @override
  void initState() {
    super.initState();
    controller.getClass();
    controller.getMedium();
    controller.getBoard();
    controller.getSchool();
    controller.getCity();
    controller.getState();
    controller.getTnC();
  }

  @override
  void dispose() {
    super.dispose();
    controller.clearController();
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Column(
        children: [
          Container(
            margin: EdgeInsets.only(left: 12.w, right: 12.w, top: 50.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () => Get.toNamed(AppRoutes.login),
                  child: Container(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // Icon(
                        //   Icons.arrow_back_ios_outlined,
                        //   size: 20.w,
                        //   color: AppColors.BACK_ARROW_COLOR.withOpacity(0.5),
                        // ),
                        // Gap(6.w),
                        Text(
                          "Back to login",
                          style: TextStyle(
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.normal,
                              fontSize: 16.sp,
                              color:
                                  AppColors.BACK_ARROW_COLOR.withOpacity(0.5)),
                        )
                      ],
                    ),
                  ),
                ),
                // IconButton(
                //   onPressed: () => checkValidation(),
                //   icon: Icon(
                //     Icons.arrow_forward_ios,
                //     size: 32.w,
                //     color: AppColors.ON_BOARDING_BUTTON_COLOR,
                //   ),
                // )
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 12.w, right: 12.w, top: 20.w),
            child: Row(
              children: [
                Expanded(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Welcome!",
                      style: TextStyle(
                          fontFamily: "Poppins",
                          fontWeight: FontWeight.w600,
                          fontSize: 22.sp,
                          color: AppColors.TITLE_TEXT_BLACK),
                    ),
                    Text(
                      "Please fill the form",
                      style: TextStyle(
                          fontFamily: "Poppins",
                          fontWeight: FontWeight.w600,
                          fontSize: 22.sp,
                          color: AppColors.ON_BOARDING_BUTTON_COLOR),
                    )
                  ],
                )),
                IconButton(
                  onPressed: () => checkValidation(),
                  icon: Icon(
                    Icons.arrow_forward_ios,
                    size: 32.w,
                    color: AppColors.ON_BOARDING_BUTTON_COLOR,
                  ),
                )
              ],
            ),
          ),
          Expanded(
            child: NotificationListener<OverscrollIndicatorNotification>(
              onNotification: (OverscrollIndicatorNotification overscroll) {
                overscroll.disallowIndicator();
                return true;
              },
              child: controller.isLoading.value
                  ? Container(
                      width: double.maxFinite,
                      height: double.maxFinite,
                      child: Center(
                        child: SizedBox(
                          height: 24.h,
                          width: 24.w,
                          child: CircularProgressIndicator(
                            color: Colors.black,
                          ),
                        ),
                      ),
                    )
                  : SingleChildScrollView(
                      child: Container(
                        margin: EdgeInsets.only(left: 12.w, right: 12.w),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Gap(28.w),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText("Name"),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            reusableTextField(
                              "Enter Your Name",
                              controller.nameController.value,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Photo",
                                ),
                              ],
                            ),
                            GestureDetector(
                              onTap: () => showDialog(
                                context: context,
                                builder: (ctx) => AlertDialog(
                                  title: const Text("Choose Image From"),
                                  content: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      GestureDetector(
                                        onTap: () {
                                          pickImageCamera();
                                          Navigator.pop(context);
                                        },
                                        //debugPrint("------1st---------"),
                                        child: Container(
                                          height: 50,
                                          child: Center(
                                            child: Icon(
                                              Icons.camera_alt_sharp,
                                              size: 40.h,
                                            ),
                                          ),
                                        ),
                                      ),
                                      GestureDetector(
                                        onTap: () {
                                          pickImageGallery();
                                          Navigator.pop(context);
                                        },
                                        //debugPrint("------2nd---------"),
                                        child: Container(
                                          height: 80,
                                          child: Center(
                                            child: Icon(
                                              Icons.image,
                                              size: 40.h,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  // actions: <Widget>[
                                  //   TextButton(
                                  //     onPressed: () {
                                  //       Navigator.of(ctx).pop();
                                  //     },
                                  //     child: Container(
                                  //       color: Colors.green,
                                  //       padding: const EdgeInsets.all(14),
                                  //       child: const Text("okay"),
                                  //     ),
                                  //   ),
                                  // ],
                                ),
                              ),
                              child: Container(
                                height: MediaQuery.of(context).size.height * .2,
                                color: AppColors.ON_BOARDING_BUTTON_COLOR
                                    .withOpacity(0.3),
                                margin: EdgeInsets.only(top: 10.w),
                                child: Center(
                                  child: Stack(
                                    children: [
                                      Container(
                                        height: 110.h,
                                        width: 110.w,
                                        // color: Colors.red,
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(10000),
                                        ),
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(10000),
                                          child: images != null
                                              ? Image.file(images!,
                                                  fit: BoxFit.fill,
                                                  filterQuality:
                                                      FilterQuality.high)
                                              : Image.asset(
                                                  "assets/icons/avatar_img.png",
                                                  fit: BoxFit.fill,
                                                  filterQuality:
                                                      FilterQuality.high),
                                        ),
                                      ),
                                      Positioned(
                                          bottom: 0,
                                          right: 5.w,
                                          child: Container(
                                            height: 28.h,
                                            width: 28.w,
                                            child: Icon(
                                              Icons.camera_alt_outlined,
                                              color: Colors.white,
                                              size: 20.w,
                                            ),
                                          ))
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText("Password"),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            // reusableTextField("Enter Your Password", controller.passwordController.value, "password"),
                            reusablePasswordField(
                              "Enter Your Password",
                              controller.passwordController.value,
                              controller.isPasswordVisible.value,
                              () {
                                controller.isPasswordVisible.value =
                                    !controller.isPasswordVisible.value;
                              },
                              "password",
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Retype Password",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            // reusableTextField("Retype Your Password", controller.cnfrmPasswordController.value, "password"),
                            reusablePasswordField(
                              "Retype Your Password",
                              controller.cnfrmPasswordController.value,
                              controller.isCnfrmPasswordVisible.value,
                              () {
                                controller.isCnfrmPasswordVisible.value =
                                    !controller.isCnfrmPasswordVisible.value;
                              },
                              "password",
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Authentication Pin",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            reusableTextField(
                                "Enter authentication pin (e.g: 1234)",
                                controller.authPinController.value,
                                "auth"),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Email",
                                ),
                              ],
                            ),
                            reusableTextField(
                              "Enter your mail id",
                              controller.emailController.value,
                              "email",
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Address",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            reusableTextField("Enter your address",
                                controller.addressController.value, "address"),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "City",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            //Searchable dropdown for city
                            Container(
                              margin: EdgeInsets.only(
                                top: 8.h,
                              ),
                              padding: EdgeInsets.symmetric(horizontal: 10.w),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  color: Colors.white.withOpacity(0.8),
                                  border: Border.all(
                                      color: AppColors.FIELD_BORDER_COLOR)),
                              child: TextFormField(
                                enabled: true,
                                maxLines: null,
                                onChanged: (value) {
                                  controller.isCityOpen.value = true;
                                  controller.getCity();
                                },
                                controller: controller.cityController.value,
                                keyboardType: TextInputType.text,
                                decoration: InputDecoration(
                                  hintText: "Select your city",
                                  counterText: "",
                                  errorStyle: TextStyle(
                                      height: 0, color: Colors.transparent),
                                  suffixIcon: Icon(
                                    Icons.search,
                                    color: AppColors.OTP_TIMER_COLOR,
                                    size: 18,
                                  ),
                                  hintStyle: TextStyle(
                                      color: AppColors.FIELD_HINT_COLOR,
                                      fontFamily: 'Poppins',
                                      fontSize: 14.sp),
                                  border: InputBorder.none,
                                  focusColor: Colors.transparent,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                ),
                              ),
                            ),
                            controller.isCityOpen.value
                                ? controller.isCityLoading.value
                                    ? Container(
                                        height: 45.h,
                                        width: double.maxFinite,
                                        color: Colors.white,
                                        margin: EdgeInsets.only(top: 4.h),
                                        padding: EdgeInsets.only(
                                            left: 6.h, top: 10.h, bottom: 10.h),
                                        child: SizedBox(
                                          height: 12.h,
                                          width: 12.w,
                                          child: Center(
                                            child: CircularProgressIndicator(
                                              color: Colors.black,
                                            ),
                                          ),
                                        ),
                                      )
                                    : controller.cityNameList!.length > 0
                                        ? Scrollbar(
                              controller: _scrollController,
                                            thickness: 5,
                                            trackVisibility: true,
                                            interactive: true,
                                            thumbVisibility: true,
                                            child: SingleChildScrollView(
                                              controller: _scrollController,
                                              child: Container(
                                                height: controller.cityNameList!
                                                            .length >
                                                        5
                                                    ? 200.h
                                                    : null,
                                                margin: EdgeInsets.only(top: 4.h),
                                                padding: EdgeInsets.only(
                                                    left: 6.h,
                                                    top: 10.h,
                                                    bottom: 10.h),
                                                decoration: BoxDecoration(
                                                    color: Colors.white,
                                                    border: Border.all(
                                                        color: Colors.black,
                                                        width: 0.2)),
                                                child: NotificationListener<
                                                    OverscrollIndicatorNotification>(
                                                  onNotification:
                                                      (OverscrollIndicatorNotification
                                                          notification) {
                                                    notification
                                                        .disallowIndicator();
                                                    return true;
                                                  },
                                                  child: ListView.builder(
                                                    shrinkWrap: true,
                                                    physics:
                                                        AlwaysScrollableScrollPhysics(),
                                                    itemBuilder:
                                                        (context, index) {
                                                      return GestureDetector(
                                                        onTap: () {
                                                          controller.cityController.value.text = controller.cityNameList![index];
                                                          controller.isCityOpen.value = false;
                                                        },
                                                        child: Container(
                                                          color:
                                                              Colors.transparent,
                                                          child: Column(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: [
                                                              Text(
                                                                  "${controller.cityNameList![index]}"),
                                                              index !=
                                                                      controller
                                                                              .cityNameList!
                                                                              .length -
                                                                          1
                                                                  ? Divider(
                                                                      color: Colors
                                                                          .grey
                                                                          .withOpacity(
                                                                              0.5),
                                                                    )
                                                                  : Container(),
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                    itemCount: controller
                                                        .cityNameList!.length,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                        : Container(
                                            margin: EdgeInsets.only(top: 4.h),
                                            padding: EdgeInsets.only(
                                                left: 6.h,
                                                top: 10.h,
                                                bottom: 10.h),
                                            decoration: BoxDecoration(
                                                color: Colors.white,
                                                border: Border.all(
                                                    color: Colors.black,
                                                    width: 0.2)),
                                            child: Column(
                                              children: [
                                                GestureDetector(
                                                  onTap: () {
                                                    controller.isSelectCity
                                                        .value = true;
                                                  },
                                                  child: Container(
                                                    height: 45.h,
                                                    width: double.maxFinite,
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    margin: EdgeInsets.only(
                                                      top: 8.w,
                                                    ),
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 10.w),
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(4.0),
                                                        color: Colors.white
                                                            .withOpacity(0.8),
                                                        border: Border.all(
                                                            color: AppColors
                                                                .FIELD_BORDER_COLOR
                                                                .withOpacity(
                                                                    0.3))),
                                                    child: Text(
                                                      "Other",
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(
                                                          color: AppColors
                                                              .FIELD_HINT_COLOR,
                                                          fontFamily: 'Poppins',
                                                          fontSize: 16.sp),
                                                    ),
                                                  ),
                                                ),
                                                controller.isSelectCity.value
                                                    ? Container(
                                                        height: 45.h,
                                                        margin: EdgeInsets.only(
                                                          top: 8.w,
                                                        ),
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                                horizontal:
                                                                    10.w),
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        4.0),
                                                            color: Colors.white
                                                                .withOpacity(
                                                                    0.8),
                                                            border: Border.all(
                                                                color: AppColors
                                                                    .FIELD_BORDER_COLOR)),
                                                        child: TextFormField(
                                                          controller: controller
                                                              .otherCityController
                                                              .value,
                                                          autofocus: true,
                                                          keyboardType:
                                                              TextInputType
                                                                  .text,
                                                          decoration:
                                                              InputDecoration(
                                                            hintText:
                                                                "Enter your city",
                                                            counterText: "",
                                                            errorStyle: TextStyle(
                                                                height: 0,
                                                                color: Colors
                                                                    .transparent),
                                                            hintStyle: TextStyle(
                                                                color: AppColors
                                                                    .FIELD_HINT_COLOR,
                                                                fontFamily:
                                                                    'Poppins',
                                                                fontSize:
                                                                    14.sp),
                                                            border: InputBorder
                                                                .none,
                                                            focusColor: Colors
                                                                .transparent,
                                                            focusedBorder:
                                                                InputBorder
                                                                    .none,
                                                            enabledBorder:
                                                                InputBorder
                                                                    .none,
                                                          ),
                                                        ),
                                                      )
                                                    : Container()
                                              ],
                                            ))
                                : Container(),
                            // Obx(() => searchableDropdown("Enter your city",controller.cityController.value,context)),
                            // searchableDropdown("Enter your city",controller.cityController.value,context),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "State",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            //Searchable dropdown for State
                            reusableDropDownField(
                                "Select your state",
                                controller.stateController.value,
                                controller.isSelectState.value, () {
                              controller.isSelectState.value =
                                  !controller.isSelectState.value;
                            }),
                            controller.isSelectState.value
                                ? buildStateDropDownList()
                                : Container(),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Pin code",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            reusableTextField("Enter your pin code",
                                controller.pinController.value, "pincode"),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Class",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            reusableDropDownField(
                                "Select your class",
                                controller.classController.value,
                                controller.isSelectClass.value, () {
                              controller.isSelectClass.value =
                                  !controller.isSelectClass.value;
                            }),
                            controller.isSelectClass.value
                                ? buildClassDropDownList()
                                : Container(),
                            // Text("${controller.classData.value.result}"),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "School",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            /*reusableTextField(
                          "Enter your school name",
                          controller.schoolController.value,
                          (value) {
                            if (value == null || value.isEmpty) {
                              Utils.showToastMessage(
                                  "Enter Your school name");
                              return '';
                            }
                            return null;
                          },
                          "dropdown",
                          ),*/
                            reusableDropDownField(
                                "Select your school",
                                controller.schoolController.value,
                                controller.isSelectSchool.value, () {
                              controller.isSelectSchool.value =
                                  !controller.isSelectSchool.value;
                            }),
                            controller.isSelectSchool.value
                                ? buildSchoolDropDownList()
                                : Container(),
                            controller.isSelectOtherSchool.value
                                ? Container(
                                    height: 45.h,
                                    margin: EdgeInsets.only(
                                      top: 8.w,
                                    ),
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 10.w),
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(4.0),
                                        color: Colors.white.withOpacity(0.8),
                                        border: Border.all(
                                            color:
                                                AppColors.FIELD_BORDER_COLOR)),
                                    child: TextFormField(
                                      controller: controller
                                          .otherSchoolController.value,
                                      autofocus: true,
                                      keyboardType: TextInputType.text,
                                      decoration: InputDecoration(
                                        hintText: "Enter your school name",
                                        counterText: "",
                                        errorStyle: TextStyle(
                                            height: 0,
                                            color: Colors.transparent),
                                        hintStyle: TextStyle(
                                            color: AppColors.FIELD_HINT_COLOR,
                                            fontFamily: 'Poppins',
                                            fontSize: 14.sp),
                                        border: InputBorder.none,
                                        focusColor: Colors.transparent,
                                        focusedBorder: InputBorder.none,
                                        enabledBorder: InputBorder.none,
                                      ),
                                    ),
                                  )
                                : Container(),

                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Medium",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            reusableDropDownField(
                                "Select your medium",
                                controller.mediumController.value,
                                controller.isSelectMedium.value, () {
                              controller.isSelectMedium.value =
                                  !controller.isSelectMedium.value;
                            }),
                            controller.isSelectMedium.value
                                ? buildMediumDropDownList()
                                : Container(),
                            /*reusableTextField("Enter your medium",
                          controller.mediumController.value, (value) {
                        if (value == null || value.isEmpty) {
                          Utils.showToastMessage("Enter Your medium");
                          return '';
                        }
                        return null;
                      }, "dropdown"),*/
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                reusableFieldText(
                                  "Board",
                                ),
                                Icon(
                                  Icons.star,
                                  color: Colors.red,
                                  size: 10.w,
                                ),
                              ],
                            ),
                            /*reusableTextField("Enter your board",
                          controller.boardController.value, (value) {
                        if (value == null || value.isEmpty) {
                          Utils.showToastMessage("Enter Your board");
                          return '';
                        }
                        return null;
                      }, "dropdown"),*/
                            reusableDropDownField(
                                "Select your board",
                                controller.boardController.value,
                                controller.isSelectBoard.value, () {
                              controller.isSelectBoard.value =
                                  !controller.isSelectBoard.value;
                            }),
                            controller.isSelectBoard.value
                                ? buildBoardDropDownList()
                                : Container(),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                buildCheckboxField(
                                    "Accept Terms & Conditions", "tnc"),
                                Container(
                                  margin: EdgeInsets.only(left: 6.w),
                                  child: Icon(
                                    Icons.star,
                                    color: Colors.red,
                                    size: 10.w,
                                  ),
                                ),
                              ],
                            ),
                            buildCheckboxField(
                                "Accept to add into groups", "group"),
                            buildCheckboxField(
                                "Accept to get notification on whatsapp", "wp"),
                            Gap(25.w)
                          ],
                        ),
                      ),
                    ),
            ),
          )
        ],
      ),
    );
  }

  Widget buildClassDropDownList() {
    return Scrollbar(
      controller: _scrollController,
      thickness: 5,
      trackVisibility: true,
      interactive: true,
      thumbVisibility: true,
      child: SingleChildScrollView(
        controller: _scrollController,
        child: Container(
          height: controller.classData.value.result!.length > 5 ? 200.h : null,
          margin: EdgeInsets.only(top: 4.h),
          padding: EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h),
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.black, width: 0.2)),
          child: NotificationListener<OverscrollIndicatorNotification>(
            onNotification: (OverscrollIndicatorNotification notification) {
              notification.disallowIndicator();
              return true;
            },
            child: ListView.builder(
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    controller.classController.value.text =
                        controller.classData.value.result![index].name!;
                    controller.isSelectClass.value =
                        !controller.isSelectClass.value;

                    controller.classId.value =
                        controller.classData.value.result![index].sId!;
                  },
                  child: Container(
                    color: Colors.transparent,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("${controller.classData.value.result![index].name}"),
                        index != controller.classData.value.result!.length - 1
                            ? Divider(
                                color: Colors.grey.withOpacity(0.5),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                );
              },
              itemCount: controller.classData.value.result!.length,
            ),
          ),
        ),
      ),
    );
  }

  Widget buildMediumDropDownList() {
    return Scrollbar(
        controller: _scrollController,
        thickness: 5,
        trackVisibility: true,
        interactive: true,
        thumbVisibility: true,
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Container(
            height: controller.mediumData.value.result!.length > 5 ? 200.h : null,
            child: Container(
              margin: EdgeInsets.only(top: 4.h),
              padding: EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h),
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.black, width: 0.2)),
              child: NotificationListener<OverscrollIndicatorNotification>(
                onNotification: (OverscrollIndicatorNotification notification) {
                  notification.disallowIndicator();
                  return true;
                },
                child: ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        controller.mediumController.value.text =
                            controller.mediumData.value.result![index].name!;
                        controller.isSelectMedium.value =
                            !controller.isSelectMedium.value;
                        controller.mediumId.value =
                            controller.mediumData.value.result![index].id!;
                      },
                      child: Container(
                        color: Colors.transparent,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                "${controller.mediumData.value.result![index].name}"),
                            index !=
                                    controller.mediumData.value.result!.length - 1
                                ? Divider(
                                    color: Colors.grey.withOpacity(0.5),
                                  )
                                : Container(),
                          ],
                        ),
                      ),
                    );
                  },
                  itemCount: controller.mediumData.value.result!.length,
                ),
              ),
            ),
          ),
        ));
  }

  Widget buildBoardDropDownList() {
    return Scrollbar(
      controller: _scrollController,
      thickness: 5,
      trackVisibility: true,
      interactive: true,
      thumbVisibility: true,
      child: SingleChildScrollView(
        controller: _scrollController,
        child: Container(
          height: controller.boardData.value.result!.length > 5 ? 200.h : null,
          margin: EdgeInsets.only(top: 4.h),
          padding: EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h),
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.black, width: 0.2)),
          child: NotificationListener<OverscrollIndicatorNotification>(
            onNotification: (OverscrollIndicatorNotification notification) {
              notification.disallowIndicator();
              return true;
            },
            child: ListView.builder(
              shrinkWrap: true,
              physics: AlwaysScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    controller.boardController.value.text =
                        controller.boardData.value.result![index].name!;
                    controller.isSelectBoard.value =
                        !controller.isSelectBoard.value;

                    controller.boardId.value =
                        controller.boardData.value.result![index].id!;
                  },
                  child: Container(
                    color: Colors.transparent,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("${controller.boardData.value.result![index].name}"),
                        index != controller.boardData.value.result!.length - 1
                            ? Divider(
                                color: Colors.grey.withOpacity(0.5),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                );
              },
              itemCount: controller.boardData.value.result!.length,
            ),
          ),
        ),
      ),
    );
  }

  Widget buildStateDropDownList() {
    return Scrollbar(
      controller: _scrollController,
      thickness: 5,
      trackVisibility: true,
      interactive: true,
      thumbVisibility: true,
      child: SingleChildScrollView(
        controller: _scrollController,
        child: Container(
          height: controller.stateData.value.result!.length > 5 ? 200.h : null,
          margin: EdgeInsets.only(top: 4.h),
          padding: EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h),
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.black, width: 0.2)),
          child: NotificationListener<OverscrollIndicatorNotification>(
            onNotification: (OverscrollIndicatorNotification notification) {
              notification.disallowIndicator();
              return true;
            },
            child: ListView.builder(
              shrinkWrap: true,
              physics: AlwaysScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    controller.stateController.value.text =
                        controller.stateData.value.result![index].name!;
                    controller.isSelectState.value =
                        !controller.isSelectState.value;
                  },
                  child: Container(
                    color: Colors.transparent,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("${controller.stateData.value.result![index].name}"),
                        index != controller.stateData.value.result!.length - 1
                            ? Divider(
                                color: Colors.grey.withOpacity(0.5),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                );
              },
              itemCount: controller.stateData.value.result!.length,
            ),
          ),
        ),
      ),
    );
  }

  Widget buildSchoolDropDownList() {
    return Scrollbar(
      controller: _scrollController,
      thickness: 5,
      trackVisibility: true,
      interactive: true,
      thumbVisibility: true,
      child: Container(
        height: controller.schoolData.value.result!.length > 5 ? 200.h : null,
        margin: EdgeInsets.only(top: 4.h),
        padding:
            EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h, right: 6.h),
        decoration: BoxDecoration(
            color: Colors.white,
            border: Border.all(color: Colors.black, width: 0.2)),
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Column(
            children: [
              NotificationListener<OverscrollIndicatorNotification>(
                onNotification: (OverscrollIndicatorNotification notification) {
                  notification.disallowIndicator();
                  return true;
                },
                child: ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        controller.schoolController.value.text =
                            controller.schoolData.value.result![index].name!;
                        controller.isSelectSchool.value = false;

                        controller.schoolId.value =
                            controller.schoolData.value.result![index].id!;
                        controller.isSelectOtherSchool.value = false;
                      },
                      child: Container(
                        color: Colors.transparent,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                                "${controller.schoolData.value.result![index].name}"),
                            index !=
                                    controller.schoolData.value.result!.length -
                                        1
                                ? Divider(
                                    color: Colors.grey.withOpacity(0.5),
                                  )
                                : Container(),
                            /*index == controller.schoolData.value.result!.length - 1
                                ? GestureDetector(
                                    onTap: () {
                                      controller.schoolController.value.text = "Other";
                                      controller.isSelectSchool.value = false;
                                      controller.isSelectOtherSchool.value = true;
                                    },
                                    child: Container(
                                      height: 45.h,
                                      width: double.maxFinite,
                                      alignment: Alignment.centerLeft,
                                      margin: EdgeInsets.only(
                                        top: 8.w,
                                      ),
                                      padding: EdgeInsets.symmetric(horizontal: 10.w),
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(4.0),
                                          color: Colors.white.withOpacity(0.8),
                                          border: Border.all(
                                              color: AppColors.FIELD_BORDER_COLOR
                                                  .withOpacity(0.3))),
                                      child: Text(
                                        "Other",
                                        textAlign: TextAlign.left,
                                        style: TextStyle(
                                            color: AppColors.FIELD_HINT_COLOR,
                                            fontFamily: 'Poppins',
                                            fontSize: 16.sp),
                                      ),
                                    ),
                                  )
                                : Container(),*/
                          ],
                        ),
                      ),
                    );
                  },
                  itemCount: controller.schoolData.value.result!.length,
                ),
              ),
              GestureDetector(
                onTap: () {
                  controller.schoolController.value.text = "Other";
                  controller.isSelectSchool.value = false;
                  controller.isSelectOtherSchool.value = true;
                },
                child: Container(
                  height: 45.h,
                  width: double.maxFinite,
                  alignment: Alignment.centerLeft,
                  margin: EdgeInsets.only(
                    top: 8.w,
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 10.w),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4.0),
                      color: Colors.white.withOpacity(0.8),
                      border: Border.all(
                          color:
                              AppColors.FIELD_BORDER_COLOR.withOpacity(0.3))),
                  child: Text(
                    "Other",
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        color: AppColors.FIELD_HINT_COLOR,
                        fontFamily: 'Poppins',
                        fontSize: 16.sp),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget buildCheckboxField(String label, String type) {
    bool value = false;
    if (type == "tnc") {
      value = controller.isSelectTnC.value;
    } else if (type == "group") {
      value = controller.isSelectGroup.value;
    } else if (type == "wp") {
      value = controller.isSelectWp.value;
    }

    return Container(
      color: Colors.white.withOpacity(0.5),
      child: Row(
        children: [
          Checkbox(
              value: value,
              onChanged: (value) {
                if (type == "tnc") {
                  controller.isSelectTnC.value = value!;
                } else if (type == "group") {
                  controller.isSelectGroup.value = value!;
                } else if (type == "wp") {
                  controller.isSelectWp.value = value!;
                }
              }),
          type == "tnc"
              ? RichText(
                  text: TextSpan(
                    text: 'I accept the ',
                    style: DefaultTextStyle.of(context).style,
                    children: <TextSpan>[
                      TextSpan(
                        text: 'Terms & Conditions',
                        style: TextStyle(
                          color: Colors.blue,
                          decoration: TextDecoration.underline,
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () {
                            // Add your click event logic here
                            print('Terms & Conditions clicked!');
                            //Get.toNamed(AppRoutes.Tnc);
                            _openAnimationDialog(context);
                          },
                      ),
                    ],
                  ),
                )
              : Text(
                  label,
                  style: TextStyle(
                      fontSize: 14.sp,
                      color: Colors.black,
                      fontFamily: "Alata"),
                )
        ],
      ),
    );
  }

  void _openAnimationDialog(BuildContext context) {
    showGeneralDialog(context: context,
        barrierDismissible: true,
        barrierLabel: '',
        // transitionDuration: Duration(microseconds: 900),
        pageBuilder: (context, animation1, animation2 ) {
          return Container();
        },
      transitionBuilder: (context, animation1, animation2, child) {
      return ScaleTransition(scale: Tween<double>(begin: 0.5,end: 1.0).animate(animation1),
      child: FadeTransition(
        opacity: Tween<double>(begin: 0.5,end: 1.0).animate(animation1),
        child: Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
          // title: Text("Terms & Conditions"),
          child: TermsCondition()
        ),
      ),);
      },
    );
  }
}
