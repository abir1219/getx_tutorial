import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../controllers/get_profile_controller.dart';
import '../res/app_colors.dart';

class MemberDetailsHeader extends StatelessWidget {
  final String phone;
  const MemberDetailsHeader({super.key, required this.phone});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80.h,
      margin: EdgeInsets.only(left: 15.w, right: 15.w, top: 20.h),
      padding: EdgeInsets.only(left: 12.w, right: 12.w),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8.w),
          color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  // "+91 1234567890",
                  "$phone",
                  style: TextStyle(
                      fontSize: 16.sp,
                      color: AppColors.TITLE_TEXT_WHITE,
                      fontFamily: "Poppins"),
                ),
                Text("Free member",
                    style: TextStyle(
                        fontSize: 14.sp,
                        color: AppColors.TITLE_TEXT_WHITE,
                        fontFamily: "Poppins")),
              ],
            ),
          ),
          Container(
            height: 40.h,
            width: 165.w,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40.w),
                color: Colors.white.withOpacity(0.15)),
            child: Center(
              child: Text("PREMIUM SUBSCRIBE",
                  style: TextStyle(
                      fontSize: 12.sp,
                      color: AppColors.TITLE_TEXT_GREEN,
                      fontFamily: "Poppins")),
            ),
          )
        ],
      ),
    );
  }
}
