import 'package:MotivateU/controllers/sign_up_controller.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';

Widget reusableTitleText(String title) {
  return Container(
      alignment: Alignment.bottomLeft,
      margin: EdgeInsets.only(left: 25.w),
      child: Text(title,
          style: TextStyle(
              fontSize: 24.sp,
              color: AppColors.TITLE_TEXT_BLACK,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold)));
}

Widget reusableFieldText(String title) {
  return Container(
      alignment: Alignment.bottomLeft,
      margin: EdgeInsets.only(
        top: 15.w,
      ),
      child: Text(title,
          style: TextStyle(
              fontSize: 16.sp,
              color: AppColors.TITLE_TEXT_BLACK.withOpacity(0.48),
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w500)));
}

/*Widget searchableDropdown(String hintText, TextEditingController? controller,BuildContext context){
  return Container(
    width: double.maxFinite,
    height: 45.h,
    margin: EdgeInsets.only(
      top: 8.w,
    ),
    padding: EdgeInsets.symmetric(horizontal: 10.w),
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4.0),
        color: Colors.white.withOpacity(0.8),
        border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),
    child: DropdownButtonHideUnderline(
      child: DropdownButton2<String>(
        isExpanded: true,
        hint: Text(
          '$hintText',
          style: TextStyle(
            fontSize: 14,
            color: Theme.of(context).hintColor,
          ),
        ),
        items: Get.find<SignUpController>().cityNameList!
            .map((item) => DropdownMenuItem(
          value: item,
          child: Text(
            item,
            style: const TextStyle(
              fontSize: 14,
            ),
          ),
        ))
            .toList(),
        value: Get.find<SignUpController>().selectedValue!.value,
        onChanged: (value) {
          Get.find<SignUpController>().selectedValue!.value = value!;
        },
        buttonStyleData: const ButtonStyleData(
          // padding: EdgeInsets.symmetric(horizontal: 16),
          height: 45,
          width: double.maxFinite,
        ),
        dropdownStyleData: const DropdownStyleData(
          maxHeight: 200,
        ),
        menuItemStyleData: const MenuItemStyleData(
          height: 45,
        ),
        dropdownSearchData: DropdownSearchData(
          searchController: controller,
          searchInnerWidgetHeight: 50,
          searchInnerWidget: Container(
            height: 50,
            padding: const EdgeInsets.only(
              top: 8,
              bottom: 4,
              right: 8,
              left: 8,
            ),
            child: TextFormField(
              expands: true,
              maxLines: null,
              controller: controller,
              decoration: InputDecoration(
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
                hintText: 'Search for city...',
                hintStyle: const TextStyle(fontSize: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
          searchMatchFn: (item, searchValue) {
            return item.value.toString().contains(searchValue);
          },
        ),
        //This to clear the search value when you close the menu
        onMenuStateChange: (isOpen) {
          if (!isOpen) {
            controller?.clear();
          }
        },
      ),
    ),
  );
}*/

Widget searchableDropdown(String hintText, TextEditingController? controller,BuildContext context){
  return Container(
      width: double.maxFinite,
      height: 45.h,
      margin: EdgeInsets.only(
      top: 8.w,
  ),
  padding: EdgeInsets.symmetric(horizontal: 10.w),
  decoration: BoxDecoration(
  borderRadius: BorderRadius.circular(4.0),
  color: Colors.white.withOpacity(0.8),
  border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),

  );
}

Widget reusableTextField(String hintText, TextEditingController controller,
    [String? type]) {
  return Container(
    // height: 45.h,
    margin: EdgeInsets.only(
      top: 8.w,
    ),
    padding: EdgeInsets.symmetric(horizontal: 10.w),
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4.0),
        color: Colors.white.withOpacity(0.8),
        border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),
    child: TextFormField(
      enabled: type == "dropdown" ? false : true,
      obscureText: type == "password" ? true : false,
      controller: controller,
      maxLines: type=="address"?null:1,
      keyboardType:
          type == "ph" ? TextInputType.phone : type=="email"?TextInputType.emailAddress:type=="auth" || type=="pincode" ?TextInputType.number:TextInputType.text,
      inputFormatters: [
        if(type=="auth")
          FilteringTextInputFormatter.digitsOnly
      ],
      maxLength: type == "ph" ? 10 : type =="auth"? 4 : type=="pincode"?6:200,
      decoration: InputDecoration(
        hintText: hintText,
        counterText: "",
        errorStyle: TextStyle(height: 0, color: Colors.transparent),
        suffixIcon: type == "dropdown"
            ? Icon(
                Icons.arrow_drop_down_sharp,
                color: AppColors.FIELD_BORDER_COLOR,
                size: 18,
              )
            : null,
        hintStyle: TextStyle(
            color: AppColors.FIELD_HINT_COLOR,
            fontFamily: 'Poppins',
            fontSize: 14.sp),
        border: InputBorder.none,
        focusColor: Colors.transparent,
        focusedBorder: InputBorder.none,
        enabledBorder: InputBorder.none,
      ),
    ),
  );
}

Widget reusablePasswordField(String hintText, TextEditingController pwController,bool isPasswordVisible,
void Function()? func,[String? type]) {
  return Container(
    height: 45.h,
    margin: EdgeInsets.only(
      top: 8.w,
    ),
    padding: EdgeInsets.symmetric(horizontal: 10.w),
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4.0),
        color: Colors.white.withOpacity(0.8),
        border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),
    child: TextFormField(
      enabled: type == "dropdown" ? false : true,
      obscureText: !isPasswordVisible ? true : false,
      controller: pwController,
      keyboardType:
      TextInputType.text,
      decoration: InputDecoration(
        hintText: hintText,
        counterText: "",
        errorStyle: TextStyle(height: 0, color: Colors.transparent),
        suffixIcon: IconButton(
          icon: Icon(isPasswordVisible?Icons.visibility_off:Icons.visibility,),
          color: AppColors.FIELD_BORDER_COLOR,
          onPressed: () => func!(),
        ),
        hintStyle: TextStyle(
            color: AppColors.FIELD_HINT_COLOR,
            fontFamily: 'Poppins',
            fontSize: 14.sp),
        border: InputBorder.none,
        focusColor: Colors.transparent,
        focusedBorder: InputBorder.none,
        enabledBorder: InputBorder.none,
      ),
    ),
  );
}


Widget reusableDropDownField(
    String hintText,
    TextEditingController controller,
    bool isSelect,
    void Function() func) {
  return GestureDetector(
    onTap: func,
    child: Container(
      height: 45.h,
      margin: EdgeInsets.only(
        top: 8.w,
      ),
      padding: EdgeInsets.symmetric(horizontal: 10.w),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4.0),
          color: Colors.white.withOpacity(0.8),
          border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),
      child: TextFormField(
        enabled: false,
        controller: controller,
        decoration: InputDecoration(
          hintText: hintText,
          counterText: "",
          errorStyle: TextStyle(height: 0, color: Colors.transparent),
          suffixIcon: Icon(
            isSelect ? Icons.arrow_drop_up : Icons.arrow_drop_down_sharp,
            color: AppColors.FIELD_BORDER_COLOR,
            size: 18,
          ),
          hintStyle: TextStyle(
              color: AppColors.FIELD_HINT_COLOR,
              fontFamily: 'Poppins',
              fontSize: 14.sp),
          border: InputBorder.none,
          focusColor: Colors.transparent,
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
        ),
      ),
    ),
  );
}
