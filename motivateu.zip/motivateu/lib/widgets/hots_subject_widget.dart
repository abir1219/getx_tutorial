import 'package:MotivateU/controllers/hots_controller.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class HotsSubjectWidget extends StatefulWidget {
  final String subjectName;
  final String subjectId;
  final int subjectCount;
  const HotsSubjectWidget({super.key, required this.subjectName, required this.subjectCount, required this.subjectId});

  @override
  State<HotsSubjectWidget> createState() => _HotsSubjectWidgetState();
}

class _HotsSubjectWidgetState extends State<HotsSubjectWidget> {

  var controller = Get.isRegistered<HotsController>()
      ? Get.find<HotsController>()
      : Get.put(HotsController());

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Get.offNamed(AppRoutes.HotsTopicList,arguments: [widget.subjectId]),
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 8.0.w,vertical: 10.h),
        child: Stack(
          children: [
            Positioned.fill(
              child: Container(
                height: 100.h,
                //width: MediaQuery.of(context).size.width,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.ACCOUNT_PAGE_BG_COLOR,
                  /*border: Border(
                    top: BorderSide(
                        color: Colors.black,
                        width: 4
                    )
                ),*/
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [Text("${widget.subjectCount}",style: TextStyle(fontSize: 26.sp,fontWeight: FontWeight.w600,color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR)),
                    Text(widget.subjectName,style: TextStyle(fontSize: 14.sp,fontWeight: FontWeight.w600,color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR))],
                ),
              ),
            ),
            Positioned(
                top: 0,
                right: 0,
                child: Container(
                  // margin: EdgeInsets.only(top: 10),
              height: 30.h,
              width: 30.w,
              decoration: BoxDecoration(
                // borderRadius: BorderRadius.circular(100.sp),
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(100),
                  bottomLeft: Radius.circular(100),
                ),
                color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,
              ),
              child: Center(
                child: Icon(Icons.arrow_forward_ios_sharp,color: Colors.white,size: 16,),
              ),
            ))
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    debugPrint("Hots Subject Widget dispose");
    if(!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!){
      controller.stopTimerTrack();
    }
  }
}
