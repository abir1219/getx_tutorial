import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../res/app_colors.dart';
import 'comments_list_widget.dart';

class CommentWidget extends StatelessWidget {
  const CommentWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          margin: EdgeInsets.only(bottom: 12,top: 10.h),
          height: 3.h,
          width: MediaQuery.of(context).size.width/6,
          color: Colors.black.withOpacity(0.5),
        ),
        Container(
          margin: EdgeInsets.only(bottom: 10),
          child: Text("Comments",style: TextStyle(fontSize: 16.sp,color: Colors.grey,fontWeight: FontWeight.bold,fontFamily: "Alata"),),
        ),
        Container(
          margin: EdgeInsets.only(bottom: 6),
          height: .5,
          color: Colors.black.withOpacity(0.3),
        ),
        //Expanded(child: CommentsListWidget()), // Assuming CommentsListWidget handles comments
        Divider(), // Add a divider for separation
        Container(
          padding: EdgeInsets.symmetric(vertical: 10),
          color: AppColors.TITLE_TEXT_WHITE,
          child: Row(
            children: [
              Flexible(
                fit: FlexFit.loose,
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 15),
                  padding: EdgeInsets.only(left: 10),
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: TextField(
                    maxLines: null,
                    decoration: InputDecoration(
                      hintText: "Write a comment...",
                      hintStyle: TextStyle(
                        color: AppColors.FIELD_BORDER_COLOR,
                        fontFamily: 'Poppins',
                        fontSize: 14,
                      ),
                      border: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      enabledBorder: InputBorder.none,
                    ),
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  debugPrint("--------send-----------");
                  // Add logic to send the comment
                },
                child: Container(
                  height: 45,
                  margin: EdgeInsets.only(right: 5),
                  child: Center(
                    child: Icon(
                      Icons.send_outlined,
                      color: Colors.grey,
                      size: 32,
                    ),
                  ),
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}
