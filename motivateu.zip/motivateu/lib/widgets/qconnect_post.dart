import 'package:MotivateU/controllers/connection_my_list_controller.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/screens/qreels.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:MotivateU/widgets/qconnect_reusable_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:like_button/like_button.dart';

class QConnectPostList extends StatefulWidget {
  const QConnectPostList({super.key});

  @override
  State<QConnectPostList> createState() => _QConnectPostListState();
}

class _QConnectPostListState extends State<QConnectPostList> {
  var controller = Get.isRegistered<ConnectionMyListController>()
      ? Get.find<ConnectionMyListController>()
      : Get.put(ConnectionMyListController());

  @override
  void initState() {
    super.initState();
    //controller.postList!.clear();
    controller.fetchPost(1); // deleted
    initSp();
  }

  @override
  void dispose() {
    super.dispose();
    controller.dispose();
    debugPrint("DISPOSE====");
  }

  bool isLoading = true;

  Future<void> initSp() async {
    await SharedPreferencesUtils.init();
  }

  @override
  Widget build(BuildContext context) {
    //isLoading = true;
    Future.delayed(Duration(milliseconds: 1500), () {
      if (mounted) {
        // Check if the widget is still mounted before updating the state
        setState(() {
          isLoading = false;
        });
      }
    });

    return
      // Obx(() =>
      // controller.isLoading.value
      isLoading
          ? Expanded(
              child: Container(
              child: Center(
                child: SizedBox(
                  height: 24.h,
                  width: 24.w,
                  child: CircularProgressIndicator(
                    color: Colors.black,
                  ),
                ),
              ),
            ))
          : Expanded(
              child: Container(
                padding: EdgeInsets.only(bottom: 15.h),
                child: NotificationListener<OverscrollIndicatorNotification>(
                  onNotification: (OverscrollIndicatorNotification overscroll) {
                    overscroll.disallowIndicator();
                    return true;
                  },
                  child: Obx(() {
                    //debugPrint("TOP-->PostList=>LikeCount:${controller.postList[1].likesCount},\nDislikeCount:${controller.postList[1].dislikesCount}");
                  //  return
                  return controller.postList.isNotEmpty
                        ? ListView.builder(
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () => controller
                              .postList[index].postType ==
                              "post"
                              ? Get.offNamed(AppRoutes.postComment,
                              arguments: [index])
                              :
                          // Utils.showToastMessage(controller.postList![index].id!),
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => QReels(
                                      // type: 'scenario',
                                      type: 'post',
                                      questionId: controller
                                          .postList[index]
                                          .question!
                                          .id!))),
                          child: Obx(() {
                            return Slidable(
                              key: const ValueKey(0),
                              direction: Axis.horizontal,
                              endActionPane: controller
                                  .postList[index].createdBy!.sId ==
                                  SharedPreferencesUtils.getString(
                                      AppConstants.PROFILE_ID)
                                  ? ActionPane(
                                motion: const ScrollMotion(),
                                children: [
                                  SlidableAction(
                                    onPressed: (context) =>
                                        controller.deletePost(
                                            controller
                                                .postList[index].id!,
                                                () => controller
                                                .fetchPost(1)),
                                    backgroundColor:
                                    Color(0xFFFE4A49),
                                    foregroundColor: Colors.white,
                                    icon: Icons.delete,
                                    label: 'Delete',
                                  ),
                                ],
                              )
                                  : null,
                              child: Container(
                                width: double.maxFinite,
                                decoration: BoxDecoration(
                                    borderRadius:
                                    BorderRadius.circular(6.0),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 0.5,
                                        blurRadius: 0.5,
                                        offset: Offset(0.5, 0.5),
                                      )
                                    ]),
                                margin: EdgeInsets.only(
                                    left: 15.w,
                                    right: 15.w,
                                    top: 5.h,
                                    bottom: 5.h),
                                padding: EdgeInsets.only(
                                    left: 6.w,
                                    right: 6.w,
                                    top: 10.h,
                                    bottom: 10.h),
                                child: Column(
                                  children: [
                                    postViewHeader(
                                        image: 'avatar_img',
                                        name: controller.postList[index]
                                            .createdBy!.name!,
                                        //'Anand Ranjan',
                                        postedOn: controller
                                            .postList[index].createdAt!),
                                    Gap(15.h),
                                    /*reusableSubTitleText(
                                  title: controller.postList![index].postType == "post"?controller.postList![index].postContent!:controller.postList![index].question!,
                                  //"Lorem ipsum dolor sit amet consectetur. Eu nibh odio id sem pulvinar interdum vitae sed. Adipiscing volutpat vulputate curabitur arcu. Viverra urna in auctor nisl ut purus dictum ut. Et id aenean id sociis consectetur leo lectus sem. Vitae volutpat congue euismod cursus neque.",
                                  fontSize: 14,
                                  marginLeft: 0),*/
                                    controller.postList[index].postType == "post"
                                        ? reusableSubTitleText(
                                        title: controller
                                            .postList[index]
                                            .postContent!,
                                        fontSize: 14,
                                        marginLeft: 0)
                                        : Align(
                                      alignment: Alignment.centerLeft,
                                      child: Container(
                                        margin: EdgeInsets.only(
                                            left: 12.w),
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .start,
                                          mainAxisAlignment:
                                          MainAxisAlignment
                                              .spaceEvenly,
                                          children: [
                                            Text(
                                              "Topic: " +
                                                  controller
                                                      .postList[index]
                                                      .question!
                                                      .type!,
                                              textAlign:
                                              TextAlign.left,
                                              style: TextStyle(
                                                  fontSize: 14.sp,
                                                  fontWeight:
                                                  FontWeight.bold,
                                                  color: AppColors
                                                      .BOTTOM_SHEET_BACKGROUND,
                                                  fontFamily:
                                                  "Poppins"),
                                            ),
                                            Text(
                                              "Click here to view",
                                              textAlign:
                                              TextAlign.left,
                                              style: TextStyle(
                                                  fontSize: 14.sp,
                                                  color: AppColors
                                                      .BOTTOM_SHEET_BACKGROUND,
                                                  fontFamily:
                                                  "Poppins"),
                                            ),
                                            Text(
                                              'http://motivateu.co.in/${controller.postList[index].question!.id!}',
                                              style: TextStyle(
                                                color: Colors.blue,
                                                fontSize: 14.sp,
                                                // Set color to blue for a typical link color
                                                decoration:
                                                TextDecoration
                                                    .underline,
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                    /* Obx(() => likeCommentCount(
                                        likeCount:
                                        "${controller.postList[index].likesCount}",
                                        commentCount:
                                        "${controller.postList[index].commentsCount}")),*/
                                    likeCommentCount(
                                        likeCount:
                                        "${controller.postList[index].likesCount}",
                                        commentCount:
                                        "${controller.postList[index].commentsCount}"),
                                    Container(
                                        margin: EdgeInsets.only(top: 15.h),
                                        child: Divider(
                                          color: AppColors.FIELD_HINT_COLOR
                                              .withOpacity(0.8),
                                          height: 1,
                                        )), //Color(0xFFEEEEEE)
                                    Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: [
                                        /*Container(
                                    height: 60,
                                    child: Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        SizedBox(
                                          height: 24.h,
                                          width: 40.w,
                                          child: LikeButton(
                                              onTap:(isLiked) => onLikeButtonTapped(isLiked,index),
                                              // async{
                                              //   controller.likePost(controller.postList[0]![index].id!);
                                              // },
                                              likeBuilder: (isLiked) {
                                                //debugPrint("---isLiked=======>${controller.postList![index].isLiked!}");
                                                // return Obx(() =>controller.postList![index].isLiked!?Icon(Icons.thumb_up,color: AppColors.DEEP_BLUE_COLOR,):Icon(Icons.thumb_up_alt_outlined,),);
                                                return Icon(controller.postList![index].isLiked!?Icons.thumb_up:Icons.thumb_up_alt_outlined,color: controller.postList![index].isLiked!?AppColors.DEEP_BLUE_COLOR:Colors.black);
                                              }
                                          ),
                                        ),
                                        Positioned(
                                          bottom: 0,
                                          child: GestureDetector(
                                            onTap: () => null,
                                            child: Container(
                                              margin: EdgeInsets.only(top: 6.h),
                                              child: Text("Like",style: TextStyle(fontSize: 11.sp,color: AppColors.ACCOUNT_PREVIEW_BOX_COLOR,fontFamily: "Poppins"),)),
                                          ),)
                                      ],
                                    ),
                                  ),*/
                                        Container(
                                          margin:
                                          EdgeInsets.only(top: 15.h),
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              SizedBox(
                                                height: 24.h,
                                                width: 40.w,
                                                child: LikeButton(
                                                    onTap: (isLiked) async {
                                                      //setState(() {
                                                      return controller.isLikedLoading.value ? null
                                                          :onLikeButtonTapped(isLiked, index);
                                                      //});
                                                    },
                                                    // onLikeButtonTapped(isLiked,index),
                                                    // async{
                                                    //   controller.likePost(controller.postList[0]![index].id!);
                                                    // },
                                                    likeBuilder: (isLiked) {
                                                      //debugPrint("---isLiked=======>${controller.postList![index].isLiked!}");
                                                      // return Obx(() =>controller.postList![index].isLiked!?Icon(Icons.thumb_up,color: AppColors.DEEP_BLUE_COLOR,):Icon(Icons.thumb_up_alt_outlined,),);
                                                      return Obx(() => Icon(
                                                          controller
                                                              .postList[
                                                          index]
                                                              .isLiked!
                                                              ? Icons.thumb_up
                                                              : Icons
                                                              .thumb_up_alt_outlined,
                                                          color: controller
                                                              .postList[
                                                          index]
                                                              .isLiked!
                                                              ? AppColors
                                                              .DEEP_BLUE_COLOR
                                                              : Colors.black));
                                                    }),
                                              ),
                                              Container(
                                                  margin: EdgeInsets.only(
                                                      top: 6.h),
                                                  child: Text(
                                                    "Like",
                                                    style: TextStyle(
                                                        fontSize: 11.sp,
                                                        color: AppColors
                                                            .ACCOUNT_PREVIEW_BOX_COLOR,
                                                        fontFamily:
                                                        "Poppins"),
                                                  )),
                                            ],
                                          ),
                                        ),
                                        /*Obx(() => LikeButton(
                                    likeBuilder: (isLiked) {
                                      return Icon(Icons.thumb_up_alt_outlined,size: 24,);
                                    },
                                  )),*/
                                        // controller.isLikedLoading.value?postInteraction("like_fill","like",() => controller.likePost(controller.postList[0]![index].id!)):postInteraction("like","like",() => controller.likePost(controller.postList[0]![index].id!))
                                        //Obx(() => controller.isDisLikedLoading.value?postInteraction("dislike_fill","dislike",() => controller.dislikePost(controller.postList![index].id!,index)):postInteraction("dislike","dislike",() => controller.dislikePost(controller.postList![index].id!,index))),
                                        Obx(() {
                                          /*if (controller.isDisLikedLoading.value) {
                                      return postInteraction("dislike_fill", "dislike", () =>
                                          controller.dislikePost(controller.postList![index].id!, index));
                                    } else {
                                      bool isPostDisliked = controller.postList![index].isDisliked ?? false;

                                      debugPrint("isPostDisliked=======>${isPostDisliked}");

                                      return postInteraction(
                                        isPostDisliked ? "disliked" : "dislike",
                                        "dislike",
                                            () => controller.dislikePost(controller.postList![index].id!, index),isPostDisliked
                                      );
                                    }*/
                                          bool isPostDisliked = controller
                                              .postList[index]
                                              .isDisliked ??
                                              false;

                                          debugPrint(
                                              "isPostDisliked=======>${isPostDisliked}");

                                          return postInteraction(
                                              isPostDisliked
                                                  ? "disliked"
                                                  : "dislike",
                                              "dislike",
                                                  () => controller.isDisLikedLoading.value?null:controller.dislikePost(controller
                                                      .postList[index].id!,
                                                  index),
                                              isPostDisliked);
                                        }),
                                        //postInteraction("dislike","dislike",() => controller.likePost(controller.postList[0]![index].id!)),
                                        postInteraction(
                                            "comment",
                                            "comment",
                                                () => Get.offNamed(
                                                AppRoutes.postComment,
                                                arguments: [index])),
                                        Container(
                                            height: 40.h,
                                            // color: Colors.red,
                                            child: Center(
                                                child: Text("Report Abuse",
                                                    style: TextStyle(
                                                        fontFamily:
                                                        "Poppins",
                                                        color: Color(
                                                            0xFF898989),
                                                        fontSize: 12.sp,
                                                        fontWeight:
                                                        FontWeight
                                                            .w500))))
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            );
                          },
                          ),
                        );
                      },
                      itemCount: controller.postList.length,
                    )
                        : Center(
                      child: Text(
                        "No posts found",
                        style: TextStyle(
                          fontSize: 14.sp,
                          fontFamily: 'Alata',
                        ),
                      ),
                    );
                  }
                  ),
                ),
              )
            );
    // );
  }

  Future<bool> onLikeButtonTapped(bool isLiked, int index) async {
    debugPrint("--isLiked--$isLiked");
    controller.likePost(controller.postList[index].id!, index, isLiked);
    //setState(() {});
    return !isLiked;
  }
}
