import 'package:MotivateU/controllers/reels_filter_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';

class CustomSearchableDropdown extends StatefulWidget {
  final String type;

  const CustomSearchableDropdown({super.key, required this.type});

  @override
  State<CustomSearchableDropdown> createState() => _CustomSearchableDropdownState();
}

class _CustomSearchableDropdownState extends State<CustomSearchableDropdown> {

  var controller = Get.find<ReelsFilterController>();

  @override
  void initState() {
    super.initState();
    if(widget.type == "Chapter"){
      controller.getAllChapters();
    }else if(widget.type == "Topic"){
      controller.getAllTopics();
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        body: Container(
          //alignment: Alignment.center,
          child: ListView(
            shrinkWrap: true,
            // mainAxisSize: MainAxisSize.min,
            children: [
              buildSearchField(searchItem: widget.type,func: (text) {
                controller.filterType.value.text = text;
                widget.type=="Chapter"?controller.getAllChapters():controller.getAllTopics();
              },),
              buildListView(widget.type),
            ],
          ),
        )
    );
  }

  Widget buildSearchField({required String searchItem,
    required void Function(String text) func}) {
    return Container(
      height: 40.h,
      margin: EdgeInsets.only(left: 15.w, right: 15.w, top: 25.w),
      padding: EdgeInsets.symmetric(horizontal: 10.w),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4.0),
          color: Colors.white.withOpacity(0.8),
          border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),
      child: TextFormField(
        enabled: true,
        onChanged: (value) => func(value),
        decoration: InputDecoration(
          hintText: "Search any $searchItem",
          counterText: "",
          errorStyle: TextStyle(height: 0, color: Colors.transparent),
          suffixIcon: Icon(
            Icons.search,
            color: AppColors.FIELD_BORDER_COLOR,
            size: 18,
          ),
          hintStyle: TextStyle(
              color: AppColors.FIELD_HINT_COLOR,
              fontFamily: 'Poppins',
              fontSize: 14.sp),
          border: InputBorder.none,
          focusColor: Colors.transparent,
          focusedBorder: InputBorder.none,
          enabledBorder: InputBorder.none,
        ),
      ),
    );
  }

  Widget buildListView(String type){
    return Obx(() => Container(
      // height: double.maxFinite,
      margin: EdgeInsets.symmetric(horizontal: 12.w,vertical: 12.h),
      child: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (OverscrollIndicatorNotification notification) {
          notification.disallowIndicator();
          return true;
        },
        child: controller.isLoading.value
            ? Center(
              child: SizedBox(
                height: 20.h,
                width: 20.w,
                child: CircularProgressIndicator(
                  color: Colors.black,
                ),
              ),
            )
            :ListView.builder(
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  type=="Chapter"?controller.chapterId.value = controller.chapterData.value.result![index].id!
                  :controller.topicId.value = controller.topicData.value.result![index].id!;

                  type=="Chapter"?controller.chapterController.value.text = controller.chapterData.value.result![index].name!
                      :controller.topicController.value.text = controller.topicData.value.result![index].name!;

                  Navigator.pop(context);
                },
                child: Container(
                  color: Colors.transparent,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.all(10),
                        child: Text(
                            type=="Chapter"?"${controller.chapterData.value.result![index].name}":"${controller.topicData.value.result![index].name}",
                        style: TextStyle(fontSize: 15.sp,fontFamily: "Alata",color: Colors.black),),
                      ),
                      index != (type=="Chapter"?controller.chapterData.value.result!.length - 1:controller.topicData.value.result!.length - 1)
                          ? Divider(
                        color: Colors.grey.withOpacity(0.5),
                      )
                          : Container(),
                    ],
                  ),
                ),
              );
            }, itemCount: type=="Chapter"?controller.chapterData.value.result!.length:controller.topicData.value.result!.length),
      ),
    ),);
  }

}
