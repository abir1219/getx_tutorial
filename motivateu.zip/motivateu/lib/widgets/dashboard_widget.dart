import 'package:MotivateU/screens/qconnect.dart';
import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../screens/account.dart';
import '../screens/hots_pattern.dart';
import '../screens/performance_info.dart';
import '../screens/qreels.dart';

Widget buildPage(int index){
  List<Widget> _pages = [
    PerformanceInfo(),
    HotsPattern(),
    QReels(type: 'reels',),
    QConnect(),
    Account(),
  ];

  return _pages[index];
}


var bottomTabs = [
  TabItem(
    icon: SizedBox(
      height: 34.h,
      width: 34.w,
      child: SvgPicture.asset("assets/icons/dashboard.svg",colorFilter: ColorFilter.mode(Color(0xFF636363), BlendMode.srcIn)),
    ),
    activeIcon: SizedBox(
      height: 34.h,
      width: 34.w,
      child: SvgPicture.asset("assets/icons/dashboard.svg",colorFilter: ColorFilter.mode(Color(0xFFFFFFFF), BlendMode.srcIn)),
    ),
    // title: "QConnect"
  ),
  TabItem(
    icon: SizedBox(
      height: 42.h,
      width: 42.w,
      child:  SvgPicture.asset("assets/icons/hots.svg",colorFilter: ColorFilter.mode(Color(0xFF636363), BlendMode.srcIn)),
    ),
    activeIcon: SizedBox(
      height: 42.h,
      width: 42.w,
      child: SvgPicture.asset("assets/icons/hots.svg",colorFilter: ColorFilter.mode(Color(0xFFFFFFFF), BlendMode.srcIn)),
    ),
    // title: "QConnect"
  ),
  TabItem(
      icon: SizedBox(
        height: 34.h,
        width: 34.w,
        child: SvgPicture.asset("assets/icons/qreels.svg",colorFilter: ColorFilter.mode(Color(0xFF636363), BlendMode.srcIn),),
      ),
      activeIcon: SizedBox(
        height: 34.h,
        width: 34.w,
        child: SvgPicture.asset("assets/icons/qreels.svg",colorFilter: ColorFilter.mode(Color(0xFF000000), BlendMode.srcIn),),
      ),
      // title: "QReels"
  ),
  TabItem(
    icon: SizedBox(
      height: 34.h,
      width: 34.w,
      child: SvgPicture.asset("assets/icons/qconnect.svg",colorFilter: ColorFilter.mode(Color(0xFF636363), BlendMode.srcIn)),
    ),
    activeIcon: SizedBox(
      height: 34.h,
      width: 34.w,
      child: SvgPicture.asset("assets/icons/qconnect.svg",colorFilter: ColorFilter.mode(Color(0xFFFFFFFF), BlendMode.srcIn)),
    ),
    // title: "QConnect"
  ),
  TabItem(
      icon: SizedBox(
        height: 34.h,
        width: 34.w,
        child: SvgPicture.asset("assets/icons/account.svg",colorFilter: ColorFilter.mode(Color(0xFF636363), BlendMode.srcIn)),
      ),
      activeIcon: SizedBox(
        height: 34.h,
        width: 34.w,
        child: SvgPicture.asset("assets/icons/account.svg",colorFilter: ColorFilter.mode(Color(0xFFFFFFFF), BlendMode.srcIn)),
      ),
      // title: "Account"
  ),
];
