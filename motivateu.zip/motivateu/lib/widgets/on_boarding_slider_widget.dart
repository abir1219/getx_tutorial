import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

class PageViewSlider extends StatelessWidget {
  final int index;
  final PageController pageController;
  final String title, subtitle, imgUrl, buttonName;

  PageViewSlider(
      {super.key,
      required this.index,
      required this.pageController,
      required this.title,
      required this.subtitle,
      required this.imgUrl,
      required this.buttonName});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
            width: 375.w,
            margin: EdgeInsets.symmetric(horizontal: 10.w),
            child: Center(
                child: Text(
              title,
              style: GoogleFonts.poppins(
                fontSize: 24.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.black
              )
            ))),
        Container(
            width: 375.w,
            margin: EdgeInsets.only(left: 20.w,right: 20.w,top: 30.w),
            child: Center(
                child: Text(
              subtitle,
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(
                  fontSize: 18.sp,
                  color: Colors.grey.withOpacity(0.5)
              ),
            ))),
        Container(
            height: 252.h,
            width: 380.w,
            margin: EdgeInsets.only(left: 20.w,right: 20.w,top: 40.w),
            child: SvgPicture.asset("assets/icons/$imgUrl",
              fit: BoxFit.contain,)
          /*Image.asset(
            imgUrl,
            fit: BoxFit.cover,
          ),*/
        ),
        CustomButton(
            buttonName: buttonName,
            callback: () {
              debugPrint("------Clicked------");
              if (index < 3) {
                pageController.animateToPage(index,
                    duration: const Duration(milliseconds: 500),
                    curve: Curves.easeIn);
              } else {
                // Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => const SignIn()),(route) => false,);
                //Get.offNamed(AppRoutes.login);
                // Get.offNamed(AppRoutes.login)!.then((value) => Get.back());
                try {
                  Get.offAllNamed(AppRoutes.login);
                } catch (e) {
                  // Handle or log the error here
                  print("Error navigating to login: $e");
                }

              }
            })
      ],
    );
  }
}

/*
Widget PageViewSlider(String headingText,String bodyText,String imageName,String buttonName,void Function() fund){
  return Container();
}*/
