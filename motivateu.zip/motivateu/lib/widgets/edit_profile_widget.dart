import 'dart:io';

import 'package:MotivateU/main.dart';
import 'package:MotivateU/widgets/custom_button.dart';
import 'package:MotivateU/widgets/reusable_sign_up_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../controllers/edit_profile_controller.dart';
import '../controllers/permission_controller.dart';
import '../res/app_colors.dart';
import '../utils/utils.dart';

class EditProfileWidget extends StatefulWidget {
  const EditProfileWidget({super.key});

  @override
  State<EditProfileWidget> createState() => _EditProfileWidgetState();
}

class _EditProfileWidgetState extends State<EditProfileWidget> {
  var controller = Get.find<EditProfileController>();
  File? images;

  Future pickImageGallery() async {
    Utils.showToastMessage("Gallery");
    try {
      XFile? image = await ImagePicker().pickImage(source: ImageSource.gallery);

      if (image == null) return;
      debugPrint("Image Gallery..................=>${image.path}");
      final imageTemp = File(image.path);
      setState(() {
        images = imageTemp;
        controller.updateImageFile(File(image.path));
        debugPrint("Image Gallery=>$images");
      });

      //setState(() => this.image = imageTemp);
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }

  Future pickImageCamera() async {
    Utils.showToastMessage("Camera");
    try {
      XFile? image = await ImagePicker().pickImage(source: ImageSource.camera);

      if (image == null) return;

      final imageTemp = File(image.path);
      setState(() {
        images = imageTemp;
        controller.updateImageFile(File(image.path));
        debugPrint("Image Camera=>$images");
      });
      // setState(() => this.image = imageTemp);
    } on PlatformException catch (e) {
      print('Failed to pick image: $e');
    }
  }

  void checkValidation() {
    RegExp regex = RegExp(r'^[0-9]+$');
    // debugPrint("regex-->$regex");
    // debugPrint("regex-->${regex.hasMatch(controller.authPinController.value.text)}");

    if (controller.nameController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter name");
    }
    /*else if(controller.authPinController.value.text.toString().isEmpty){
      Utils.showToastMessage("Enter Authentication Pin");
    }
    else if(controller.authPinController.value.text.length != 4){
      Utils.showToastMessage("Authentication Pin must be of 4 numbers");
    }
    else if(!regex.hasMatch(controller.authPinController.value.text)){
      Utils.showToastMessage("Authentication Pin can only take numbers");
    }*/
    else if (controller.classController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter class");
    } /*else if (controller.isSelectOtherSchool.value == true &&
        controller.otherSchoolController.value.text.toString().isEmpty) {
      // if(controller.otherSchoolController.value.text.toString().isEmpty){
      Utils.showToastMessage("Enter school");
      // }
    } else if (controller.isSelectOtherSchool.value == false &&
        controller.schoolController.value.text.toString().isEmpty) {
      // if(controller.schoolController.value.text.toString().isEmpty){
      Utils.showToastMessage("Enter school");
      // }
    }*/
    else if(controller.otherSchoolController.value.text.toString().isEmpty && controller.schoolController.value.text.toString().isEmpty){
      Utils.showToastMessage("Enter school");
    }
    // else if(controller.otherSchoolController.value.text.toString().isEmpty || controller.schoolController.value.text.toString().isEmpty){
    //   Utils.showToastMessage("Enter school");
    // }
    // else if(controller.mediumController.value.text.toString().isEmpty){
    //   Utils.showToastMessage("Enter medium");
    // }
    // else if(controller.boardController.value.text.toString().isEmpty){
    //   Utils.showToastMessage("Enter board");
    // }
    else {
      debugPrint("validity signUp");
      controller.updateProfile();
    }
  }

  @override
  void initState() {
    super.initState();
    controller.getProfileForEdit(Get.arguments[0]);
    controller.getClass();
    controller.getMedium();
    controller.getBoard();
    controller.getSchool();
  }


  // final PermissionController permissionController = Get.put(PermissionController());

  @override
  void dispose() {
    super.dispose();
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Container(
        width: double.maxFinite,
        child: controller.isLoading.value
            ? Container(
                height: double.maxFinite,
                child: Center(
                  child: SizedBox(
                    height: 24.h,
                    width: 24.w,
                    child: CircularProgressIndicator(
                      color: Colors.black,
                    ),
                  ),
                ),
              )
            : Column(
                children: [
                  GestureDetector(
                    onTap: () => Get.back(),
                    child: Container(
                      height: MediaQuery.of(context).size.height * .09,
                      margin: EdgeInsets.only(left: 15.w), //,top: 30.h
                      child: Center(
                        child: Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 24.h,
                                width: 24.w,
                                child: Icon(
                                  Icons.arrow_back_ios_new_outlined,
                                  color: AppColors.BACK_ARROW_COLOR,
                                ),
                              ),
                              Gap(5.h),
                              Text("Back",
                                  style: TextStyle(
                                      fontSize: 20.sp,
                                      color: AppColors.FIELD_HINT_COLOR,
                                      fontFamily: 'Poppins'))
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                      child:
                          NotificationListener<OverscrollIndicatorNotification>(
                    onNotification:
                        (OverscrollIndicatorNotification notification) {
                      notification.disallowIndicator();
                      return true;
                    },
                    child: SingleChildScrollView(
                      child: Obx(
                        () => Container(
                          margin: EdgeInsets.only(left: 12.w, right: 12.w),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Gap(12.w),
                              Container(
                                alignment: Alignment.centerLeft,
                                margin: EdgeInsets.only(top: 20.w),
                                //left: 12.w, right: 12.w,
                                child: Text(
                                  "Please update your profile",
                                  style: TextStyle(
                                      fontFamily: "Poppins",
                                      fontWeight: FontWeight.w600,
                                      fontSize: 18.sp,
                                      color:
                                          AppColors.ON_BOARDING_BUTTON_COLOR),
                                ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  reusableFieldText("Name"),
                                  Icon(
                                    Icons.star,
                                    color: Colors.red,
                                    size: 10.w,
                                  ),
                                ],
                              ),
                              reusableTextField(
                                "Enter Your Name",
                                controller.nameController.value,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  reusableFieldText(
                                    "Photo",
                                  ),
                                ],
                              ),
                              GestureDetector(
                                onTap: () async{

                                  debugPrint("cameraStatus==>${await Permission.camera.status}");
                                  debugPrint("photoStatus==>${await Permission.photos.status}");

                                  if(await Permission.camera.status == PermissionStatus.granted && await Permission.photos.status == PermissionStatus.granted ){
                                    showDialog(
                                      context: context,
                                      builder: (ctx) => AlertDialog(
                                        title: const Text("Choose Image From"),
                                        content: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                          children: [
                                            GestureDetector(
                                              onTap: () {
                                                pickImageCamera();
                                                Navigator.pop(context);
                                              },
                                              //debugPrint("------1st---------"),
                                              child: Container(
                                                height: 50,
                                                child: Center(
                                                  child: Icon(
                                                    Icons.camera_alt_sharp,
                                                    size: 40.h,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            GestureDetector(
                                              onTap: () {
                                                pickImageGallery();
                                                Navigator.pop(context);
                                              },
                                              //debugPrint("------2nd---------"),
                                              child: Container(
                                                height: 80,
                                                child: Center(
                                                  child: Icon(
                                                    Icons.image,
                                                    size: 40.h,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  }else{
                                    Utils.showToastMessage("Please grant camera and gallery permissions to use this");
                                    //permissionController.requestPermissions();
                                    setUpPermission();
                                  }
                                },
                                child: Container(
                                  height:
                                      MediaQuery.of(context).size.height * .2,
                                  color: AppColors.ON_BOARDING_BUTTON_COLOR
                                      .withOpacity(0.3),
                                  margin: EdgeInsets.only(top: 10.w),
                                  child: Center(
                                    child: Stack(
                                      children: [
                                        Container(
                                          height: 110.h,
                                          width: 110.w,
                                          // color: Colors.red,
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10000),
                                          ),
                                          child: ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(10000),
                                            child: controller.selectedImage !=
                                                    null
                                                ? Image.file(
                                                    controller.selectedImage!,
                                                    fit: BoxFit.fill,
                                                    filterQuality:
                                                        FilterQuality.high)
                                                : Image.asset(
                                                    "assets/icons/avatar_img.png",
                                                    fit: BoxFit.fill,
                                                    filterQuality:
                                                        FilterQuality.high),
                                          ),
                                        ),
                                        Positioned(
                                            bottom: 0,
                                            right: 5.w,
                                            child: Container(
                                              height: 28.h,
                                              width: 28.w,
                                              child: Icon(
                                                Icons.camera_alt_outlined,
                                                color: Colors.white,
                                                size: 20.w,
                                              ),
                                            ))
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              /*Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            reusableFieldText(
                              "Authentication Pin",
                            ),
                            Icon(
                              Icons.star,
                              color: Colors.red,
                              size: 10.w,
                            ),
                          ],
                        ),
                        reusableTextField(
                          "Enter authentication pin (e.g: 1234)", controller.authPinController.value,),*/
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  reusableFieldText(
                                    "Class",
                                  ),
                                  Icon(
                                    Icons.star,
                                    color: Colors.red,
                                    size: 10.w,
                                  ),
                                ],
                              ),
                              reusableDropDownField(
                                  "Select your class",
                                  controller.classController.value,
                                  controller.isSelectClass.value, () {
                                controller.isSelectClass.value =
                                    !controller.isSelectClass.value;
                              }),
                              controller.isSelectClass.value
                                  ? buildClassDropDownList()
                                  : Container(),
                              // Text("${controller.classData.value.result}"),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  reusableFieldText(
                                    "School",
                                  ),
                                  Icon(
                                    Icons.star,
                                    color: Colors.red,
                                    size: 10.w,
                                  ),
                                ],
                              ),
                              reusableDropDownField(
                                  "Select your school",
                                  controller.schoolController.value,
                                  controller.isSelectSchool.value, () {
                                controller.isSelectSchool.value =
                                    !controller.isSelectSchool.value;
                              }),
                              controller.isSelectSchool.value
                                  ? buildSchoolDropDownList()
                                  : Container(),
                              controller.isSelectOtherSchool.value
                                  ? Container(
                                      height: 45.h,
                                      margin: EdgeInsets.only(
                                        top: 8.w,
                                      ),
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 10.w),
                                      decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(4.0),
                                          color: Colors.white.withOpacity(0.8),
                                          border: Border.all(
                                              color: AppColors
                                                  .FIELD_BORDER_COLOR)),
                                      child: TextFormField(
                                        controller: controller
                                            .otherSchoolController.value,
                                        autofocus: true,
                                        keyboardType: TextInputType.text,
                                        decoration: InputDecoration(
                                          hintText: "Enter your school name",
                                          counterText: "",
                                          errorStyle: TextStyle(
                                              height: 0,
                                              color: Colors.transparent),
                                          hintStyle: TextStyle(
                                              color: AppColors.FIELD_HINT_COLOR,
                                              fontFamily: 'Poppins',
                                              fontSize: 14.sp),
                                          border: InputBorder.none,
                                          focusColor: Colors.transparent,
                                          focusedBorder: InputBorder.none,
                                          enabledBorder: InputBorder.none,
                                        ),
                                      ),
                                    )
                                  : Container(),

                              /*Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            reusableFieldText(
                              "Medium",
                            ),
                            Icon(
                              Icons.star,
                              color: Colors.red,
                              size: 10.w,
                            ),
                          ],
                        ),
                        reusableDropDownField(
                            "Select your medium",
                            controller.mediumController.value,
                            controller.isSelectMedium.value,
                                () {
                              controller.isSelectMedium.value =
                              !controller.isSelectMedium.value;
                            }),
                        controller.isSelectMedium.value
                            ? buildMediumDropDownList()
                            : Container(),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            reusableFieldText(
                              "Board",
                            ),
                            Icon(
                              Icons.star,
                              color: Colors.red,
                              size: 10.w,
                            ),
                          ],
                        ),
                        reusableDropDownField(
                            "Select your board",
                            controller.boardController.value,
                            controller.isSelectBoard.value,
                                () {
                              controller.isSelectBoard.value =
                              !controller.isSelectBoard.value;
                            }),
                        controller.isSelectBoard.value
                            ? buildBoardDropDownList()
                            : Container(),*/
                              controller.editProfileModel.value.result![0].group!
                                          .length ==
                                      0
                                  ? Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        buildCheckboxField(
                                            "Accept to add into groups",
                                            "group"),
                                        Icon(
                                          Icons.star,
                                          color: Colors.red,
                                          size: 10.w,
                                        ),
                                      ],
                                    )
                                  : Container(),
                              CustomButton(
                                buttonName: "EDIT PROFILE",
                                callback: () => checkValidation(),
                                loading: controller.isUpldateLoading.value,
                              ),
                              Gap(35.w)
                            ],
                          ),
                        ),
                      ),
                    ),
                  ))
                ],
              ),
      ),
    );
  }

  Widget buildClassDropDownList() {
    return Container(
      margin: EdgeInsets.only(top: 4.h),
      padding: EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.black, width: 0.2)),
      child: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (OverscrollIndicatorNotification notification) {
          notification.disallowIndicator();
          return true;
        },
        child: ListView.builder(
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                controller.classController.value.text =
                    controller.classData.value.result![index].name!;
                controller.isSelectClass.value =
                    !controller.isSelectClass.value;

                controller.classId.value =
                    controller.classData.value.result![index].sId!;
              },
              child: Container(
                color: Colors.transparent,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        "${controller.classData.value.result![index].name}"),
                    index != controller.classData.value.result!.length - 1
                        ? Divider(
                            color: Colors.grey.withOpacity(0.5),
                          )
                        : Container(),
                  ],
                ),
              ),
            );
          },
          itemCount: controller.classData.value.result!.length,
        ),
      ),
    );
  }

  Widget buildMediumDropDownList() {
    return Container(
      margin: EdgeInsets.only(top: 4.h),
      padding: EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.black, width: 0.2)),
      child: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (OverscrollIndicatorNotification notification) {
          notification.disallowIndicator();
          return true;
        },
        child: ListView.builder(
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                controller.mediumController.value.text =
                    controller.mediumData.value.result![index].name!;
                controller.isSelectMedium.value =
                    !controller.isSelectMedium.value;
                controller.mediumId.value =
                    controller.mediumData.value.result![index].id!;
              },
              child: Container(
                color: Colors.transparent,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        "${controller.mediumData.value.result![index].name}"),
                    index != controller.mediumData.value.result!.length - 1
                        ? Divider(
                            color: Colors.grey.withOpacity(0.5),
                          )
                        : Container(),
                  ],
                ),
              ),
            );
          },
          itemCount: controller.mediumData.value.result!.length,
        ),
      ),
    );
  }

  Widget buildBoardDropDownList() {
    return Container(
      margin: EdgeInsets.only(top: 4.h),
      padding: EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.black, width: 0.2)),
      child: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (OverscrollIndicatorNotification notification) {
          notification.disallowIndicator();
          return true;
        },
        child: ListView.builder(
          shrinkWrap: true,
          physics: AlwaysScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                controller.boardController.value.text =
                    controller.boardData.value.result![index].name!;
                controller.isSelectBoard.value =
                    !controller.isSelectBoard.value;

                controller.boardId.value =
                    controller.boardData.value.result![index].id!;
              },
              child: Container(
                color: Colors.transparent,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        "${controller.boardData.value.result![index].name}"),
                    index != controller.boardData.value.result!.length - 1
                        ? Divider(
                            color: Colors.grey.withOpacity(0.5),
                          )
                        : Container(),
                  ],
                ),
              ),
            );
          },
          itemCount: controller.boardData.value.result!.length,
        ),
      ),
    );
  }

  Widget buildSchoolDropDownList() {
    return Container(
      margin: EdgeInsets.only(top: 4.h),
      padding: EdgeInsets.only(left: 6.h, top: 10.h, bottom: 10.h, right: 6.h),
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: Colors.black, width: 0.2)),
      child: NotificationListener<OverscrollIndicatorNotification>(
        onNotification: (OverscrollIndicatorNotification notification) {
          notification.disallowIndicator();
          return true;
        },
        child: ListView.builder(
          shrinkWrap: true,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                controller.schoolController.value.text =
                    controller.schoolData.value.result![index].name!;
                controller.isSelectSchool.value = false;

                controller.isSelectOtherSchool.value = false;
              },
              child: Container(
                color: Colors.transparent,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                        "${controller.schoolData.value.result![index].name}"),
                    index != controller.schoolData.value.result!.length - 1
                        ? Divider(
                            color: Colors.grey.withOpacity(0.5),
                          )
                        : Container(),
                    index == controller.schoolData.value.result!.length - 1
                        ? GestureDetector(
                            onTap: () {
                              controller.schoolController.value.text = "Other";
                              controller.isSelectSchool.value = false;
                              controller.isSelectOtherSchool.value = true;
                            },
                            child: Container(
                              height: 45.h,
                              width: double.maxFinite,
                              alignment: Alignment.centerLeft,
                              margin: EdgeInsets.only(
                                top: 8.w,
                              ),
                              padding: EdgeInsets.symmetric(horizontal: 10.w),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.0),
                                  color: Colors.white.withOpacity(0.8),
                                  border: Border.all(
                                      color: AppColors.FIELD_BORDER_COLOR
                                          .withOpacity(0.3))),
                              child: Text(
                                "Other",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: AppColors.FIELD_HINT_COLOR,
                                    fontFamily: 'Poppins',
                                    fontSize: 16.sp),
                              ),
                            ),
                          )
                        : Container(),
                  ],
                ),
              ),
            );
          },
          itemCount: controller.schoolData.value.result!.length,
        ),
      ),
    );
  }

  Widget buildCheckboxField(String label, String type) {
    return Container(
      color: Colors.white.withOpacity(0.5),
      child: Row(
        children: [
          Checkbox(
              value: controller.isSelectGroup.value,
              onChanged: (value) {
                controller.isSelectGroup.value = value!;
              }),
          Text(
            label,
            style: TextStyle(
                fontSize: 14.sp, color: Colors.black, fontFamily: "Alata"),
          )
        ],
      ),
    );
  }
}
