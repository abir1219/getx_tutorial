import 'package:MotivateU/controllers/login_controller.dart';
import 'package:MotivateU/controllers/otp_controller.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/widgets/custom_button.dart';
import 'package:MotivateU/widgets/reusable_sign_in_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../res/app_colors.dart';
import '../utils/utils.dart';

class LoginFormWidgets extends StatefulWidget {
  const LoginFormWidgets({super.key});

  @override
  State<LoginFormWidgets> createState() => _LoginFormWidgetsState();
}

class _LoginFormWidgetsState extends State<LoginFormWidgets> {
  LoginController controller = Get.find<LoginController>();

  void validateForm() {
    if (controller.phoneController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter Mobile No");
    } else if (controller.phoneController.value.text.toString().length != 10) {
      Utils.showToastMessage("Enter a valid Mobile Number");
    } else if (controller.passwordController.value.text.toString().isEmpty) {
      Utils.showToastMessage("Enter your password");
    } else {
      controller.login();
    }
  }

  @override
  void initState() {
    super.initState();

  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    controller.checkIfRemembered();

    return NotificationListener<OverscrollIndicatorNotification>(
      onNotification: (OverscrollIndicatorNotification overscroll) {
        overscroll.disallowIndicator();
        return true;
      },
      child: SingleChildScrollView(
        child: Obx(() =>  Column(
            // shrinkWrap: true,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              reusableTitleText("Welcome to MotivateU"),
              reusableSubTitleText("Please login to continue our app"),
              reusableFieldText("Mobile"),
              reusableField(
                context,
                "Your mobile no.",
                controller.phoneController.value,
                controller.phoneFocusNode.value,
                controller.passwordFocusNode.value,
                "ph",
              ),
              reusableFieldText("Password"),
              // reusableField(
              //     context,
              //     "Your password",
              //     controller.passwordController.value,
              //     controller.passwordFocusNode.value,
              //     null,
              //     "password"),

              reusablePasswordField("Your Password", controller.passwordController.value,controller.isPasswordVisible.value,() {
                controller.isPasswordVisible.value = !controller.isPasswordVisible.value;
              },"password",),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      if (controller.phoneController.value.text.isEmpty) {
                        Utils.showToastMessage("Please enter mobile number");
                      }
                      if (controller.phoneController.value.text.toString().length != 10) {
                        Utils.showToastMessage("Please enter a valid mobile number");
                      } else {
                        controller.sendOtp();
                        AppConstants.TYPE = "login";
                        Get.isRegistered<OtpController>()
                            ? Get.find<OtpController>().verifyType.value = "login"
                            : Get.put(OtpController()).verifyType.value = "login";
                        //Get.toNamed(AppRoutes.otp,arguments: [controller.phoneController.value.text.toString()]);
                      }
                    },
                    child: Container(
                        margin: EdgeInsets.only(top: 30.w, left: 25.w),
                        child: Text("Login via OTP?",
                            style: TextStyle(
                                fontSize: 16.sp,
                                color: AppColors.DEEP_BLUE_COLOR,
                                fontFamily: 'Poppins'))),
                  ),
                  GestureDetector(
                    onTap: () {
                      AppConstants.TYPE = "forgetPw";
                      Get.isRegistered<OtpController>()
                          ? Get.find<OtpController>().verifyType.value =
                      "forgetPw"
                          : Get.put(OtpController()).verifyType.value =
                      "forgetPw";
                      Get.toNamed(AppRoutes.mobile);
                      if (Get.isRegistered<OtpController>())
                        Get.find<OtpController>().phController.value.text = "";
                    },
                    child: Container(
                        margin: EdgeInsets.only(top: 30.w, right: 25.w),
                        child: Text("Forget Password?",
                            style: TextStyle(
                                fontSize: 16.sp,
                                color: AppColors.DEEP_BLUE_COLOR,
                                fontFamily: 'Poppins'))),
                  )
                ],
              ),
              checkBoxRow("Remember me"),
              Obx(
                () => Center(
                  child: CustomButton(
                    buttonName: "LOGIN",
                    callback: () => validateForm(),
                    loading: controller.isLoading.value,
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                      margin:
                          EdgeInsets.only(top: 20.w, left: 25.w, right: 2.w),
                      child: Text("Don't have account?",
                          style: TextStyle(
                              fontSize: 16.sp,
                              color: AppColors.FIELD_HINT_COLOR,
                              fontFamily: 'Poppins'))),
                  GestureDetector(
                    // onTap: () => Get.toNamed(AppRoutes.signup),
                    onTap: () {
                      AppConstants.TYPE = "signup";
                      Get.isRegistered<OtpController>()
                          ? Get.find<OtpController>().verifyType.value =
                              "signup"
                          : Get.put(OtpController()).verifyType.value =
                              "signup";
                      Get.toNamed(AppRoutes.mobile);
                      if (Get.isRegistered<OtpController>())
                        Get.find<OtpController>().phController.value.text = "";
                    },
                    child: Container(
                        margin:
                            EdgeInsets.only(top: 20.w, right: 25.w, left: 2.w),
                        child: Text("Sign Up",
                            style: TextStyle(
                                fontSize: 16.sp,
                                color: AppColors.DEEP_BLUE_COLOR,
                                fontFamily: 'Poppins'))),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
