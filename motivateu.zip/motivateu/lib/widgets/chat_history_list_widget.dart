import 'package:MotivateU/controllers/chat_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import 'chat_list_member_widget.dart';

class ChatHistoryListWidget extends StatefulWidget {
  const ChatHistoryListWidget({super.key});

  @override
  State<ChatHistoryListWidget> createState() => _ChatHistoryListWidgetState();
}

class _ChatHistoryListWidgetState extends State<ChatHistoryListWidget> {
  var controller = Get.find<ChatController>();

  @override
  void initState() {
    super.initState();
    controller.getChatList();
  }

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Expanded(
        child: controller.isLoading.value
            ? Container(
                // height: double.maxFinite,
                child: Center(
                  child: SizedBox(
                    height: 20.h,
                    width: 20.w,
                    child: CircularProgressIndicator(color: Colors.black),
                  ),
                ),
              )
            : controller.chatListModel.value.chats!.length > 0
                ? Container(
                    margin: EdgeInsets.only(top: 25.h),
                    child:
                        NotificationListener<OverscrollIndicatorNotification>(
                      onNotification:
                          (OverscrollIndicatorNotification overscroll) {
                        overscroll.disallowIndicator();
                        return true;
                      },
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemBuilder: (context, index) =>
                            // chatMembers(image: 'avatar_img', name: 'John Doe', lastMsg: 'lorem ipsum dolor',lastMsgTime:'04:26pm', func: () {  })
                            chatMembers(
                                image: 'avatar_img',
                                name: controller.chatListModel.value
                                    .chats![index].participants![0].name!,
                                lastMsg:
                                    "${controller.chatListModel.value.chats![index].lastMessage!.message}",
                                lastMsgTime:
                                    '${DateFormat('d MMMM yyyy').format(DateTime.parse(controller.chatListModel.value.chats![index].lastMessage!.createdAt!).toLocal())}',
                                func: () {},
                                roomID: controller.chatListModel.value.chats![index].sId!, participantName: controller.chatListModel.value.chats![index].participants![0].name!,),
                        itemCount: controller.chatListModel.value.chats!.length,
                      ),
                    ))
                : Container(
                    // height: double.maxFinite,
                    child: Center(
                      child: SizedBox(
                        child: Text("No records found"),
                      ),
                    ),
                  ),
      );
    });
  }
}

//chatMembers(image: 'avatar_img', name: 'John Doe', lastMsg: 'Class VII',lastMsgTime:'04:26pm', func: () {  }),
