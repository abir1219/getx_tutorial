import 'package:MotivateU/controllers/reels_filter_controller.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/widgets/custom_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../controllers/reels_controller.dart';
import '../res/app_colors.dart';
import 'custom_searchable_dropdown.dart';

class FilterWidget extends StatefulWidget {
  const FilterWidget({Key? key}) : super(key: key);

  @override
  State<FilterWidget> createState() => _FilterWidgetState();
}

class _FilterWidgetState extends State<FilterWidget> {
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    Get.find<ReelsFilterController>().getAllSubjects();
  }

  int selectedCount = -1;

  @override
  Widget build(BuildContext context) {

    return Obx(() => Get.find<ReelsFilterController>().isLoading.value?
    Center(
      child: SizedBox(
          height: 24.h,
          width: 24.w,
          child: CircularProgressIndicator(color: Colors.black,)),
    )
        :SingleChildScrollView(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () => Get.back(),
                child: Container(
                  margin: EdgeInsets.only(top: 30.w, left: 15.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 24.h,
                        width: 24.w,
                        child: Icon(
                          Icons.arrow_back_ios_new_outlined,
                          color: AppColors.BACK_ARROW_COLOR,
                        ),
                      ),
                      Gap(5.h),
                      Text("Back",
                          style: TextStyle(
                              fontSize: 20.sp,
                              color: AppColors.FIELD_HINT_COLOR,
                              fontFamily: 'Poppins'))
                    ],
                  ),
                ),
              ),
              /*GestureDetector(
            onTap: () => Utils.showToastMessage("Click"),
            child: Container(
              height: 50.h,
              width: 50.w,
              margin: EdgeInsets.only(top: 30.w,right: 30.w),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(200),
                color: AppColors.ON_BOARDING_BUTTON_COLOR
              ),
              child: Center(
                child: Container(
                    // height: 40.h,
                    // width: 40.w,
                    color: Colors.transparent,
                    //margin: EdgeInsets.all(35.w),
                    child: Center(
                        child: IconButton(
                            icon: Icon(
                              Icons.arrow_forward_ios_rounded,
                              size: 36.w,
                              color: Colors.white,
                            ),
                            onPressed: () {}))),
              ),
            ),
          ),*/
            ],
          ),
          Container(
            margin: EdgeInsets.only(top: 20.h, left: 15.w),
            alignment: Alignment.centerLeft,
            child: Text(
              "Filter your search...",
              style: TextStyle(
                  fontSize: 16.sp,
                  color: Colors.black.withOpacity(0.40),
                  fontWeight: FontWeight.w500),
            ),
          ),
          /*Container(
        height: 40.h,
        margin: EdgeInsets.only(top: 15.w, left: 20.w, right: 20.w),
        padding: EdgeInsets.symmetric(horizontal: 10.w),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4.0),
            border: Border.all(color: const Color(0xFF3F3F3F))),
        child: TextField(
          //obscureText: type == "password" ? true : false,
          // keyboardType:
          // type == "password" ? TextInputType.text : TextInputType.phone,
          // maxLength: type == "ph" ? 10 : 20,
          decoration: InputDecoration(
            hintText: "Select Subject",
            counterText: "",
            hintStyle: TextStyle(color: Colors.black, fontSize: 14.sp),
            border: InputBorder.none,
            focusColor: Colors.transparent,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
          ),
        ),
      ),*/

          Container(
            margin: EdgeInsets.only(left: 15.w, right: 15.w, top: 25.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Select Subject",
                  style: TextStyle(
                      fontSize: 16.sp,
                      color: Colors.black.withOpacity(0.40),
                      fontWeight: FontWeight.w500),
                ),
                Gap(10.h),
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      childAspectRatio: 2.5,
                      crossAxisSpacing: 5,
                      mainAxisSpacing: 5),
                  itemBuilder: (context, index) {
                    return buildSubject(Get.find<ReelsFilterController>().subjectData.value.result![index].id!,Get.find<ReelsFilterController>().subjectData.value.result![index].name!,index);
                  },
                  itemCount: Get.find<ReelsFilterController>().subjectData.value.result!.length,
                ),
              ],
            ),
          ),
          buildSearchField("Chapter", () {
            showDialog(
              context: context,
              builder: (context) {
                return CustomSearchableDropdown(type: 'Chapter');
              },
            );
          }, Get.find<ReelsFilterController>().chapterController.value),
          buildSearchField("Topic", () {
            showDialog(
              context: context,
              builder: (context) {
                return CustomSearchableDropdown(type: 'Topic');
              },
            );
          }, Get.find<ReelsFilterController>().topicController.value),
          buildSearchField('Keyword ( separate by  "," )', () {},
              Get.find<ReelsFilterController>().keywordController.value),
          CustomButton(
              buttonName: "APPLY FILTER",
              callback: () {
                if (Get.find<ReelsFilterController>()
                    .keywordController
                    .value
                    .text
                    .isNotEmpty ||
                    Get
                        .find<ReelsFilterController>()
                        .topicController
                        .value
                        .text
                        .isNotEmpty ||
                    Get.find<ReelsFilterController>()
                        .chapterController
                        .value
                        .text
                        .isNotEmpty ||
                    Get.find<ReelsFilterController>()
                        .subjectId
                        .value
                        .isNotEmpty) {
                  setState(() {
                    isLoading = true;
                  });
                }

                Get.find<ReelsController>().keywordList.value =
                Get.find<ReelsFilterController>()
                    .keywordController
                    .value
                    .text
                    .isEmpty
                    ? []
                    : Get.find<ReelsFilterController>()
                    .keywordController
                    .value
                    .text
                    .split(",");
                Get.find<ReelsController>().chapterId.value =
                    Get.find<ReelsFilterController>().chapterId.value;
                Get.find<ReelsController>().topicId.value =
                    Get.find<ReelsFilterController>().topicId.value;
                Get.find<ReelsController>().subjectId.value =
                    Get.find<ReelsFilterController>().subjectId.value;

                Get.find<ReelsFilterController>().chapterId.value = "";
                Get.find<ReelsFilterController>().topicId.value = "";
                Get.find<ReelsFilterController>().subjectId.value = "";

                Get.find<ReelsFilterController>().keywordController.value.text =
                "";
                Get.find<ReelsFilterController>().topicController.value.text =
                "";
                Get.find<ReelsFilterController>().chapterController.value.text =
                "";

                // Utils.showToastMessage("Click");
                isLoading == true
                    ? Future.delayed(Duration(seconds: 2),
                        () => Get.toNamed(AppRoutes.dashboard))
                    : Get.toNamed(AppRoutes.dashboard);
              },
              loading: isLoading),
        ],
      ),
    ));
  }

  Widget buildSubject(String subId,String title,int index) {
    return Obx(() => GestureDetector(
        onTap: () {
          setState(() {
            // selectedCount = index;
            Get.find<ReelsFilterController>().subjectId.value = subId;
            Get.find<ReelsFilterController>().selectedIndex.value = index;
          },);
        },
        child: Container(
          // height: 45.h,
          decoration: BoxDecoration(
            border: Border.all(
              color: selectedCount==index?AppColors.SLIDER_DOTTED_COLOR:Color(0xFFADADAD),
            ),
          ),
          child: Center(
              child: Text(
            title,
            style:
                TextStyle(color: Get.find<ReelsFilterController>().selectedIndex.value==index?AppColors.SLIDER_DOTTED_COLOR:Colors.black.withOpacity(0.38),
                    fontWeight: Get.find<ReelsFilterController>().selectedIndex.value==index?FontWeight.bold:FontWeight.normal,
                    fontSize: 14.sp),
          )),
        ),
      ),
    );
  }

  Widget buildSearchField(
    String searchItem,
    void Function() func,
    TextEditingController controller,
  ) {
    return GestureDetector(
      onTap: func,
      child: Container(
        // height: 40.h,
        margin: EdgeInsets.only(left: 15.w, right: 15.w, top: 25.w),
        padding: EdgeInsets.symmetric(horizontal: 10.w),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4.0),
            color: Colors.white.withOpacity(0.8),
            border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),
        child: TextFormField(
          enabled: searchItem.contains("Keyword") ? true : false,
          controller: controller,
          maxLines: null,
          decoration: InputDecoration(
            hintText: searchItem,
            counterText: "",
            errorStyle: TextStyle(height: 0, color: Colors.transparent),
            suffixIcon: Icon(
              Icons.search,
              color: AppColors.FIELD_BORDER_COLOR,
              size: 18,
            ),
            hintStyle: TextStyle(
                color: AppColors.FIELD_HINT_COLOR,
                fontFamily: 'Poppins',
                fontSize: 14.sp),
            border: InputBorder.none,
            focusColor: Colors.transparent,
            focusedBorder: InputBorder.none,
            enabledBorder: InputBorder.none,
          ),
        ),
      ),
    );
  }

  Future<void> _refreshData() async {
    try {
      // Reset selectedCount and fetch new data
      selectedCount = -1;
      await Get.find<ReelsFilterController>().getAllSubjects();
      Get.find<ReelsFilterController>().chapterId.value = "";
      Get.find<ReelsFilterController>().topicId.value = "";
      Get.find<ReelsFilterController>().subjectId.value = "";
      Get.find<ReelsFilterController>().keywordController.value.text = "";
      Get.find<ReelsFilterController>().topicController.value.text = "";
      Get.find<ReelsFilterController>().chapterController.value.text = "";
    } catch (e) {
      // Handle any errors that occur during data refresh
      debugPrint("Error during data refresh: $e");
    }
  }
}
