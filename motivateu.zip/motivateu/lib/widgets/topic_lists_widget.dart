import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../controllers/hots_topics_controller.dart';
import '../controllers/reels_controller.dart';
import '../res/app_colors.dart';
import '../screens/alert_message_screen.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class TopicListsWidget extends StatefulWidget {
  final String subjectId;

  const TopicListsWidget({super.key, required this.subjectId});

  @override
  State<TopicListsWidget> createState() => _TopicListsWidgetState();
}

class _TopicListsWidgetState extends State<TopicListsWidget> {
  var controller = Get.find<HotsTopicsController>();

  @override
  void initState() {
    super.initState();
    // controller.getTopicsList(widget.subjectId);
  }

  @override
  void dispose() {
    super.dispose();
    // controller.stopTimerTrack();
    if(!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!){
      controller.stopTimerTrack();
    }
  }

  @override
  Widget build(BuildContext context) {
    /*if(!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!
        && SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! > 0){
      controller.startTimerTrack();
    }*/

    if (!SharedPreferencesUtils.getBool(AppConstants.isSUBSCRIBED)!){
      if(SharedPreferencesUtils.getInt(AppConstants.LEFT_TIME)! > 0){
        // controller.startTimer();
        controller.startTimerTrack();
        controller.getTopicsList(widget.subjectId);
      }else {
        controller.haveTime.value = false;
        debugPrint("noooooooooooooo");
      }
    }else{
      //controller.startTimerTrack();
      controller.getTopicsList(widget.subjectId);
    }

    return Scaffold(
      body: WillPopScope(
        onWillPop: () async{
          // Get.offNamed(AppRoutes.dashboard,arguments: [1]);
          Get.offNamed(AppRoutes.dashboard,parameters: {'pageIndex':'1'});
          return true;
        },
        child: Obx(
          () => Container(
              color: Colors.white,
              width: double.maxFinite,
              height: double.maxFinite,
              child: controller.haveTime.value
                  ? controller.isLoading.value
                      ? Center(
                          child: SizedBox(
                            height: 24.h,
                            width: 24.w,
                            child: const CircularProgressIndicator(
                              color: Colors.black,
                            ),
                          ),
                        )
                      : controller.hotsTopicModel.value.result != null
                          ? NotificationListener<OverscrollIndicatorNotification>(
                              onNotification:
                                  (OverscrollIndicatorNotification notification) {
                                notification.disallowIndicator();
                                return true;
                              },
                              child: ListView.builder(
                                shrinkWrap: true,
                                itemBuilder: (context, index) =>
                                    buildTopicContainer(index),
                                itemCount: controller
                                    .hotsTopicModel.value.result!.length,
                              ))
                          : AlertMessageScreen(
                              callback: () =>
                                  controller.getTopicsList(widget.subjectId),
                            )
                  : Container(
                      child: Center(
                          child: Text("No free minutes available for the day")),
                    )),
        ),
      ),
    );
  }

  Widget buildTopicContainer(int index) {
    return GestureDetector(
      onTap: () => Get.offNamed(AppRoutes.Scenario, arguments: [index,widget.subjectId]),
      child: Container(
          width: double.maxFinite,
          // height: 45.h,
          margin: EdgeInsets.symmetric(vertical: 4.h, horizontal: 8.w),
          decoration: BoxDecoration(
              color: AppColors.ON_BOARDING_BUTTON_COLOR.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8.sp)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                height: 35.h,
                width: 35.w,
                margin: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100.sp),
                    color: AppColors.BOTTOM_NAVIGATION_BAR_COLOR),
                child: Center(
                    child: Text(
                  "${index + 1}",
                  style: TextStyle(
                      fontSize: 14.sp,
                      color: Colors.white,
                      fontWeight: FontWeight.normal),
                )),
              ),
              Expanded(
                  child: Container(
                      margin: EdgeInsets.only(left: 12.w),
                      child: Text(
                          "${controller.hotsTopicModel.value.result![index].title}",
                          style:
                              TextStyle(fontSize: 16.sp, color: Colors.black))))
            ],
          )),
    );
  }
}
