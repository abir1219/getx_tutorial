import 'package:MotivateU/res/app_colors.dart';
import 'package:custom_clippers/custom_clippers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class MessageBubble extends StatelessWidget {
  final String type;
  final String? text;
  final String? timestamp;

  MessageBubble({
    required this.type,
    required this.text,
    required this.timestamp,
  });

  @override
  Widget build(BuildContext context) {
    final isSender = type == "sender";
    return isSender
        ? Align(
            alignment: Alignment.centerRight,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  // width: double.maxFinite,
                  child: ClipPath(
                    // clipper: UpperNipMessageClipper(
                    //     isSender?MessageType.send:MessageType.receive
                    // ),
                    child: Container(
                      width: MediaQuery.of(context).size.width * .8,
                      padding: EdgeInsets.only(top: 15.h,bottom: 15.h,left: 10.w,right: 10.w),
                      // height: 100,
                      margin: EdgeInsets.only(
                          left: 12.w, right: 12.w, top: 20.h, bottom: 20.w),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(16.0),
                              topRight: Radius.circular(16.0),
                              bottomRight: isSender
                                  ? Radius.circular(0)
                                  : Radius.circular(16.0),
                              bottomLeft: isSender
                                  ? Radius.circular(16.0)
                                  : Radius.circular(0)),
                          color: Colors.blue
                              .shade50 //isSender ? AppColors.SLIDER_DOTTED_COLOR : Colors.blue.shade50,
                          ),
                      child: Text(text!,
                        textAlign: TextAlign.end,
                        style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.normal,fontFamily: "Poppins",color: Color(0xFF160905)),),
                    ),
                  ),
                ),
                Container(
                    margin: EdgeInsets.only(right: 12.w),
                    child: Text("${timestamp}",style: TextStyle(fontSize: 12.sp,color: AppColors.TITLE_TEXT_BLACK.withOpacity(0.38),fontWeight: FontWeight.normal,fontFamily: "Poppins"),))
              ],
            )
            /*Container(
        margin: EdgeInsets.symmetric(vertical: 4, horizontal: 16),
        padding: EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isSender ? Colors.blue : Colors.grey,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              text,
              style: TextStyle(color: Colors.white),
            ),
            SizedBox(height: 4),
            Text(
              timestamp.toString(),
              style: TextStyle(color: Colors.white.withOpacity(0.7)),
            ),
          ],
        ),
      )*/
            ,
          )
        : Align(
            alignment: Alignment.centerLeft,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  margin: EdgeInsets.only(left: 10.w),
                  child: CircleAvatar(
                    backgroundImage: AssetImage("assets/icons/avatar_img.png"),
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      child: ClipPath(
                        // clipper: UpperNipMessageClipper(
                        //     isSender?MessageType.send:MessageType.receive
                        // ),
                        child: Container(
                          width: MediaQuery.of(context).size.width * .75,
                          //height: 100,
                          padding: EdgeInsets.only(top: 15.h,bottom: 15.h,left: 10.w,right: 10.w),
                          margin: EdgeInsets.only(
                              left: 12.w, right: 12.w, top: 20.h, bottom: 20.w),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(16.0),
                                topRight: Radius.circular(16.0),
                                bottomRight: isSender
                                    ? Radius.circular(0)
                                    : Radius.circular(16.0),
                                bottomLeft: isSender
                                    ? Radius.circular(16.0)
                                    : Radius.circular(0)),
                            color: AppColors.SLIDER_DOTTED_COLOR,
                          ),
                          child: Text(text!,style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.normal,fontFamily: "Poppins",color: Color(0xFF160905)),),
                        ),
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.only(left: 12.w),
                        child: Text("${timestamp}",style: TextStyle(fontSize: 12.sp,color: AppColors.TITLE_TEXT_BLACK.withOpacity(0.38),fontWeight: FontWeight.normal,fontFamily: "Poppins"),))
                  ],
                ),
              ],
            )
          );
  }
}
