import 'package:MotivateU/controllers/reels_controller.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

import '../controllers/chat_controller.dart';
import '../main.dart';
import '../models/chat_history_model.dart';
import '../screens/qreels.dart';
import 'message_bubble.dart';

class ChatScreenWidget extends StatefulWidget {
  final String roomId;
  const ChatScreenWidget({super.key, required this.roomId});

  @override
  State<ChatScreenWidget> createState() => _ChatScreenWidgetState();
}

class _ChatScreenWidgetState extends State<ChatScreenWidget> {

  var controller = Get.find<ChatController>();
  int pageNo = 1;

  ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    controller.getChatHistory(widget.roomId, 1);
    _scrollController.addListener(_scrollListener);
    // socket.on('chat-message',widget.roomId);

  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    // Utils.showToastMessage("hii");
    debugPrint("_scrollController.position====>${controller.chatHistoryModel.value.pagination!.totalRecord} and ${controller.chatHistoryList!.length}");
    if (_scrollController.offset >=
        _scrollController.position.maxScrollExtent &&
        !_scrollController.position.outOfRange) {
      // Reach the end of the list, load more data
      if (controller.chatHistoryModel.value.pagination!.totalRecord !=
          controller.chatHistoryList!.length) {
        setState(() {
          pageNo++;
        });
        controller.getMoreChatHistory(widget.roomId,pageNo);
        //_loadMoreData();
      }
    }
  }

  @override
  Widget build(BuildContext context) {

    // final ChatController chatController = Get.find<ChatController>();
    debugPrint("CHAT-->${socket.connected}");
    if(socket.connected) {
      debugPrint("CHAT-->${widget.roomId}");
      socket.emit('join',widget.roomId);
      socket.on('chat-message', (data) {
        debugPrint("<<<<<socketData_Chat>>>>> ${data['chat']}");
        debugPrint("<<<<<socketData_Chat>>>>> ${data['chat'].runtimeType}");
        //controller.chatHistoryList!.add(data['chat']);
        Result chatResult = Result.fromJson(data['chat']);

        // Add the constructed Result object to the list
        // controller.chatHistoryList!.add(chatResult);
        controller.chatHistoryList!.insert(0, chatResult);
      });
    }
    return Expanded(
      flex: 10,
      child: Obx(() {
        debugPrint("controller.chatHistoryList!.length===>${controller.chatHistoryList!.length}");
        return controller.isLoadingHistory.value?
        Container(
          child: Center(
            child: SizedBox(
              width: 20.w,
              height: 20.h,
              child: CircularProgressIndicator(color: Colors.black,),
            ),
          ),
        )
            : Container(
          color: Colors.white,
          child: NotificationListener<OverscrollIndicatorNotification>(
            onNotification: (OverscrollIndicatorNotification notification) {
              notification.disallowIndicator();
              return true;
            },
            child: ListView.builder(
                shrinkWrap: true,
                reverse: true,
                controller: _scrollController,
                itemBuilder: (context, index) {
                  // final message = chatController.messages[index];
                  // final message = controller.chatHistoryList![index].post!.sId! ==
                  //     SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)?"sender":"receiver";
                  return GestureDetector(
                    onTap: () => controller.chatHistoryList![index].post!.postType == "reel"?
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => QReels(
                              // type: 'scenario',
                                type: '',
                                questionId: controller.chatHistoryList![index].post!.question!.sId!)))
                        :null,
                    child: MessageBubble(
                      type: controller.chatHistoryList![index].profile!.sId ==
                          SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)?"sender":"receiver",
                      text: controller.chatHistoryList![index].messageType == "chat"?controller.chatHistoryList![index].message
                          :
                      controller.chatHistoryList![index].post!.postType == "post"?
                      controller.chatHistoryList![index].post!.postContent:
                      "Topic:${controller.chatHistoryList![index].post!.question!.typename}\n"
                          "Click here to view\n"
                          "http://motivateu.co.in/${controller.chatHistoryList![index].post!.question!.sId}",
                      //"Shared a post",
                      timestamp: controller.chatHistoryList![index].createdAt,
                    ),
                  );
                },
                itemCount: controller.chatHistoryList!.length
            ),
          ),
        );
      }
      ),
    );
  }
}
