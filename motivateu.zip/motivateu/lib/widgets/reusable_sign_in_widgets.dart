import 'package:MotivateU/controllers/login_controller.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

Widget reusableTitleText(String title) {
  return Container(
      alignment: Alignment.bottomLeft,
      margin: EdgeInsets.only(left: 25.w),
      child: Text(title,
          style: TextStyle(
              fontSize: 24.sp,
              color: AppColors.TITLE_TEXT_BLACK,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.bold)));
}

Widget reusableSubTitleText(String title) {
  return Container(
      alignment: Alignment.bottomLeft,
      margin: EdgeInsets.only(top: 8.w, left: 25.w),
      child: Text(title,
          style: TextStyle(
              fontSize: 18.sp,
              color: AppColors.TITLE_TEXT_BLACK.withOpacity(0.48),
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w600)));
}

Widget reusableFieldText(String title) {
  return Container(
      alignment: Alignment.bottomLeft,
      margin: EdgeInsets.only(top: 15.w, left: 25.w),
      child: Text(title,
          style: TextStyle(
              fontSize: 16.sp,
              color: AppColors.TITLE_TEXT_BLACK.withOpacity(0.48),
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w500)));
}

Widget reusableField(
    BuildContext context,
    String hintText,
    TextEditingController controller,
    FocusNode? currentFocus,
    FocusNode? nextFocus,
    [String? type]) {
  return Container(
    height: 45.h,
    margin: EdgeInsets.only(top: 8.w, left: 20.w, right: 20.w),
    padding: EdgeInsets.symmetric(horizontal: 10.w),
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4.0),
        border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),
    child: TextFormField(
      controller: controller,
      focusNode: currentFocus,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      obscureText: type == "password" ? true : false,
      /*onFieldSubmitted: (value) {
        debugPrint("------$type-------");
        if (type == "ph") {
          Utils.fieldFocusChange(context, currentFocus!, nextFocus!);
        }
      },*/
      keyboardType:
          type == "password" ? TextInputType.text : TextInputType.phone,
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly,
      ],
      maxLength: type == "ph" ? 10 : 200,
      decoration: InputDecoration(
        hintText: hintText,
        errorStyle: TextStyle(height: 0, color: Colors.transparent),
        counterText: "",
        hintStyle: TextStyle(
            color: AppColors.FIELD_HINT_COLOR,
            fontFamily: 'Poppins',
            fontSize: 14.sp),
        border: InputBorder.none,
        focusColor: Colors.transparent,
        focusedBorder: InputBorder.none,
        enabledBorder: InputBorder.none,
      ),
    ),
  );
}

Widget reusablePasswordField(String hintText, TextEditingController pwController,bool isPasswordVisible,
    void Function()? func,[String? type]) {
  return Container(
    height: 45.h,
    margin: EdgeInsets.only(top: 8.w, left: 20.w, right: 20.w),
    padding: EdgeInsets.symmetric(horizontal: 10.w),
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4.0),
        color: Colors.white.withOpacity(0.8),
        border: Border.all(color: AppColors.FIELD_BORDER_COLOR)),
    child: TextFormField(
      obscureText: !isPasswordVisible ? true : false,
      controller: pwController,
      keyboardType:
      TextInputType.text,
      decoration: InputDecoration(
        hintText: hintText,
        counterText: "",
        errorStyle: TextStyle(height: 0, color: Colors.transparent),
        suffixIcon: IconButton(
          icon: Icon(isPasswordVisible?Icons.visibility_off:Icons.visibility,),
          color: AppColors.FIELD_BORDER_COLOR,
          onPressed: () => func!(),
        ),
        hintStyle: TextStyle(
            color: AppColors.FIELD_HINT_COLOR,
            fontFamily: 'Poppins',
            fontSize: 14.sp),
        border: InputBorder.none,
        focusColor: Colors.transparent,
        focusedBorder: InputBorder.none,
        enabledBorder: InputBorder.none,
      ),
    ),
  );
}

Widget checkBoxRow(String title) {
  Color getColor(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return AppColors.ON_BOARDING_BUTTON_COLOR;
    }
    return AppColors.ON_BOARDING_BUTTON_COLOR;
  }

  return Obx(() => GestureDetector(
    // onTap: () => Get.find<LoginController>().isRemembered.value?saveData():clearData(),
    child: Container(
          margin: EdgeInsets.only(top: 25.w, left: 25.w),
          child: Row(
            children: [
              Container(
                margin: EdgeInsets.only(right: 5.w),
                height: 20.h,
                width: 20.w,
                child: Checkbox(
                  checkColor: Colors.white,
                  // fillColor: MaterialStateProperty.resolveWith(getColor),
                  value: Get.find<LoginController>().isRemembered.value,
                  onChanged: (bool? value) {
                    Get.find<LoginController>().isRemembered.value =
                        !Get.find<LoginController>().isRemembered.value;


                  },
                ),
              ),
              Text(
                title,
                style:
                    TextStyle(fontSize: 16.sp, color: AppColors.FIELD_HINT_COLOR),
              )
            ],
          ),
        ),
  ));
}

