import 'package:MotivateU/controllers/edit_profile_controller.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/widgets/qconnect_reusable_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';
import '../helper/api_end_points.dart';
import '../res/routes/app_routes.dart';
import '../utils/sharedpreference_utils.dart';

class QConnectHeaderTop extends StatefulWidget {
  const QConnectHeaderTop({super.key});

  @override
  State<QConnectHeaderTop> createState() => _QConnectHeaderTopState();
}

class _QConnectHeaderTopState extends State<QConnectHeaderTop> {
  var controller = Get.isRegistered<EditProfileController>()
      ? Get.find<EditProfileController>()
      : Get.put(EditProfileController());

  @override
  void initState() {
    super.initState();
    initSp();
    controller.getProfileForEdit(
        SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!);
  }

  void initSp() async {
    await SharedPreferencesUtils.init();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 15.w, /*right: 5.w,*/ top: 30.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Obx(
                    () => controller.isLoading.value
                        ? Shimmer.fromColors(
                        baseColor: Colors.grey.withOpacity(0.3),
                        highlightColor: Colors.white.withOpacity(0.4),
                          child: CircleAvatar(
                              backgroundImage:
                                  AssetImage("assets/icons/avatar_img.jpg"),
                              radius: 26.w,
                            ),
                        )
                        :  controller.editProfileModel.value.result![0].avatar != ""?
                    CircleAvatar(
                      // backgroundImage: NetworkImage("${ApiEndPoints.IMAGE_URL}${result.profile![position].avatar}"),
                      // radius: 50.sp,
                      backgroundColor: Colors.transparent, // Add this to make the background transparent
                      child: ClipOval(
                        child: Image.network(
                          "${ApiEndPoints.IMAGE_URL}${controller.editProfileModel.value.result![0].avatar}",
                          fit: BoxFit.cover, // You can adjust the fit as per your requirements
                          width: 50.sp, // Adjust the width and height as needed
                          height: 50.sp,
                        ),
                      ),
                    )
                        :CircleAvatar(
                            backgroundImage:
                                AssetImage("assets/icons/avatar_img.jpg"),
                            radius: 26.w,
                          ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Obx(
                            () => controller.isLoading.value?
                            Shimmer.fromColors(
                              baseColor: Colors.grey.withOpacity(0.3),
                              highlightColor: Colors.white.withOpacity(0.4),
                              child: reusableTitleText("Profile Name"),
                            ): reusableTitleText(
                            "${controller.editProfileModel.value.result![0].name!}"),
                      ),
                      Obx(() =>  controller.isLoading.value?
                        Shimmer.fromColors(
                          baseColor: Colors.grey.withOpacity(0.3),
                          highlightColor: Colors.white.withOpacity(0.4),
                          child: reusableSubTitleText(title:"Class"),
                        )
                            :reusableSubTitleText(
                            title:
                                "Class ${controller.editProfileModel.value.result![0].std!.name!}"),
                      ),
                    ],
                  )
                ],
              )
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              reusableIcon(Icons.add_circle_outline_outlined,
                  () => Get.toNamed(AppRoutes.AddPost)),
              reusableIcon(
                  Icons.group, () => Get.toNamed(AppRoutes.SearchConnect)),
              reusableIcon(Icons.messenger_outline,
                  () => Get.toNamed(AppRoutes.ChatHistoryList)),
            ],
          ),
        ],
      ),
    );
  }
}
