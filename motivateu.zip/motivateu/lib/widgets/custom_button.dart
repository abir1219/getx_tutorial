import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../res/app_colors.dart';

class CustomButton extends StatelessWidget {
  final String buttonName;
  final bool loading;
  final VoidCallback callback;

  CustomButton(
      {super.key,
      required this.buttonName,
      this.loading = false,
      required this.callback});

  @override
  Widget build(BuildContext context) {
    // Utils.showToastMessage("isLoading->$loading");
    return GestureDetector(
      onTap: () => callback(),
      child: Container(
        alignment: Alignment.center,
        margin: EdgeInsets.only(top: 35.h, left: 25.h, right: 25.h),
        width: 260.w,
        padding: EdgeInsets.symmetric(horizontal: 55.w, vertical: 20.w),
        decoration: BoxDecoration(
            color: AppColors.ON_BOARDING_BUTTON_COLOR,
            borderRadius: BorderRadius.circular(40.0.w),
            boxShadow: [
              BoxShadow(
                  color: Colors.grey.withOpacity(0.5),
                  spreadRadius: 1,
                  blurRadius: 2,
                  offset: const Offset(1, 2))
            ]),
        child: loading
            ? SizedBox(
                height: 20.h,
                width: 20.w,
                child: CircularProgressIndicator(
                  color: Colors.white,
                ),
              )
            : Text(
                buttonName,
                style: TextStyle(fontSize: 14.sp, color: Colors.white),
              ),
      ),
    );
  }
}
