import 'package:MotivateU/helper/api_end_points.dart';
import 'package:MotivateU/main.dart';
import 'package:MotivateU/repository/logout_repo.dart';
import 'package:MotivateU/res/app_colors.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:MotivateU/utils/utils.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:socket_io_client/socket_io_client.dart';

import '../controllers/get_profile_controller.dart';
import '../models/get_profile_model.dart';
import '../screens/verify_auth_pin.dart';
import '../utils/app_constants.dart';
import 'member_details_header.dart';

class AccountPageWidget extends StatefulWidget {
  const AccountPageWidget({super.key});

  @override
  State<AccountPageWidget> createState() => _AccountPageWidgetState();
}

class _AccountPageWidgetState extends State<AccountPageWidget> {
  var controller = Get.isRegistered<GetProfileController>()
      ? Get.find<GetProfileController>()
      : Get.put(GetProfileController());

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    controller.getProfile();
    initSp();
  }

/*
  @override
  void dispose() {
    super.dispose();
    controller.dispose();
  }*/

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => controller.isLoading.value
          ? Container(
              height: double.maxFinite,
              child: Center(
                child: SizedBox(
                  height: 24.h,
                  width: 24.w,
                  child: CircularProgressIndicator(
                    color: Colors.black,
                  ),
                ),
              ),
            )
          : isLoading
              ? Container(
                  height: double.maxFinite,
                  child: Center(
                    child: SizedBox(
                      height: 24.h,
                      width: 24.w,
                      child: CircularProgressIndicator(
                        color: Colors.black,
                      ),
                    ),
                  ),
                )
              : Container(
                  color: AppColors.ON_BOARDING_BUTTON_COLOR.withOpacity(0.1),
                  //ACCOUNT_PAGE_BG_COLOR,
                  child: Column(
                    children: [
                      /*Container(
                    child: Text("Profile ID=>${controller.getProfileModel.value.result!.profile![0].sId}"),
                  ),*/
                      MemberDetailsHeader(
                        phone: controller.getProfileModel.value.result![0].phone!,
                      ),
                      Container(
                        margin: EdgeInsets.only(
                          left: 15.w,
                          right: 15.w,
                        ), //debugPrint("controller.PROFILE.value=>${controller.PROFILE.value}");
                        child: Obx(() {
                          // debugPrint("controller.PROFILE.value=>${controller.PROFILE.value}");
                          return Column(
                            children: [
                              for (int i = 0; i < controller.getProfileModel.value.result![0].profile!.length; i++)
                                (controller.getProfileModel.value.result![0].profile![i].sId! ==
                                    SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)
                                    //controller.PROFILE.value
                                )
                                    ? viewProfile(
                                    context: context,
                                    position: i,
                                    result: controller.getProfileModel.value.result![0],
                                    icon: "avatar_img",
                                    labelIcon: "crown")
                                    : Container(),

                            ],
                          );
                        },
                        ),
                      ),
                      Expanded(
                        child: Container(
                          margin: EdgeInsets.only(
                            left: 15.w,
                            right: 15.w,
                          ),
                          width: double.maxFinite,
                          // height: 435.h,
                          //MediaQuery.of(context).size.height*.4,
                          color: AppColors.ACCOUNT_PAGE_BG_COLOR,
                          child: NotificationListener<
                              OverscrollIndicatorNotification>(
                            onNotification:
                                (OverscrollIndicatorNotification overscroll) {
                              overscroll.disallowIndicator();
                              return true;
                            },
                            child: SingleChildScrollView(
                              child: Column(
                                // scrollDirection: Axis.vertical,
                                // shrinkWrap: true,
                                children: [
                                  Container(
                                    height: MediaQuery.of(context).size.height *
                                        .29, //190.h,
                                    margin: EdgeInsets.only(top: 10.h),
                                    decoration: BoxDecoration(
                                      // borderRadius: BorderRadius.circular(6.0.w),
                                      color: Colors.white,
                                    ),
                                    child: Column(
                                      children: [
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              height: 40.w,
                                              width: 18.w,
                                              margin: EdgeInsets.all(12.w),
                                              child: Center(
                                                  child: Icon(
                                                Icons.star_border,
                                                color: Colors.black,
                                              )),
                                            ),
                                            Container(
                                              margin:
                                                  EdgeInsets.only(top: 12.w),
                                              width: 200.w,
                                              height: 50.h,
                                              // color: Colors.amber,
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Text("Profile Score",
                                                      style: TextStyle(
                                                          fontSize: 14.sp,
                                                          color: AppColors
                                                              .BOTTOM_SHEET_BACKGROUND,
                                                          fontFamily:
                                                              "Poppins")),
                                                  for (int i = 0; i < controller.getProfileModel.value.result![0].profile!.length; i++)
                                                    (controller.getProfileModel.value.result![0].profile![i].sId! ==
                                                        SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)
                                                        //controller.PROFILE.value
                                                    )
                                                      ?Text(
                                                    // "100 coins received",
                                                    "${controller.getProfileModel.value.result![0].profile![i].point??0} points earned",
                                                    style: TextStyle(
                                                        fontSize: 11.sp,
                                                        color: AppColors
                                                            .BOTTOM_SHEET_BACKGROUND,
                                                        fontFamily: "Poppins"),
                                                  ):Container(),
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            buildIcon(
                                                icon: "regular_icon",
                                                color: AppColors
                                                    .REGULAR_MEMBER_BATCH_BG_COLOR,
                                                description: "Regular member",
                                                range: "<100 points",
                                                context: context),
                                            buildIcon(
                                                icon: "crown",
                                                color: AppColors
                                                    .GOLD_MEMBER_BATCH_BG_COLOR,
                                                description: "Gold member",
                                                range: "<200 points",
                                                context: context),
                                            buildIcon(
                                                icon: "diamond_icon",
                                                color: AppColors
                                                    .DIAMOND_MEMBER_BATCH_BG_COLOR,
                                                description: "Diamond member",
                                                range: ">200 points",
                                                context: context),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () async{
                                      await SharedPreferencesUtils.init();
                                      String referralCode = SharedPreferencesUtils.getString(AppConstants.REFERRAL_NO)!;
                                      debugPrint("referralCode-->$referralCode");
                                      // Uri link = referralLink(referralCode);
                                      Future<Uri?> link = generateDynamicLink(referralCode);
                                      FlutterShare.share(
                                        title: 'Share',
                                        text: 'Welcome to MotivateU',
                                        linkUrl: link.toString(),
                                      );

                                    },
                                    child: Container(
                                      margin: EdgeInsets.only(top: 10.h),
                                      padding: EdgeInsets.all(12.0.w),
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(6.0.w),
                                        color: Colors.white,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Icon(
                                            Icons.share,
                                            color: Colors.black,
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(left: 12.w),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text("Referral",
                                                    style: TextStyle(
                                                        fontSize: 14.sp,
                                                        color:
                                                            Color(0xFF1A002D),
                                                        fontFamily: "Poppins")),
                                                Text(
                                                    "Refer via social/mail/whatsapp",
                                                    style: TextStyle(
                                                        fontSize: 11.sp,
                                                        color:
                                                            Color(0xFF1A002D),
                                                        fontFamily: "Poppins")),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  /* Container(
                                margin: EdgeInsets.only(top: 10.h),
                                padding: EdgeInsets.all(12.0.w),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(6.0.w),
                                  color: Colors.white,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      height: 20.h,
                                      width: 20.w,
                                      child: SvgPicture.asset(
                                          "assets/icons/save_list.svg",
                                          colorFilter: ColorFilter.mode(
                                              Colors.black,
                                              BlendMode
                                                  .srcIn)), //Image.asset("assets/icons/save_list.png",color: Colors.black,),
                                    ),
                                    GestureDetector(
                                      onTap: () => null,
                                      child: Container(
                                        margin: EdgeInsets.only(left: 12.w),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text("My saved lists",
                                                style: TextStyle(
                                                    fontSize: 14.sp,
                                                    color: Color(0xFF1A002D),
                                                    fontFamily: "Poppins")),
                                            Text("Reels saved by you",
                                                style: TextStyle(
                                                    fontSize: 11.sp,
                                                    color: Color(0xFF1A002D),
                                                    fontFamily: "Poppins")),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),*/
                                  Container(
                                    margin: EdgeInsets.only(top: 10.h),
                                    padding: EdgeInsets.all(12.0.w),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(6.0.w),
                                      color: Colors.white,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        SizedBox(
                                            height: 20.h,
                                            width: 20.w,
                                            child: Icon(Icons.key)

                                            /* SvgPicture.asset(
                                          "assets/icons/save_list.svg",
                                          colorFilter: ColorFilter.mode(
                                              Colors.black,
                                              BlendMode
                                                  .srcIn)),*/ //Image.asset("assets/icons/save_list.png",color: Colors.black,),
                                            ),
                                        GestureDetector(
                                          onTap: () => showDialog(
                                            context: context,
                                            builder: (context) =>VerifyAuthPin(type: 'change'),
                                          ),
                                          child: Container(
                                            margin: EdgeInsets.only(left: 12.w),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                    "Change authentication pin",
                                                    style: TextStyle(
                                                        fontSize: 14.sp,
                                                        color:
                                                            Color(0xFF1A002D),
                                                        fontFamily: "Poppins")),
                                                Text(
                                                    "Verify to change the authentication pin",
                                                    style: TextStyle(
                                                        fontSize: 11.sp,
                                                        color:
                                                            Color(0xFF1A002D),
                                                        fontFamily: "Poppins")),
                                              ],
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () => showDialog(
                                        context: context,
                                        builder: (context) =>
                                            showAlertDialog()),
                                    child: Container(
                                      margin: EdgeInsets.only(top: 10.h),
                                      padding: EdgeInsets.all(12.0.w),
                                      decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(6.0.w),
                                        color: Colors.white,
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            height: 20.h,
                                            width: 20.w,
                                            child: SvgPicture.asset(
                                              "assets/icons/logout.svg",
                                              colorFilter: ColorFilter.mode(
                                                  Colors.black,
                                                  BlendMode.srcIn),
                                            ),
                                          ),
                                          Container(
                                            margin: EdgeInsets.only(left: 12.w),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text("Logout",
                                                    style: TextStyle(
                                                        fontSize: 14.sp,
                                                        color:
                                                            Color(0xFF1A002D),
                                                        fontFamily: "Poppins")),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 4),
                        child: Align(
                          alignment: FractionalOffset.bottomCenter,
                          child: Container(
                            height: 80.h,
                            color: AppColors.TITLE_TEXT_WHITE,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                buildButtomField(
                                  color: AppColors.DEEP_BLUE_COLOR,
                                  title: "REFERRAL BONUS",
                                  func: () =>
                                      Get.toNamed(AppRoutes.ReferralBonus),
                                ),
                                buildButtomField(
                                    color: AppColors.TITLE_TEXT_GREEN,
                                    title: "SUBSCRIBE DETAILS",
                                    func: () => Get.toNamed(
                                        AppRoutes.SubscribeDetails)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget buildButtomField(
      {required Color color,
      required String title,
      required void Function() func}) {
    return GestureDetector(
      onTap: func,
      child: Container(
        height: 45.h,
        width: 160.w,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(40.w),
            border: Border.all(color: color)),
        child: Center(
            child: Text(
          title,
          style:
              TextStyle(fontFamily: "Poppins", fontSize: 12.sp, color: color),
        )),
      ),
    );
  }

  Widget viewProfile(
      {required BuildContext context,
      required Result result,
      required String icon,
      required int position,
      required String labelIcon}) {
    debugPrint("controller.PROFILE.value=>${controller.PROFILE.value} and position=>${result.profile![position].avatar}");
    SharedPreferencesUtils.saveString(AppConstants.ANOTHER_PROFILE_ID, controller.getProfileModel.value.result![0].profile![position==0?1:0].sId!);
    return Container(
      height: 110.h,
      // width: 170.w,//200.w,
      margin: EdgeInsets.only(top: 8.h),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(6.0.w),
          topRight: Radius.circular(6.0.w),
        ),
        color: Colors
            .white, //AppColors.SLIDER_DOTTED_COLOR//ACCOUNT_PAGE_BG_COLOR, //Colors.red,
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                // height: 55.h,
                width: 50.w,
                margin: EdgeInsets.only(right: 10.w, left: 10.w),
                child: Stack(
                  children: [
                    Positioned.fill(
                        child: Container(
                      height: 35.h,
                      width: 35.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100.w),
                      ),
                      child: result.profile![position].avatar != ""?
                      CircleAvatar(
                        // backgroundImage: NetworkImage("${ApiEndPoints.IMAGE_URL}${result.profile![position].avatar}"),
                        //radius: 50.sp,
                        backgroundColor: Colors.transparent, // Add this to make the background transparent
                        child: ClipOval(
                          child: Image.network(
                            "${ApiEndPoints.IMAGE_URL}${result.profile![position].avatar}",
                            fit: BoxFit.cover, // You can adjust the fit as per your requirements
                            width: 50.sp, // Adjust the width and height as needed
                            height: 50.sp,
                          ),
                        ),
                      )
                          : Image.asset("assets/icons/$icon.png"),
                    )),
                    Positioned(
                        top: 26,
                        right: 0,
                        child: SizedBox(
                            height: 12.h,
                            width: 16.w,
                            child: Image.asset("assets/icons/$labelIcon.png")))
                  ],
                ),
              ),
              Text(
                "${result.profile![position].name}",
                style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 16.sp,
                    color: AppColors.TITLE_TEXT_BLACK),
              ),
            ],
          ),
          Positioned(
            child: GestureDetector(
              onTap: () => Get.toNamed(AppRoutes.EditProfile,
                  // arguments: ['65156e7baac1fe9effe50128']),
                  arguments: [result.profile![position].sId]),
              child: Container(
                height: 26.h,
                width: 26.w,
                decoration: BoxDecoration(
                    image: DecorationImage(
                  image: AssetImage("assets/icons/edit.png"),
                  colorFilter: ColorFilter.mode(
                      AppColors.TITLE_TEXT_BLACK, BlendMode.srcIn),
                )),
              ),
            ),
            top: 10,
            right: 10,
          ),
          Positioned(
              bottom: 0,
              right: 0,
              child: Column(
                children: [
                  Divider(color: Colors.red, height: 10),
                  controller.getProfileModel.value.result![0].profile!.length < 2
                      ? Container(
                          margin: EdgeInsets.all(10),
                          child: GestureDetector(
                            onTap: () => Get.toNamed(AppRoutes.AddProfile),
                            child: Container(
                              child: Row(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(right: 2.w),
                                    width: 24.w,
                                    height: 24.h,
                                    // decoration: BoxDecoration(
                                    //   borderRadius: BorderRadius.circular(100.w),
                                    //   color: Colors.grey.withOpacity(0.4)
                                    // ),
                                    child: SizedBox(
                                      width: 18.w,
                                      height: 18.h,
                                      child: Icon(Icons.add,
                                          color: Colors.grey.withOpacity(0.9)),
                                    ),
                                  ),
                                  Text("Add new profile",
                                      style: TextStyle(
                                          color: Colors.grey.withOpacity(0.9))),
                                ],
                              ),
                            ),
                          ),
                        )
                      : Container(
                          margin: EdgeInsets.all(10),
                          child: GestureDetector(
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (context) =>
                                    VerifyAuthPin(position: position, result: result,type: 'switch'),
                              );

                              // SharedPreferencesUtils.saveString(
                              //     AppConstants.PROFILE_ID,
                              //     position == 0
                              //         ? result.profile![position + 1].sId!
                              //         : result.profile![position - 1].sId!);
                              // controller.getProfile();

                            },
                            child: Container(
                              child: Row(
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(right: 2.w),
                                    width: 24.w,
                                    height: 24.h,
                                    // decoration: BoxDecoration(
                                    //   borderRadius: BorderRadius.circular(100.w),
                                    //   color: Colors.grey.withOpacity(0.4)
                                    // ),
                                    child: SizedBox(
                                      width: 18.w,
                                      height: 18.h,
                                      child: Icon(Icons.change_circle_outlined,
                                          color: Colors.grey.withOpacity(0.9)),
                                    ),
                                  ),
                                  Text("Switch to another profile",
                                      style: TextStyle(
                                          color: Colors.grey.withOpacity(0.9)),
                                      overflow: TextOverflow.ellipsis),
                                ],
                              ),
                            ),
                          ),
                        ),
                ],
              ))
        ],
      ),
    );
  }

  Widget addProfile({required BuildContext context}) {
    return GestureDetector(
      onTap: () => Get.toNamed(AppRoutes.AddProfile),
      child: Container(
        height: 80.h,
        width: 135.w,
        margin: EdgeInsets.only(top: 8.h),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(6.0.w),
            topRight: Radius.circular(6.0.w),
            bottomRight: Radius.circular(6.0.w),
            bottomLeft: Radius.circular(6.0.w),
          ),
          // color: Colors.red,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 25.h,
              width: 25.w,
              margin: EdgeInsets.all(4.w),
              child: Container(
                height: 25.h,
                width: 25.w,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(70),
                    border: Border.all(
                        color: Colors.black.withOpacity(0.22), width: 2.w)),
                child: Center(
                    child: Icon(
                  Icons.add,
                  size: 15.w,
                  color: Colors.black.withOpacity(0.22),
                )),
              ),
            ),
            Text("Add profile",
                style: TextStyle(
                    fontFamily: "Poppins",
                    fontSize: 14.sp,
                    color: Color(0xFF969494)))
          ],
        ),
      ),
    );
  }

  Widget buildIcon(
      {required BuildContext context,
      required String icon,
      required Color color,
      required String description,
      required String range}) {
    return Container(
      // color: Colors.red,
      height: MediaQuery.of(context).size.height * .18, //125.h,
      width: MediaQuery.of(context).size.width * .28, //110.h,
      padding: EdgeInsets.only(top: 12.h),
      // color: Colors.red,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 55.h,
            width: 53.w,
            margin: EdgeInsets.only(bottom: 10.w),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(200.w),
              color: color,
            ),
            child: Center(
              child: Image.asset("assets/icons/$icon.png"),
            ),
          ),
          Text(
            description,
            style: TextStyle(
                fontSize: 10.sp,
                fontFamily: "Poppins",
                color: AppColors.BOTTOM_SHEET_BACKGROUND),
            textAlign: TextAlign.center,
          ),
          Text(range,
              style: TextStyle(
                  fontSize: 10.sp,
                  fontFamily: "Poppins",
                  color: AppColors.BOTTOM_SHEET_BACKGROUND),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Future<void> share() async {
    await FlutterShare.share(
        title: 'Example share',
        text: 'Example share text',
        linkUrl: 'https://flutter.dev/',
        chooserTitle: 'Example Chooser Title');
  }

  void initSp() async {
    await SharedPreferencesUtils.init();
  }


  Widget showAlertDialog() {
    return AlertDialog(
      title: Text("Do you want to logout?"),
      actions: <Widget>[
        TextButton(
          style: TextButton.styleFrom(
            textStyle: Theme.of(context).textTheme.labelLarge,
          ),
          child: const Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        TextButton(
          style: TextButton.styleFrom(
            textStyle: Theme.of(context).textTheme.labelLarge,
          ),
          child: const Text('Logout'),
          onPressed: () {
            logout();
            Navigator.of(context).pop();
            setState(() {
              isLoading = true;
            });
          },
        ),
      ],
    );
  }

  void logout() async {
    await SharedPreferencesUtils.init();
    final _logoutRepo = LogoutRepo();
    _logoutRepo.logout().then((value) async {
      Utils.showToastMessage("${value['message']}");
      SharedPreferencesUtils.clear();
      Get.offNamed(AppRoutes.login);
      _connectionSocket();
      socket.io.disconnect();
    }).onError((error, stackTrace) {
      debugPrint("Getting some errors : $error");
      Utils.showToastMessage("Getting some errors : $error");
    });
  }

  _connectionSocket(){
    print("SOCket->${socket.connected}");
    socket.onConnect((data) => print("Connection Established"));
    socket.onConnectError((data) => print("Connection Error : $data"));
    // _socket.on('connection', (data) => print("connection ${data}"));
    socket.onDisconnect((data) => print("Socket server disconnected"));
    print("SOCket->${socket.json.connected}");
  }

  /*Uri referralLink(String code) =>
      Uri.parse('https://mymotivateu.page.link/').replace(queryParameters: {'referral_code': code});*/


    Future<Uri?> generateDynamicLink(String code) async {
      final DynamicLinkParameters parameters = DynamicLinkParameters(
        uriPrefix: 'https://mymotivateu.page.link/',
        link: Uri.parse('https://google.com'),
        androidParameters: AndroidParameters(
          packageName: 'com.motivateu.edutech',
          // minimumVersion: 0
        ),
        iosParameters: IOSParameters(
          bundleId: 'com.motivateu.edutech',
            // minimumVersion: "0"
        ),
      );

      debugPrint("=====parameters=====${parameters}");

      try {
        final ShortDynamicLink shortLink = await FirebaseDynamicLinks.instance.buildShortLink(parameters);
        // debugPrint("----shortLink----$shortLink");
        return shortLink.shortUrl;
      } catch (e) {
        debugPrint("Error creating dynamic link: $e");
        return null;
      }
    }
}
