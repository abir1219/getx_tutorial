import 'package:MotivateU/main.dart';
import 'package:MotivateU/models/reels_model.dart';
import 'package:MotivateU/res/routes/app_routes.dart';
import 'package:MotivateU/screens/comment_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gap/gap.dart';
import 'package:get/get.dart';

import '../controllers/reels_controller.dart';

Widget footerTag() {
  return Container(
    width: 300.w,
    margin: EdgeInsets.symmetric(horizontal: 10.w,vertical: 10.w),
    child: GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: 6,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3,
        crossAxisSpacing: 0,mainAxisSpacing: 0,childAspectRatio: 4.0,),
      itemBuilder: (context, index) {
        return Text("#Descriptive${index+1}",style: TextStyle(fontSize: 13.sp,color: Colors.white,fontWeight: FontWeight.bold),);
      },
    ),
  );
}

Widget footerKeyword({required List<String>? keyword}) {
  debugPrint("KEYWORDS=>${keyword}");
  return Container(
    width: 300.w,
    margin: EdgeInsets.symmetric(horizontal: 10.w,vertical: 10.w),
    child: Column(
      children: [
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: keyword!.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3,
            crossAxisSpacing: 0,mainAxisSpacing: 0,childAspectRatio: 4.0,),
          itemBuilder: (context, index) {
            return Container(
              margin: EdgeInsets.symmetric(horizontal: 2.w,vertical: 2.h),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(10.sp)
                ),
                child: Center(child: Text("#${keyword[index]}",style: TextStyle(fontSize: 14.sp,color: Colors.black,fontWeight: FontWeight.bold,fontFamily: "Alata"),)));
          },
        ),
        Gap(10.h)
      ],
    ),
  );
}

Widget interactiveIcons({required String reelsId,required BuildContext context,required bool isBackground,required Result result,required dynamic socketData}) {
debugPrint("socketData_>${Get.find<ReelsController>().socketData}");
  return Container(
    // height: MediaQuery.of(context).size.height,
    //     color: Colors.red,
    margin: EdgeInsets.only(bottom: 100.w),
    // color: Colors.red,
    child: Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        interactionWithUser(
            icons: Icons.favorite_border,
            // count: "${result.likesCount??0}",
            count: "${socketData['like']??0}",
            function: () {
              debugPrint("Like");
              Get.find<ReelsController>().likeReels(reelsId,result);
            }, isBackground: result.isLiked?true:false, result: result),
        interactionWithUser(
            icons: Icons.thumb_down_alt,
            // count: "${result.dislikesCount??0}",
            count: "${socketData['dislike']??0}",
            function: () {
              debugPrint("Dislike");
              Get.find<ReelsController>().dislikeReels(reelsId,result);
            }, isBackground: result.isDisliked! ? true:false, result: result),
        interactionWithUser(
            icons: Icons.comment,
            // count: "${result.commentsCount??0}",
            count: "${socketData['dislike']??0}",
            function: () {
              debugPrint("Comment");
              // Get.toNamed(AppRoutes.Comment,arguments: ['','']);
              showModalBottomSheet(
                isScrollControlled: true,
                enableDrag: true,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(20.0),
                  ),
                ),
                context: context, builder: (context) => CommentScreen(questionId: result.questions![0].sId!,result:result)); //CommentScreen()
            }, isBackground: false, result: result),
        interactionWithUser(
            icons: Icons.send,
            count: "${socketData['shareCount']??0}",
            function: () {
              debugPrint("Share");
              Get.toNamed(AppRoutes.postTo,arguments: ["reels",result.sId]);
            }, isBackground: false, result: result),
        interactionWithUser(
            icons: Icons.filter_alt_outlined,
            function: () {
              debugPrint("Filter");
              Get.toNamed(AppRoutes.QReelsFilter);
            }, isBackground: false, result: result),
      ],
    ),
  );
}

Widget interactionWithUser({required IconData icons,required bool isBackground,String count="",required void Function()? function,required Result result}){
  debugPrint("-------isBackground-----------$isBackground");
  return GestureDetector(
    onTap: () => function!(),
    child: Container(
      margin: EdgeInsets.only(right: 10.w,top: 23.h),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icons,color: isBackground?Colors.red:Colors.white,size: 30.w,),
          Text(count,style: TextStyle(color: isBackground?Colors.red:Colors.white,fontSize: 12.sp,fontWeight: FontWeight.bold),)
        ],
      ),
    ),
  );
}