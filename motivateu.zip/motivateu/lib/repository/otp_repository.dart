import 'package:MotivateU/data/network/network_api_services.dart';

import '../helper/api_end_points.dart';

class OtpRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> sendOtp(var body) async{
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.sendOtp;
    dynamic response = _apiClient.postApi(url, body);
    return response;
  }

  Future<dynamic> verifyOtp(var body) async{
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.verifyOtp;
    dynamic response = _apiClient.postApi(url, body);
    return response;
  }

  Future<dynamic> addFcm(var body) async {
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.ADD_FCM;
    dynamic response = _apiClient.postApi(url, body);
    return response;
  }
}