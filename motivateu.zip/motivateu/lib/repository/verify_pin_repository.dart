import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';

class VerifyPinRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> verifyAuthPin(var body) async{
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.VerifyPin;
    dynamic response = _apiClient.postApi(url, body);
    return response;
  }

  Future<dynamic> changeAuthPin(var body) async{
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.ChangePin;
    dynamic response = _apiClient.putApi(url, body);
    return response;
  }

  Future<dynamic> addFcm(var body) async {
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.ADD_FCM;
    dynamic response = _apiClient.postApi(url, body);
    return response;
  }
}