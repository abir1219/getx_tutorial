import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class FetchPostRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> fetchPost(var pageNumber,var searchGroup) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.FetchPost+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}?pageNumber=$pageNumber&pageSize=10&searchGroup=$searchGroup";
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> likePost(String postId) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.LikePost+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$postId";
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> disLikePost(String postId) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.DislikePost+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$postId";
    dynamic response = _apiClient.getApi(url);
    return response;
  }
}