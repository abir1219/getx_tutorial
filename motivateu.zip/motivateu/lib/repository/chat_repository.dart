import 'package:flutter/material.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class ChatRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getChatList() async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.ChatList+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}";
    debugPrint("GET_CHAT_LIST_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getChatHistory(var roomId,int pageNo) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.ChatHistory+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$roomId?pageNumber=$pageNo&pageSize=10000";
    debugPrint("GET_CHAT_LIST_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> sendChat(var body) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.SendChat+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}";
    debugPrint("SEND_CHAT_URL====>${url}");
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }


}//SendChat