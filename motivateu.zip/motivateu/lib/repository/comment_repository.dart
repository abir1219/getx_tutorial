import 'package:MotivateU/data/network/network_api_services.dart';
import 'package:MotivateU/helper/api_end_points.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';
import 'package:flutter/material.dart';

class CommentRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getComments(var questionId) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.Comments+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$questionId";
    // var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.Comments+"/65103b11c98a5fa7bbb149b9/$questionId";
    debugPrint("GET_COMMENTS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> postComments(var body) async{
    await SharedPreferencesUtils.init();
    // var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.GetComments+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}";
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.Comments+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}"; //64f5664175ebf2323060cdde
    debugPrint("POST_COMMENTS_URL====>${url}");
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }

  Future<dynamic> deleteComments(String commentId) async{
    await SharedPreferencesUtils.init();
    // var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.GetComments+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}";
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.deleteComment+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$commentId"; //64f5664175ebf2323060cdde
    debugPrint("POST_COMMENTS_URL====>${url}");
    dynamic response = _apiClient.deleteApi(url);
    return response;
  }

}