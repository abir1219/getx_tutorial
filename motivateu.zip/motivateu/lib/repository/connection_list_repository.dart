import 'package:flutter/material.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class ConnectionListRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getConnections(var pageNumber) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.SearchConnection+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/connection?pageNumber=$pageNumber&pageSize=10&searchName=";
    debugPrint("GET_CONNECTIONS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> searchConnections(var pageNumber,var searchItem) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.SearchConnection+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}?pageNumber=$pageNumber&pageSize=10&searchName=$searchItem";
    debugPrint("SEARCH_CONNECTIONS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> sendConnectionRequest(var connectionId) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.sendConnectionRequest+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$connectionId";
    debugPrint("SEARCH_CONNECTIONS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> actionAgainstConnectionRequest(var body) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.actionAgainstConnectionRequest+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}";
    debugPrint("SEARCH_CONNECTIONS_URL====>${url}");
    dynamic response = _apiClient.putApi(url,body);
    return response;
  }

  Future<dynamic> getRequestList({String type="",required int pageNo}) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.RequestList+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$type?page=$pageNo&pageSize=10";
    debugPrint("Request_List_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }
}