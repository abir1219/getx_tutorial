import 'package:MotivateU/data/network/network_api_services.dart';
import 'package:MotivateU/helper/api_end_points.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';

import '../utils/app_constants.dart';

class ReelsRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getReels(int pageNumber,var body, String? scenarioId) async{
    await SharedPreferencesUtils.init();
    String url = scenarioId != "" || scenarioId != null
        ? "${ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.reels+"/"+SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!}" //?pageNumber=$pageNumber&pageSize=20
        : "${ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.reels+"/"+SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!}"; //?pageNumber=$pageNumber&pageSize=20
    //String url = //+"?pageNumber=$pageNumber&pageSize=1000"
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }

  Future<dynamic> viewReels(var questionId) async{
    await SharedPreferencesUtils.init();
    String url = "${ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.viewReels+"/$questionId"}";
    //String url = //+"?pageNumber=$pageNumber&pageSize=1000"
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> saveSeenReels(var body) async{
    await SharedPreferencesUtils.init();
    // String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.SaveQuestionTrack+"/"+SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!;
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.SaveQuestionTrack;
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }

  Future<dynamic> sendTimeTrack(var body) async{
    await SharedPreferencesUtils.init();
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.ADD_TIME_TRACK;
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }

  Future<dynamic> likeReel(var reelsId) async{
    await SharedPreferencesUtils.init();
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.LikeReel+"/"+SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!+"/"+reelsId;
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> dislikeReel(var reelsId) async{
    await SharedPreferencesUtils.init();
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.DislikeReel+"/"+SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)!+"/"+reelsId;
    dynamic response = _apiClient.getApi(url);
    return response;
  }
}
//ADD_TIME_TRACK