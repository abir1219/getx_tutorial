import 'package:MotivateU/data/network/network_api_services.dart';

import '../helper/api_end_points.dart';

class LogoutRepo{
  final _apiClient = NetworkApiServices();

  Future<dynamic> logout() async{
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.logout;
    dynamic response = _apiClient.getApi(url);
    return response;
  }
}