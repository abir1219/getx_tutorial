import 'dart:io';

import 'package:flutter/material.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';

class AddProfileRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> addProfile(var body) async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.addProfile;
    debugPrint("ADD_PROFILE_URL====>${url}");
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }

  Future<void> profileUpload(String profileId,File file) async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.addProfileImage+"/$profileId";
   var result = _apiClient.multipartFileUpload(url, profileId, file);
   return result;
  }

}