import 'package:flutter/material.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';

class SubscriptionRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getSubscriptionList() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.subscription+"?status=Active";
    debugPrint("CLASS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getSubscriptionInvoice(String subscriptionId) async{
    var url = ApiEndPoints.baseUrl +ApiEndPoints.authEndpoints.invoice+"/$subscriptionId";
    debugPrint("CLASS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> mySubscriptionList() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.mySubscription;
    debugPrint("CLASS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> mySubscriptionHistoryList() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.mySubscription+"/all";
    debugPrint("CLASS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> subscribePlan(var body) async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.subscribe;
    debugPrint("Subscribe_URL====>${url}");
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }
}