import 'package:MotivateU/data/network/network_api_services.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:flutter/cupertino.dart';

import '../helper/api_end_points.dart';
import '../utils/sharedpreference_utils.dart';

class DashboardRepository{
  var _apiClient = NetworkApiServices();

  Future<dynamic> getDashboardData() async{
    await SharedPreferencesUtils.init();
    String url = "${ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.Dashboard+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}"}";
    //String url = //+"?pageNumber=$pageNumber&pageSize=1000"
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> checkTnC() async{
    await SharedPreferencesUtils.init();
    String url = "${ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.check_terms}";
    //String url = //+"?pageNumber=$pageNumber&pageSize=1000"
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getDashboardDetailsData(var subjectId) async{
    await SharedPreferencesUtils.init();
    String url = "${ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.Dashboard+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$subjectId"}";
    //String url = //+"?pageNumber=$pageNumber&pageSize=1000"
    dynamic response = _apiClient.getApi(url);
    return response;
  }
}