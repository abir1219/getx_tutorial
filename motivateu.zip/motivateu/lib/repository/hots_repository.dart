import 'package:MotivateU/data/network/network_api_services.dart';
import 'package:MotivateU/helper/api_end_points.dart';
import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';

class HotsRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getHotList() async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.HotList+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}";
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> sendTimeTrack(var body) async{
    await SharedPreferencesUtils.init();
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.ADD_TIME_TRACK;
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }

}