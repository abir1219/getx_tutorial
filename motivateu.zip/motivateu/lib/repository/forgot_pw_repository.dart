import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';

class ForgotPwRepository {
  final _apiClient = NetworkApiServices();

  Future<dynamic> UpdatePwApi(var body) async {
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.forgetPw;
    dynamic response = _apiClient.postApi(url, body);
    return response;
  }
}