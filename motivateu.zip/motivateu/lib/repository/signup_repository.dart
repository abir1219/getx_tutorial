import 'package:MotivateU/data/network/network_api_services.dart';
import 'package:flutter/material.dart';

import '../helper/api_end_points.dart';
import '../models/class_model.dart';

class SignupRepository{
  final _apiClient = NetworkApiServices();


  Future<dynamic> getCity(String city) async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.city+"?city=$city";
    debugPrint("CITY_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getTnC() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.terms_condition;
    debugPrint("TnC_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> acceptTnC() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.accept_terms;
    debugPrint("Accept_TnC_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getClass() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.std;
    debugPrint("CLASS_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getState() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.state;
    debugPrint("STATE_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> addFcm(var body) async {
    String url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.ADD_FCM;
    dynamic response = _apiClient.postApi(url, body);
    return response;
  }

  Future<dynamic> getMedium() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.medium;
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getBoard() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.board;
    dynamic response = _apiClient.getApi(url);
    return response;
  }


  Future<dynamic> getSchool() async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.school;
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> signup(var body) async{
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.signup;
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }

}