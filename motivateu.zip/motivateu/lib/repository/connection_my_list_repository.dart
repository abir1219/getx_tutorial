import 'package:flutter/material.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';

class ConnectionMyListRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getMyConnectionList({var pageNumber,var searchName = "",var type=""}) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.ConnectionMyList+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}$type?pageNumber=$pageNumber&pageSize=10&searchName=$searchName";
    debugPrint("GET_MY_CONNECTION_LIST_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> addPost(var body,var type) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.AddPost+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$type";
    dynamic response = _apiClient.postApi(url, body);
    return response;
  }

  Future<dynamic> deletePost(var postId) async{
    await SharedPreferencesUtils.init();
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.deletePost+"/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$postId";
    dynamic response = _apiClient.deleteApi(url);
    return response;
  }

}