import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';

class ReelsFilterRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getChapters(String filterType) async{
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.GetChapters+"?filterType=$filterType";
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getTopics(String filterType) async{
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.GetTopics+"?filterType=$filterType";
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getSubjects(String filterType) async{
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.GetSubjects+"?filterType=$filterType";
    dynamic response = _apiClient.getApi(url);
    return response;
  }
}