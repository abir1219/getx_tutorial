import 'package:MotivateU/utils/app_constants.dart';
import 'package:MotivateU/utils/sharedpreference_utils.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';

class HotsTopicsRepository{
  final _apiClient = NetworkApiServices();

  Future<dynamic> getHotsTopicsList(String subjectId) async{
    await SharedPreferencesUtils.init();
    var url = "${ApiEndPoints.baseUrl}${ApiEndPoints.authEndpoints.ScenarioTopics}/${SharedPreferencesUtils.getString(AppConstants.PROFILE_ID)}/$subjectId";
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> sendTimeTrack(var body) async{
    await SharedPreferencesUtils.init();
    String url = ApiEndPoints.baseUrl+ApiEndPoints.authEndpoints.ADD_TIME_TRACK;
    dynamic response = _apiClient.postApi(url,body);
    return response;
  }
}