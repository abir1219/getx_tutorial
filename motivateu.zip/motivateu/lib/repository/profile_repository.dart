import 'dart:io';

import 'package:flutter/material.dart';

import '../data/network/network_api_services.dart';
import '../helper/api_end_points.dart';
import 'package:http/http.dart' as http;
import '../utils/app_constants.dart';
import '../utils/sharedpreference_utils.dart';
import '../utils/utils.dart';

class ProfileRepository {
  final _apiClient = NetworkApiServices();

  Future<dynamic> getProfile() async {
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.GetProfile;
    debugPrint("GET_PROFILE_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }

  Future<dynamic> getProfileForEdit(String profileId) async {
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.GetProfile+"/$profileId";
    debugPrint("GET_PROFILE_URL====>${url}");
    dynamic response = _apiClient.getApi(url);
    return response;
  }


  Future<dynamic> UpdateProfileForEdit(var body) async {
    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.UpdateProfile;
    debugPrint("GET_PROFILE_URL====>${url}");
    dynamic response = _apiClient.putApi(url,body);
    return response;
  }

  Future<void> profileUpload(String profileId, File file) async {

    try {
      await SharedPreferencesUtils.init();

      var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.addProfileImage + "/$profileId";
      // var url = "http://192.168.1.184:5007/api/v1/" + ApiEndPoints.authEndpoints.addProfileImage + "/$profileId";

      _apiClient.imageUpload(url,file);

     /* var headers = {
        'Authorization': 'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}',
      };

      var request = http.MultipartRequest("POST", Uri.parse(url));
      request.headers.addAll(headers);

      var stream = http.ByteStream(file.openRead());
      var length = await file.length();

      var multipartFile = http.MultipartFile('file', stream, length, filename: file.path.split("/").last);
      request.files.add(multipartFile);
      // Utils.showToastMessage("profileId01==>${profileId} and \nFile==> ${file.path} and \nURL==>$url");
      await _uploadImage(request);*/

      /*final http.Client client = http.Client();

      final http.StreamedResponse response = await client.send(request);

      // Ensure the client is closed to free up resources
      client.close();

      final String res = await response.stream.bytesToString();

      debugPrint("IMAGE_RES=>${response.request}");
      debugPrint("IMAGE_RES=>${res}");

      if (response.statusCode == 200) {
        print("Image uploaded successfully");
      } else {
        print("Failed to upload image. Status Code: ${response.statusCode}");
      }*/
    } catch (e) {
      print("Error uploading image: $e");
    }
  }


  Future<void> _uploadImage(http.MultipartRequest request) async {
    // Utils.showToastMessage("http.MultipartRequest==>${request}");
    debugPrint("http.MultipartRequest==>${request.files.first}");
    final http.Client client = http.Client();
    try {
      final http.StreamedResponse response = await client.send(request);

      final String res = await response.stream.bytesToString();

      debugPrint("IMAGE_RES=>${response.request}");
      debugPrint("IMAGE_RES=>${res}");

      debugPrint("REQUEST_HEADERS: ${request.headers}");
      debugPrint("REQUEST_BODY: ${request.fields}");
      debugPrint("RESPONSE_STATUS_CODE: ${response.statusCode}");
      debugPrint("RESPONSE_BODY: $res");

      if (response.statusCode == 200) {
        print("Image uploaded successfully");
      } else {
        print("Failed to upload image. Status Code: ${response.statusCode}");
      }
    } catch (e) {
      print("Error uploading image: $e");
    } finally {
      // Ensure the client is closed to free up resources
      print("Final called");
      client.close();
    }
  }

  /*Future<void> profileUpload(String profileId,File file) async{
    try {
    await SharedPreferencesUtils.init();

    // file = File('/data/data/com.motivateu.edutech/cache/faf83b4c-a903-4a67-94b0-307b27a3ec0c/1000062997.jpg');

    var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.addProfileImage+"/$profileId";
    // var url = ApiEndPoints.baseUrl + ApiEndPoints.authEndpoints.addProfileImage;

    var headers = {
      'Content-Type': 'multipart/form-data',
      'Authorization': 'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}',
    };

    debugPrint("AVATAR_URL->$url");
    var request = http.MultipartRequest("POST", Uri.parse(url));
    request.headers.addAll(headers);
   // request.headers["Content-Type"] = "multipart/form-data";
   //  request.headers["Authorization"] = 'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}';

    debugPrint("FILE_UPLOAD=>${file.path} and Name=>${file.path.split("/").last}");

    //request.files.add((http.MultipartFile.fromFile(file,)));

    //var fileObj = file;// your File object here
    var stream = http.ByteStream(file.openRead());
    var length = await file.length();

    var multipartFile = http.MultipartFile('file', stream, length, filename: file.path.split("/").last);
    request.files.add(multipartFile);

    // var fileStream = http.ByteStream(file.openRead());
    // var length = await file.length();
     *//* request.files.add(await http.MultipartFile(
      'file', // Replace with your server's file field name
        file.readAsBytes().asStream(),//fileStream,
        file.lengthSync(),
      filename: file.path.split("/").last//file.uri.pathSegments.last.replaceAll(" ", "_"),//file.path.split("/").last//'example.jpg',
        // contentType: MediaType('image','jpeg'),
    ));*//*


    // request.files.add(await http.MultipartFile.fromPath(
    //   'file',
    //   file.path,
    // ));
    // request.fields['pId'] = profileId;

    // request.files.add(http.MultipartFile.fromBytes('file', fileStream))


      //var response = await request.send();

    final http.StreamedResponse response = await request.send();
    final String res = await response.stream.bytesToString();

      debugPrint("IMAGE_RES=>${response.request}");
      debugPrint("IMAGE_RES=>${res}");
      if (response.statusCode == 200) {
        print("Image uploaded successfully");
      } else {
        print("Failed to upload image. Status Code: ${response.statusCode}");
      }
    } catch (e) {
      print("Error uploading image: $e");
    }

    // var result = _apiClient.multipartFileUpload(url, profileId, file);
    // var result = _apiClient.imageUpload(url, file);
    // return result;
    *//*await SharedPreferencesUtils.init();
    try {
      Dio dio = Dio();

      Map<String, dynamic> headers = {
        'Authorization': 'Bearer ${SharedPreferencesUtils.getString(AppConstants.ACCESS_TOKEN)}',
      };

      FormData formData = FormData.fromMap({
        'file': await MultipartFile.fromFile(file.path),
      });

      await dio.post(url, data: formData,options: Options(
        headers: headers
      ));

      // Handle success
      print('Image uploaded successfully');
    } catch (e) {
      // Handle error
      print('Error uploading image: $e');
    }*//*
  }*/
}
