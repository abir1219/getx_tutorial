import 'package:flutter/material.dart';

class AppColors{
  static const BOTTOM_SHEET_BACKGROUND = Color(0xFF1A002D);
  static const ON_BOARDING_BUTTON_COLOR = Color(0xFF00AEEF);
  static const SLIDER_DOTTED_COLOR = Color(0xFFBBDA6C);
  
  static const TITLE_TEXT_BLACK = Colors.black;
  static const TITLE_TEXT_WHITE = Colors.white;
  static const TITLE_TEXT_GREEN = Color(0xFFA4CD39);
  
  static const FIELD_BORDER_COLOR = Color(0xFF3F3F3F);
  static const FIELD_HINT_COLOR = Color(0xFF9E9E9E);
  static const DEEP_BLUE_COLOR = Color(0xFF00ADEE);
  static const BACK_ARROW_COLOR = Color(0xFF858585);
  static const OTP_PIN_VIEW_COLOR = Color(0xFF3F3F3F);
  static const DASHBOARD_SUBJECT_COLOR = Color(0xFF4B4B4B);
  static const OTP_TIMER_COLOR = Color(0xFF939393);
  static const BOTTOM_NAVIGATION_BAR_COLOR = Color(0xFF1A002D);
  static const ACCOUNT_PREVIEW_BOX_COLOR = Color(0xFF000E39);
  static const ACCOUNT_PAGE_BG_COLOR = Color(0xFFF3FBFE);
  static const ACCOUNT_PAGE_BUTTON_BG_COLOR = Color(0xFFECF9FE);

  static const REGULAR_MEMBER_BATCH_BG_COLOR = Color(0xFFF4FFD6);
  static const GOLD_MEMBER_BATCH_BG_COLOR = Color(0xFFFFFAE7);
  static const DIAMOND_MEMBER_BATCH_BG_COLOR = Color(0xFFF4FEFF);
  static const BOTTOM_CONTAINER_BG_COLOR = Color(0xFF3C2D47);

  static const MCQ_CORRECT_QUESTION_BG_COLOR = Color(0xFFD4FD6C);
  static const MCQ_WRONG_QUESTION_BG_COLOR = Color(0xFFFB5050);

  static const RED_BAR_COLOR = ACCOUNT_PREVIEW_BOX_COLOR;//Color(0xFFFF6868);
  static const YELLOW_BAR_COLOR = ON_BOARDING_BUTTON_COLOR;//Color(0xFFFFC000);
  static const GREEN_BAR_COLOR = TITLE_TEXT_GREEN;//Color(0xFF3FB65F);
}