import 'package:MotivateU/bindings/onboarding_binding.dart';
import 'package:MotivateU/bindings/otp_binding.dart';
import 'package:MotivateU/screens/add_edit_profile.dart';
import 'package:MotivateU/screens/add_post.dart';
import 'package:MotivateU/screens/forgot_pw.dart';
import 'package:MotivateU/screens/hots_topics_screen.dart';
import 'package:MotivateU/screens/login.dart';
import 'package:MotivateU/screens/mobile_screen.dart';
import 'package:MotivateU/screens/on_boarding_screen.dart';
import 'package:MotivateU/screens/otp_screen_new.dart';
import 'package:MotivateU/screens/post_to_group_connection.dart';
import 'package:MotivateU/screens/scenario_screen.dart';
import 'package:MotivateU/screens/search_connect.dart';
import 'package:MotivateU/screens/splash_screen.dart';
import 'package:MotivateU/screens/subscription_details.dart';
import 'package:MotivateU/screens/terms_condition.dart';
import 'package:get/get.dart';

import '../../bindings/Forget_pw_binding.dart';
import '../../bindings/add_profile_bindings.dart';
import '../../bindings/chat_binding.dart';
import '../../bindings/connection_list_binding.dart';
import '../../bindings/dashboard_binding.dart';
import '../../bindings/edit_profile_bindings.dart';
import '../../bindings/hots_topics_binding.dart';
import '../../bindings/login_binding.dart';
import '../../bindings/post_to_binding.dart';
import '../../bindings/reels_filter_binding.dart';
import '../../bindings/signup_binding.dart';
import '../../bindings/subscription_binding.dart';
import '../../screens/chat_history.dart';
import '../../screens/dashboard.dart';
import '../../screens/edit_profile.dart';
import '../../screens/one_to_one_chat.dart';
import '../../screens/post_comment_screen.dart';
import '../../screens/qreels_filter.dart';
import '../../screens/referral_bonus.dart';
import '../../screens/sign_up_screen.dart';
import 'app_routes.dart';

class AppPages {
  static final List<GetPage> pages = [
    GetPage(
      name: AppRoutes.initial,
      page: () => SplashScreen(),
    ),
    GetPage(
        name: AppRoutes.onBoarding,
        page: () => OnBoardingScreen(),
        binding: OnBoardingBinding()),
    GetPage(
        name: AppRoutes.login, page: () => Login(), binding: LoginBinding()),
    GetPage(
        name: AppRoutes.mobile,
        page: () => MobileScreen(),
        binding: OtpBinding()),
    GetPage(
        name: AppRoutes.signup,
        page: () => SignUpScreen(),
        binding: SignUpBinding()),
    GetPage(
        name: AppRoutes.forgetPW,
        page: () => ForgotPW(),
        binding: ForgetPwBinding()),
    //signup
    GetPage(
        name: AppRoutes.otp,
        // page: () => OtpScreen(),
        page: () => OtpScreenNew(),
        binding: OtpBinding()),
    GetPage(
      name: AppRoutes.dashboard,
      page: ({
        String? pageIndex,
        dynamic message,
  }) => Dashboard(pageIndex: pageIndex ?? '-1',message: message,),
      binding: DashboardBinding(),
    ),
    // GetPage(
    //   name: AppRoutes.QReels,
    //   page: () => QReels(),
    //   binding: ReelsBinding(),
    // ),
    GetPage(
        name: AppRoutes.QReelsFilter,
        page: () => QReelsFilter(),
        binding: ReelsFilterBinding()),
    GetPage(
      name: AppRoutes.ReferralBonus,
      page: () => ReferralBonus(),
    ),
    GetPage(
        name: AppRoutes.SubscribeDetails,
        page: () => SubscriptionDetails(),
        binding: SubscriptionBinding()),
    GetPage(
      name: AppRoutes.AddPost,
      page: () => AddPost(),
    ),
    GetPage(
        name: AppRoutes.SearchConnect,
        page: () => SearchConnect(),
        binding: ConnectionListBinding()),
    GetPage(
        name: AppRoutes.ChatHistoryList,
        page: () => ChatHistory(),
        binding: ChatBinding()),
    GetPage(
      name: AppRoutes.OneToOneChat,
      page: () => OneToOneChat(),
    ),
    /*GetPage(
        name: AppRoutes.Comment,
        page: () => CommentScreen(),
        binding: CommentsBinding()),*/
    GetPage(
        name: AppRoutes.AddProfile,
        page: () => AddProfile(),
        binding: AddProfileBinding()),
    GetPage(
        name: AppRoutes.EditProfile,
        page: () => EditProfile(),
        binding: EditProfileBinding()),
    GetPage(
        name: AppRoutes.HotsTopicList,
        page: () => HotsTopicsScreen(),
        binding: HotsTopicBinding()),
    GetPage(
      name: AppRoutes.Scenario,
      page: () => ScenarioScreen(),
      // binding: EditProfileBinding()
    ),
    GetPage(
        name: AppRoutes.postTo,
        page: () => PostToGroupConnection(),
        binding: PostToBinding()),
    GetPage(
      name: AppRoutes.postComment,
      page: () => PostCommentScreen(),
      // binding: PostToBinding()
    ),
    GetPage(
      name: AppRoutes.Tnc,
      page: () => TermsCondition(),
      // binding: PostToBinding()
    ),
  ];
}
