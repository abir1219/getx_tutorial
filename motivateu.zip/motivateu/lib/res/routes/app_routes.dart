class AppRoutes{
  static const initial = "/";
  static const onBoarding = "/onboarding";
  static const login = "/login";
  static const mobile = "/mobile";
  static const signup = "/signup";
  static const otp = "/otp";
  static const forgetPW = "/forgetPw";
  static const dashboard = "/dashboard";
  static const QReels = "/qreels";
  static const QReelsFilter = "/qreelsfilter";
  static const ReferralBonus = "/referralBonus";
  static const SubscribeDetails = "/subscribeDetails";
  static const AddPost = "/addPost";
  static const SearchConnect = "/searchConnect";
  static const ChatHistoryList = "/chatHistoryList";
  static const OneToOneChat = "/oneToOneChat";
  static const Comment = "/comment";
  static const AddProfile = "/addProfile";
  static const EditProfile = "/editProfile";
  static const HotsTopicList = "/hotsTopicsList";
  static const Scenario = "/scenario";
  static const postTo = "/postTo";
  static const postComment = "/postComment";
  static const Tnc = "/tnc";
}